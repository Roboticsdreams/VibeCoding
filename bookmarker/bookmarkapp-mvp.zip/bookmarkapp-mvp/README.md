# BookMark App - MVP

A modern bookmark management application built with React, Material UI, Node.js, Express, and SQLite.

## Project Structure

The project consists of two main parts:

```
bookmarkapp-mvp/
├── backend/            # Node.js/Express API server
│   ├── config/         # Configuration files
│   ├── controllers/    # API controllers
│   ├── middleware/     # Express middleware
│   ├── models/         # Database models (Sequelize)
│   ├── routes/         # API routes
│   ├── utils/          # Utility functions
│   └── db/             # SQLite database files
└── frontend/           # React frontend application
    ├── public/         # Static assets
    └── src/            # React source code
        ├── components/ # React components
        ├── pages/      # Page components
        ├── services/   # API service clients
        ├── context/    # React context providers
        ├── hooks/      # Custom React hooks
        └── utils/      # Utility functions
```

## Features

- **User Authentication**: Register, login, and secure access to bookmarks
- **Bookmark Management**: Create, view, edit, and delete bookmarks
- **Collections**: Organize bookmarks into collections
- **Tags**: Tag bookmarks for easy categorization and searching
- **Search**: Find bookmarks using text search
- **Favorites**: Mark bookmarks as favorites for quick access
- **Responsive Design**: Works on desktop and mobile devices

## Getting Started

### Prerequisites

- Node.js (v14 or higher)
- npm or yarn package manager

### Installation

1. Clone the repository

2. Install backend dependencies:
```bash
cd bookmarkapp-mvp/backend
npm install
```

3. Install frontend dependencies:
```bash
cd ../frontend
npm install
```

### Set Up Environment

1. Create a .env file in the backend directory:
```bash
cd ../backend
cp .env.example .env
```

2. Edit the .env file with your JWT secret:
```
NODE_ENV=development
PORT=5000
JWT_SECRET=your_secure_jwt_secret_key
JWT_EXPIRE=24h
```

### Initialize the Database

```bash
cd bookmarkapp-mvp/backend
npm run db:init
```

### Running the Application

1. Start the backend server:
```bash
cd bookmarkapp-mvp/backend
npm run dev
```

2. In a new terminal, start the frontend development server:
```bash
cd bookmarkapp-mvp/frontend
npm start
```

3. Open your browser and navigate to http://localhost:3000

## API Documentation

### Swagger Documentation

The API is documented using Swagger/OpenAPI. Once the server is running, you can access the interactive documentation at:

```plaintext
http://localhost:5000/api-docs
```

The Swagger UI provides:

- Interactive API documentation
- The ability to try out API endpoints directly from the browser
- Authentication using Bearer token
- Complete request/response documentation

### Postman Collection

A Postman collection and environment are provided for API testing:

- Location: `backend/docs/bookmarkapp.postman_collection.json`
- Environment: `backend/docs/bookmarkapp.postman_environment.json`

This collection includes requests for all endpoints with appropriate authentication headers and request bodies.

For more details, see the [API documentation README](./backend/docs/README.md).

### Authentication Endpoints

- `POST /api/auth/register` - Register a new user
- `POST /api/auth/login` - Login and get access token
- `GET /api/auth/me` - Get current user information

### Bookmark Endpoints

- `GET /api/bookmarks` - Get all bookmarks with optional filtering
- `POST /api/bookmarks` - Create a new bookmark
- `GET /api/bookmarks/:id` - Get a specific bookmark
- `PUT /api/bookmarks/:id` - Update a bookmark
- `DELETE /api/bookmarks/:id` - Delete a bookmark

### Collection Endpoints

- `GET /api/collections` - Get all collections
- `POST /api/collections` - Create a new collection
- `GET /api/collections/:id` - Get a specific collection
- `PUT /api/collections/:id` - Update a collection
- `DELETE /api/collections/:id` - Delete a collection
- `POST /api/collections/:id/bookmarks` - Add bookmark to collection
- `DELETE /api/collections/:id/bookmarks/:bookmarkId` - Remove bookmark from collection

### Tag Endpoints

- `GET /api/tags` - Get all tags
- `POST /api/tags` - Create a new tag
- `PUT /api/tags/:id` - Update a tag
- `DELETE /api/tags/:id` - Delete a tag
- `GET /api/tags/:id/bookmarks` - Get bookmarks by tag
- `POST /api/tags/:id/bookmarks` - Add tag to bookmark
- `DELETE /api/tags/:id/bookmarks/:bookmarkId` - Remove tag from bookmark

## Future Enhancements

The current version is an MVP. Future enhancements include:

- Import/export of bookmarks
- Google Drive integration for backup
- Browser extension for one-click bookmarking
- Sharing of bookmarks and collections
- Advanced analytics and insights
- Mobile apps for iOS and Android

## License

This project is licensed under the MIT License.
