import React, { createContext, useContext, useState, useEffect } from 'react';
import { ThemeProvider as MuiThemeProvider, createTheme, Theme } from '@mui/material';

// Define the shape of our theme context
interface ThemeContextType {
  mode: 'light' | 'dark';
  toggleThemeMode: () => void;
  theme: Theme;
}

// Create the context
const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

// Create a provider component
export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Check localStorage for saved theme preference or use system preference
  const getInitialMode = (): 'light' | 'dark' => {
    const savedMode = localStorage.getItem('themeMode') as 'light' | 'dark';
    
    if (savedMode) {
      return savedMode;
    }
    
    // Check system preference
    const prefersDarkMode = window.matchMedia && 
      window.matchMedia('(prefers-color-scheme: dark)').matches;
    
    return prefersDarkMode ? 'dark' : 'light';
  };
  
  const [mode, setMode] = useState<'light' | 'dark'>(getInitialMode);

  // Create theme based on mode
  const theme = React.useMemo(
    () =>
      createTheme({
        palette: {
          mode: mode,
          primary: {
            main: mode === 'light' ? '#0a5276' : '#64b5f6', // Dark blue in light mode, light blue in dark mode
            light: mode === 'light' ? '#1976d2' : '#90caf9',
            dark: mode === 'light' ? '#063a53' : '#42a5f5',
          },
          secondary: {
            main: mode === 'light' ? '#4caf50' : '#66bb6a', // Green
            light: mode === 'light' ? '#81c784' : '#a5d6a7',
            dark: mode === 'light' ? '#388e3c' : '#43a047',
          },
          background: {
            default: mode === 'light' ? '#f5f7f9' : '#121212',
            paper: mode === 'light' ? '#ffffff' : '#1e1e1e',
          },
          text: {
            primary: mode === 'light' ? '#333333' : '#e0e0e0',
            secondary: mode === 'light' ? '#666666' : '#aaaaaa',
          },
          divider: mode === 'light' ? '#e0e0e0' : '#424242',
        },
        typography: {
          fontFamily: [
            'Inter',
            '-apple-system',
            'BlinkMacSystemFont',
            '"Segoe UI"',
            'Roboto',
            '"Helvetica Neue"',
            'Arial',
            'sans-serif',
          ].join(','),
          h1: {
            fontSize: '1.5rem',
            fontWeight: 600,
          },
          h2: {
            fontSize: '1.25rem',
            fontWeight: 600,
          },
          h3: {
            fontSize: '1.1rem',
            fontWeight: 500,
          },
          body1: {
            fontSize: '0.9rem',
          },
          body2: {
            fontSize: '0.8rem',
          },
          button: {
            textTransform: 'none',
            fontWeight: 500,
          },
        },
        components: {
          MuiAppBar: {
            styleOverrides: {
              root: {
                backgroundColor: mode === 'light' ? '#0a5276' : '#1e1e1e',
                boxShadow: 'none',
              },
            },
          },
          MuiButton: {
            styleOverrides: {
              root: {
                borderRadius: 4,
                textTransform: 'none',
                fontWeight: 500,
                boxShadow: 'none',
              },
              contained: {
                '&:hover': {
                  boxShadow: '0px 2px 4px rgba(0, 0, 0, 0.1)',
                },
              },
            },
          },
          MuiCard: {
            styleOverrides: {
              root: {
                borderRadius: 8,
                boxShadow: mode === 'light' 
                  ? '0px 1px 3px rgba(0, 0, 0, 0.1)' 
                  : '0px 1px 3px rgba(0, 0, 0, 0.3)',
                transition: 'box-shadow 0.2s ease-in-out',
                '&:hover': {
                  boxShadow: mode === 'light'
                    ? '0px 2px 6px rgba(0, 0, 0, 0.15)'
                    : '0px 2px 6px rgba(0, 0, 0, 0.4)',
                },
              },
            },
          },
          MuiIconButton: {
            styleOverrides: {
              root: {
                padding: 8,
              },
            },
          },
          MuiListItemButton: {
            styleOverrides: {
              root: {
                borderRadius: 4,
                '&.Mui-selected': {
                  backgroundColor: mode === 'light'
                    ? 'rgba(10, 82, 118, 0.1)'
                    : 'rgba(100, 181, 246, 0.1)',
                },
                '&:hover': {
                  backgroundColor: mode === 'light'
                    ? 'rgba(10, 82, 118, 0.05)'
                    : 'rgba(100, 181, 246, 0.05)',
                },
              },
            },
          },
          MuiPaper: {
            styleOverrides: {
              root: {
                backgroundImage: 'none',
              },
            },
          },
          MuiDivider: {
            styleOverrides: {
              root: {
                margin: '8px 0',
              },
            },
          },
          MuiSwitch: {
            styleOverrides: {
              root: {
                width: 42,
                height: 26,
                padding: 0,
                '& .MuiSwitch-switchBase': {
                  padding: 0,
                  margin: 2,
                  transitionDuration: '300ms',
                  '&.Mui-checked': {
                    transform: 'translateX(16px)',
                    color: '#fff',
                    '& + .MuiSwitch-track': {
                      opacity: 1,
                      border: 0,
                    },
                  },
                },
                '& .MuiSwitch-thumb': {
                  boxSizing: 'border-box',
                  width: 22,
                  height: 22,
                },
                '& .MuiSwitch-track': {
                  borderRadius: 13,
                  opacity: 1,
                },
              },
            },
          },
        },
        shape: {
          borderRadius: 4,
        },
      }),
    [mode],
  );

  // Toggle between light and dark mode
  const toggleThemeMode = () => {
    const newMode = mode === 'light' ? 'dark' : 'light';
    setMode(newMode);
    localStorage.setItem('themeMode', newMode);
  };

  // Listen for changes to system preference
  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    
    const handleChange = (e: MediaQueryListEvent) => {
      // Only update if user hasn't explicitly set a preference
      if (!localStorage.getItem('themeMode')) {
        setMode(e.matches ? 'dark' : 'light');
      }
    };
    
    mediaQuery.addEventListener('change', handleChange);
    
    return () => {
      mediaQuery.removeEventListener('change', handleChange);
    };
  }, []);

  const value = {
    mode,
    toggleThemeMode,
    theme,
  };

  return (
    <ThemeContext.Provider value={value}>
      <MuiThemeProvider theme={theme}>
        {children}
      </MuiThemeProvider>
    </ThemeContext.Provider>
  );
};

// Custom hook for accessing the theme context
export const useTheme = (): ThemeContextType => {
  const context = useContext(ThemeContext);
  
  if (context === undefined) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  
  return context;
};
