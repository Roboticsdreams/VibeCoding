import api from './api';
import { SharedUser } from '../components/sharing/ShareCollectionDialog';

// Get sharing settings for a collection
export const getSharingSettings = async (collectionId: number): Promise<{
  isPublic: boolean;
  publicLink: string | null;
  sharedUsers: SharedUser[];
}> => {
  const response = await api.get(`/collections/${collectionId}/sharing`);
  return response.data;
};

// Update public sharing settings
export const updatePublicSharing = async (
  collectionId: number, 
  isPublic: boolean
): Promise<{
  isPublic: boolean;
  publicLink: string | null;
}> => {
  const response = await api.put(`/collections/${collectionId}/sharing/public`, { isPublic });
  return response.data;
};

// Share collection with a user
export const shareWithUser = async (
  collectionId: number,
  email: string,
  role: string
): Promise<SharedUser> => {
  const response = await api.post(`/collections/${collectionId}/sharing/users`, { email, role });
  return response.data;
};

// Update a user's role in a shared collection
export const updateUserRole = async (
  collectionId: number,
  userId: number,
  role: string
): Promise<SharedUser> => {
  const response = await api.put(
    `/collections/${collectionId}/sharing/users/${userId}`,
    { role }
  );
  return response.data;
};

// Remove a user from a shared collection
export const removeSharedUser = async (
  collectionId: number,
  userId: number
): Promise<void> => {
  await api.delete(`/collections/${collectionId}/sharing/users/${userId}`);
};

// Get all collections shared with the current user
export const getSharedWithMeCollections = async (): Promise<{
  collections: Array<{
    id: number;
    name: string;
    description?: string;
    color?: string;
    sharedBy: {
      id: number;
      email: string;
      name?: string;
    };
    role: string;
    dateShared: string;
  }>;
}> => {
  const response = await api.get('/sharing/with-me');
  return response.data;
};

// Get all collections the current user has shared
export const getMySharedCollections = async (): Promise<{
  collections: Array<{
    id: number;
    name: string;
    description?: string;
    color?: string;
    isPublic: boolean;
    sharedWithCount: number;
    dateCreated: string;
  }>;
}> => {
  const response = await api.get('/sharing/my-shared');
  return response.data;
};

// Get a shared collection by its public ID
export const getPublicCollection = async (
  publicId: string
): Promise<{
  id: number;
  name: string;
  description?: string;
  color?: string;
  owner: {
    id: number;
    name?: string;
  };
  bookmarks: Array<{
    id: number;
    url: string;
    title: string;
    description?: string;
    favicon?: string;
    createdAt: string;
  }>;
}> => {
  const response = await api.get(`/shared/collections/${publicId}`);
  return response.data;
};
