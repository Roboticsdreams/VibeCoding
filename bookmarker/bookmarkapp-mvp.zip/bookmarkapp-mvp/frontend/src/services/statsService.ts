import api from './api';

// Interface for bookmark statistics
export interface BookmarkStats {
  totalBookmarks: number;
  totalCollections: number;
  totalTags: number;
  bookmarksAddedToday: number;
  bookmarksAddedThisWeek: number;
  bookmarksAddedThisMonth: number;
  mostUsedTags: Array<{
    id: number;
    name: string;
    count: number;
  }>;
  mostPopularDomains: Array<{
    domain: string;
    count: number;
  }>;
}

// Interface for usage analytics
export interface UsageAnalytics {
  mostVisitedBookmarks: Array<{
    id: number;
    title: string;
    url: string;
    visits: number;
    lastVisited: string;
  }>;
  bookmarksByDay: Array<{
    date: string;
    count: number;
  }>;
  bookmarksByCategory: Array<{
    category: string;
    count: number;
  }>;
  visitTrend: Array<{
    date: string;
    visits: number;
  }>;
}

// Get bookmark statistics
export const getBookmarkStats = async (): Promise<BookmarkStats> => {
  const response = await api.get('/stats/bookmarks');
  return response.data;
};

// Get usage analytics
export const getUsageAnalytics = async (timeRange: 'week' | 'month' | 'year'): Promise<UsageAnalytics> => {
  const response = await api.get(`/stats/analytics?timeRange=${timeRange}`);
  return response.data;
};

// Get dead links report
export const getDeadLinksReport = async (): Promise<Array<{
  id: number;
  url: string;
  title: string;
  statusCode: number;
  lastChecked: string;
}>> => {
  const response = await api.get('/stats/dead-links');
  return response.data;
};

// Record bookmark visit
export const recordBookmarkVisit = async (bookmarkId: number): Promise<void> => {
  await api.post(`/stats/visit/${bookmarkId}`);
};

// Get bookmarks health overview
export const getBookmarksHealth = async (): Promise<{
  totalChecked: number;
  healthy: number;
  redirects: number;
  broken: number;
  lastScanDate: string;
}> => {
  const response = await api.get('/stats/health');
  return response.data;
};

// Trigger a scan of all bookmarks for health check
export const triggerHealthScan = async (): Promise<{
  scanId: string;
  startedAt: string;
  estimatedCompletionTime: string;
}> => {
  const response = await api.post('/stats/scan');
  return response.data;
};
