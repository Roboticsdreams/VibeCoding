import api from './api';

export interface Bookmark {
  id: number;
  url: string;
  title: string;
  description?: string;
  favicon?: string;
  notes?: string;
  isFavorite: boolean;
  tags?: Tag[];
  collections?: Collection[];
  createdAt: string;
  updatedAt: string;
}

export interface Tag {
  id: number;
  name: string;
}

export interface Collection {
  id: number;
  name: string;
  description?: string;
  color?: string;
  icon?: string;
}

export interface BookmarkFilters {
  search?: string;
  favorite?: boolean;
  collectionId?: number;
  tagId?: number;
  page?: number;
  limit?: number;
}

export interface BookmarkResponse {
  count: number;
  bookmarks: Bookmark[];
  totalPages: number;
  currentPage: number;
}

export const getBookmarks = async (filters: BookmarkFilters = {}): Promise<BookmarkResponse> => {
  const response = await api.get<BookmarkResponse>('/bookmarks', { params: filters });
  return response.data;
};

export const getBookmark = async (id: number): Promise<Bookmark> => {
  const response = await api.get<Bookmark>(`/bookmarks/${id}`);
  return response.data;
};

export interface CreateBookmarkData {
  url: string;
  title: string;
  description?: string;
  favicon?: string;
  notes?: string;
  isFavorite?: boolean;
  tags?: string[];
  collectionIds?: number[];
}

export const createBookmark = async (bookmarkData: CreateBookmarkData): Promise<Bookmark> => {
  const response = await api.post<Bookmark>('/bookmarks', bookmarkData);
  return response.data;
};

export const updateBookmark = async (id: number, bookmarkData: Partial<CreateBookmarkData>): Promise<Bookmark> => {
  const response = await api.put<Bookmark>(`/bookmarks/${id}`, bookmarkData);
  return response.data;
};

export const deleteBookmark = async (id: number): Promise<void> => {
  await api.delete(`/bookmarks/${id}`);
};
