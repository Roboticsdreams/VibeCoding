import api from './api';

export interface RegisterData {
  email: string;
  password: string;
  firstName?: string;
  lastName?: string;
}

export interface LoginData {
  email: string;
  password: string;
}

export interface AuthResponse {
  id: number;
  email: string;
  firstName?: string;
  lastName?: string;
  token: string;
}

export const register = async (userData: RegisterData): Promise<AuthResponse> => {
  const response = await api.post<AuthResponse>('/auth/register', userData);
  return response.data;
};

export const login = async (userData: LoginData): Promise<AuthResponse> => {
  const response = await api.post<AuthResponse>('/auth/login', userData);
  return response.data;
};

export const getMe = async (): Promise<Omit<AuthResponse, 'token'>> => {
  const response = await api.get<Omit<AuthResponse, 'token'>>('/auth/me');
  return response.data;
};
