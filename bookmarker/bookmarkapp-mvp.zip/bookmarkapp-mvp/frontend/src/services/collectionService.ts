import api from './api';
import { Bookmark } from './bookmarkService';

export interface Collection {
  id: number;
  name: string;
  description?: string;
  color?: string;
  icon?: string;
  isPublic: boolean;
  parentId?: number;
  bookmarks?: Bookmark[];
  childCollections?: Collection[];
  createdAt: string;
  updatedAt: string;
}

export const getCollections = async (): Promise<Collection[]> => {
  const response = await api.get<Collection[]>('/collections');
  return response.data;
};

export const getCollection = async (id: number): Promise<Collection> => {
  const response = await api.get<Collection>(`/collections/${id}`);
  return response.data;
};

export interface CreateCollectionData {
  name: string;
  description?: string;
  color?: string;
  icon?: string;
  isPublic?: boolean;
  parentId?: number;
}

export const createCollection = async (collectionData: CreateCollectionData): Promise<Collection> => {
  const response = await api.post<Collection>('/collections', collectionData);
  return response.data;
};

export const updateCollection = async (
  id: number,
  collectionData: Partial<CreateCollectionData>
): Promise<Collection> => {
  const response = await api.put<Collection>(`/collections/${id}`, collectionData);
  return response.data;
};

export const deleteCollection = async (id: number): Promise<void> => {
  await api.delete(`/collections/${id}`);
};

export const addBookmarkToCollection = async (collectionId: number, bookmarkId: number): Promise<void> => {
  await api.post(`/collections/${collectionId}/bookmarks`, { bookmarkId });
};

export const removeBookmarkFromCollection = async (collectionId: number, bookmarkId: number): Promise<void> => {
  await api.delete(`/collections/${collectionId}/bookmarks/${bookmarkId}`);
};
