import api from './api';
import { ImportOptions, ExportOptions } from '../components/import-export/ImportExportDialog';
import { Bookmark } from './bookmarkService';

// Interface for parsed bookmarks
export interface ParsedBookmark {
  url: string;
  title: string;
  description?: string;
  tags?: string[];
  collectionPath?: string[];
  notes?: string;
  favicon?: string;
}

// Upload file for import
export const importBookmarks = async (file: File, options: ImportOptions): Promise<void> => {
  const formData = new FormData();
  formData.append('file', file);
  formData.append('importMode', options.importMode);
  
  if (options.defaultCollectionId) {
    formData.append('defaultCollectionId', options.defaultCollectionId.toString());
  }

  await api.post('/bookmarks/import', formData, {
    headers: {
      'Content-Type': 'multipart/form-data',
    },
  });
};

// Get export data
export const exportBookmarks = async (format: string, options: ExportOptions): Promise<void> => {
  const response = await api.get('/bookmarks/export', {
    params: {
      format,
      includeCollections: options.includeCollections,
      includeTags: options.includeTags,
      includeNotes: options.includeNotes,
      collectionId: options.collectionId,
    },
    responseType: 'blob',
  });

  // Create file name based on format and date
  const date = new Date().toISOString().split('T')[0];
  let fileName = `bookmarks_${date}`;
  
  switch (format) {
    case 'html':
      fileName += '.html';
      break;
    case 'json':
      fileName += '.json';
      break;
    case 'csv':
      fileName += '.csv';
      break;
    default:
      fileName += '.txt';
  }

  // Create download link
  const url = window.URL.createObjectURL(new Blob([response.data]));
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', fileName);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

// Parse HTML bookmarks (for browser imports)
export const parseHtmlBookmarks = (html: string): ParsedBookmark[] => {
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, 'text/html');
  const bookmarks: ParsedBookmark[] = [];
  
  // Helper function to extract bookmarks from a node
  const extractBookmarks = (node: Element, path: string[] = []): void => {
    // Handle folders
    const folderName = node.querySelector('h3')?.textContent?.trim();
    const newPath = folderName ? [...path, folderName] : path;
    
    // Process all links
    const links = node.querySelectorAll('a');
    links.forEach(link => {
      const url = link.getAttribute('href');
      const title = link.textContent?.trim();
      const addDate = link.getAttribute('add_date');
      const icon = link.getAttribute('icon');
      
      if (url && title) {
        bookmarks.push({
          url,
          title,
          collectionPath: newPath.length > 0 ? newPath : undefined,
          favicon: icon || undefined,
        });
      }
    });
    
    // Process subfolders
    const subfolders = node.querySelectorAll('dl > dt');
    subfolders.forEach(subfolder => {
      if (subfolder.querySelector('h3')) {
        extractBookmarks(subfolder, newPath);
      }
    });
  };
  
  // Start extraction from the document
  const rootNodes = doc.querySelectorAll('dl > dt');
  rootNodes.forEach(node => extractBookmarks(node));
  
  return bookmarks;
};

// Parse JSON bookmarks
export const parseJsonBookmarks = (json: string): ParsedBookmark[] => {
  try {
    const data = JSON.parse(json);
    
    // If it's our app format
    if (Array.isArray(data) && data[0] && 'url' in data[0]) {
      return data.map(item => ({
        url: item.url,
        title: item.title,
        description: item.description,
        tags: item.tags?.map((t: any) => t.name),
        collectionPath: item.collectionPath,
        notes: item.notes,
        favicon: item.favicon
      }));
    }
    
    // If it's a different JSON format, add parsing logic here
    
    throw new Error('Unsupported JSON format');
  } catch (error) {
    throw new Error('Failed to parse JSON bookmarks');
  }
};

// Parse CSV bookmarks
export const parseCsvBookmarks = (csv: string): ParsedBookmark[] => {
  const bookmarks: ParsedBookmark[] = [];
  const lines = csv.split('\n');
  
  // Try to detect header line
  const firstLine = lines[0]?.toLowerCase();
  const hasHeader = firstLine?.includes('url') && firstLine?.includes('title');
  
  // Find column indices
  let urlIndex = 0;
  let titleIndex = 1;
  let descIndex = -1;
  let tagsIndex = -1;
  let folderIndex = -1;
  let notesIndex = -1;
  
  if (hasHeader) {
    const headers = firstLine.split(',').map(h => h.trim());
    urlIndex = headers.findIndex(h => h === 'url');
    titleIndex = headers.findIndex(h => h === 'title');
    descIndex = headers.findIndex(h => h === 'description');
    tagsIndex = headers.findIndex(h => h === 'tags');
    folderIndex = headers.findIndex(h => h === 'folder' || h === 'collection');
    notesIndex = headers.findIndex(h => h === 'notes');
  }
  
  // Process lines
  const startIndex = hasHeader ? 1 : 0;
  for (let i = startIndex; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    
    // Handle CSV escaping (basic implementation)
    const values: string[] = [];
    let current = '';
    let inQuotes = false;
    
    for (let j = 0; j < line.length; j++) {
      const char = line[j];
      if (char === '"') {
        inQuotes = !inQuotes;
      } else if (char === ',' && !inQuotes) {
        values.push(current);
        current = '';
      } else {
        current += char;
      }
    }
    values.push(current); // Add the last value
    
    // Create bookmark object
    if (values[urlIndex]) {
      const bookmark: ParsedBookmark = {
        url: values[urlIndex].replace(/^"|"$/g, ''),
        title: values[titleIndex]?.replace(/^"|"$/g, '') || values[urlIndex],
      };
      
      if (descIndex >= 0 && values[descIndex]) {
        bookmark.description = values[descIndex].replace(/^"|"$/g, '');
      }
      
      if (tagsIndex >= 0 && values[tagsIndex]) {
        bookmark.tags = values[tagsIndex].replace(/^"|"$/g, '').split(';').map(t => t.trim());
      }
      
      if (folderIndex >= 0 && values[folderIndex]) {
        bookmark.collectionPath = values[folderIndex].replace(/^"|"$/g, '').split('/').map(f => f.trim());
      }
      
      if (notesIndex >= 0 && values[notesIndex]) {
        bookmark.notes = values[notesIndex].replace(/^"|"$/g, '');
      }
      
      bookmarks.push(bookmark);
    }
  }
  
  return bookmarks;
};

// Helper to determine import file type
export const detectFileType = (file: File): 'html' | 'json' | 'csv' | 'unknown' => {
  const extension = file.name.split('.').pop()?.toLowerCase();
  
  if (extension === 'html' || extension === 'htm') {
    return 'html';
  } else if (extension === 'json') {
    return 'json';
  } else if (extension === 'csv') {
    return 'csv';
  }
  
  return 'unknown';
};
