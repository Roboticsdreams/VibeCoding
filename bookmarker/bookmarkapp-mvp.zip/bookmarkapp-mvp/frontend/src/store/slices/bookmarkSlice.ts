import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import { BookmarksState, BookmarkFilters, Bookmark } from '../types';
import { 
  getBookmarks, 
  getBookmark, 
  createBookmark as apiCreateBookmark,
  updateBookmark as apiUpdateBookmark,
  deleteBookmark as apiDeleteBookmark,
  toggleFavorite as apiToggleFavorite
} from '../../services/bookmarkService';

const initialState: BookmarksState = {
  bookmarks: [],
  totalCount: 0,
  currentPage: 1,
  totalPages: 1,
  loading: false,
  error: null,
  selectedBookmark: null,
  filters: {
    page: 1,
    limit: 12,
  },
};

export const fetchBookmarks = createAsyncThunk(
  'bookmarks/fetchBookmarks',
  async (filters: BookmarkFilters, { rejectWithValue }) => {
    try {
      return await getBookmarks(filters);
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.message || 'Failed to fetch bookmarks');
    }
  }
);

export const fetchBookmarkById = createAsyncThunk(
  'bookmarks/fetchBookmarkById',
  async (id: number, { rejectWithValue }) => {
    try {
      return await getBookmark(id);
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.message || 'Failed to fetch bookmark');
    }
  }
);

export const createBookmark = createAsyncThunk(
  'bookmarks/createBookmark',
  async (bookmarkData: Partial<Bookmark>, { rejectWithValue }) => {
    try {
      return await apiCreateBookmark(bookmarkData);
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.message || 'Failed to create bookmark');
    }
  }
);

export const updateBookmark = createAsyncThunk(
  'bookmarks/updateBookmark',
  async ({ id, data }: { id: number; data: Partial<Bookmark> }, { rejectWithValue }) => {
    try {
      return await apiUpdateBookmark(id, data);
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.message || 'Failed to update bookmark');
    }
  }
);

export const deleteBookmark = createAsyncThunk(
  'bookmarks/deleteBookmark',
  async (id: number, { rejectWithValue }) => {
    try {
      await apiDeleteBookmark(id);
      return id;
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.message || 'Failed to delete bookmark');
    }
  }
);

export const toggleFavorite = createAsyncThunk(
  'bookmarks/toggleFavorite',
  async (id: number, { rejectWithValue, getState }) => {
    try {
      const response = await apiToggleFavorite(id);
      return response;
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.message || 'Failed to toggle favorite');
    }
  }
);

const bookmarksSlice = createSlice({
  name: 'bookmarks',
  initialState,
  reducers: {
    setFilters: (state, action: PayloadAction<Partial<BookmarkFilters>>) => {
      state.filters = { ...state.filters, ...action.payload };
    },
    clearFilters: (state) => {
      state.filters = { page: 1, limit: 12 };
    },
    setCurrentPage: (state, action: PayloadAction<number>) => {
      state.currentPage = action.payload;
    },
    setSelectedBookmark: (state, action: PayloadAction<Bookmark | null>) => {
      state.selectedBookmark = action.payload;
    },
    clearSelectedBookmark: (state) => {
      state.selectedBookmark = null;
    },
  },
  extraReducers: (builder) => {
    builder
      // Fetch bookmarks
      .addCase(fetchBookmarks.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchBookmarks.fulfilled, (state, action) => {
        state.loading = false;
        state.bookmarks = action.payload.bookmarks;
        state.totalCount = action.payload.count;
        state.currentPage = action.payload.currentPage;
        state.totalPages = action.payload.totalPages;
      })
      .addCase(fetchBookmarks.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      
      // Fetch bookmark by ID
      .addCase(fetchBookmarkById.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchBookmarkById.fulfilled, (state, action) => {
        state.loading = false;
        state.selectedBookmark = action.payload;
      })
      .addCase(fetchBookmarkById.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      
      // Create bookmark
      .addCase(createBookmark.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createBookmark.fulfilled, (state, action) => {
        state.loading = false;
        state.bookmarks = [action.payload, ...state.bookmarks];
        state.totalCount += 1;
      })
      .addCase(createBookmark.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      
      // Update bookmark
      .addCase(updateBookmark.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateBookmark.fulfilled, (state, action) => {
        state.loading = false;
        state.bookmarks = state.bookmarks.map(bookmark =>
          bookmark.id === action.payload.id ? action.payload : bookmark
        );
        if (state.selectedBookmark?.id === action.payload.id) {
          state.selectedBookmark = action.payload;
        }
      })
      .addCase(updateBookmark.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      
      // Delete bookmark
      .addCase(deleteBookmark.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteBookmark.fulfilled, (state, action) => {
        state.loading = false;
        state.bookmarks = state.bookmarks.filter(bookmark => bookmark.id !== action.payload);
        state.totalCount -= 1;
        if (state.selectedBookmark?.id === action.payload) {
          state.selectedBookmark = null;
        }
      })
      .addCase(deleteBookmark.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      
      // Toggle favorite
      .addCase(toggleFavorite.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(toggleFavorite.fulfilled, (state, action) => {
        state.loading = false;
        state.bookmarks = state.bookmarks.map(bookmark =>
          bookmark.id === action.payload.id ? action.payload : bookmark
        );
        if (state.selectedBookmark?.id === action.payload.id) {
          state.selectedBookmark = action.payload;
        }
      })
      .addCase(toggleFavorite.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export const { 
  setFilters, 
  clearFilters, 
  setCurrentPage, 
  setSelectedBookmark, 
  clearSelectedBookmark 
} = bookmarksSlice.actions;

export default bookmarksSlice.reducer;
