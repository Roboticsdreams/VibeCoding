import { configureStore } from '@reduxjs/toolkit';
import authReducer from './slices/authSlice';
import bookmarkReducer from './slices/bookmarkSlice';

const store = configureStore({
  reducer: {
    auth: authReducer,
    bookmarks: bookmarkReducer,
    // We'll add other reducers as we create them
  },
});

// Infer the `RootState` and `AppDispatch` types from the store itself
export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;

export default store;
