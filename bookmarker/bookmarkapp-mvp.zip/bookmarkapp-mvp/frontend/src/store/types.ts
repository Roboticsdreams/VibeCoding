// Common types used across the Redux store

// User types
export interface User {
  id: number;
  email: string;
  firstName?: string;
  lastName?: string;
  avatar?: string;
}

// Auth state types
export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  loading: boolean;
  error: string | null;
}

// Bookmark types
export interface Bookmark {
  id: number;
  url: string;
  title: string;
  description?: string;
  favicon?: string;
  notes?: string;
  isFavorite: boolean;
  createdAt: string;
  updatedAt: string;
}

// Collection types
export interface Collection {
  id: number;
  name: string;
  description?: string;
  color?: string;
  icon?: string;
  parentId?: number | null;
  isPublic: boolean;
  createdAt: string;
  updatedAt: string;
}

// Tag types
export interface Tag {
  id: number;
  name: string;
}

// Bookmark state types
export interface BookmarksState {
  bookmarks: Bookmark[];
  totalCount: number;
  currentPage: number;
  totalPages: number;
  loading: boolean;
  error: string | null;
  selectedBookmark: Bookmark | null;
  filters: BookmarkFilters;
}

// Collection state types
export interface CollectionsState {
  collections: Collection[];
  loading: boolean;
  error: string | null;
  selectedCollection: Collection | null;
}

// Tag state types
export interface TagsState {
  tags: Tag[];
  loading: boolean;
  error: string | null;
}

// Filter types
export interface BookmarkFilters {
  search?: string;
  collectionId?: number;
  tagId?: number;
  favorite?: boolean;
  page: number;
  limit: number;
  sortBy?: string;
  sortDirection?: 'asc' | 'desc';
}

// UI state types
export interface UIState {
  sidebarOpen: boolean;
  mobileOpen: boolean;
  notifications: Notification[];
}

export interface Notification {
  id: string;
  message: string;
  type: 'success' | 'error' | 'info' | 'warning';
  duration?: number;
}

// Root state type
export interface RootState {
  auth: AuthState;
  bookmarks: BookmarksState;
  collections: CollectionsState;
  tags: TagsState;
  ui: UIState;
}
