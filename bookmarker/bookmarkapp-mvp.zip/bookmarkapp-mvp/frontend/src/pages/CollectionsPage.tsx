import React, { useState, useEffect, useCallback } from 'react';
import {
  Box,
  Typography,
  Grid,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  Divider,
} from '@mui/material';
import { Add as AddIcon } from '@mui/icons-material';
import CollectionList from '../components/collections/CollectionList';
import CollectionForm, { CollectionFormData } from '../components/collections/CollectionForm';
import {
  Collection,
  getCollections,
  createCollection,
  updateCollection,
  deleteCollection,
  CreateCollectionData,
} from '../services/collectionService';
import { getBookmarks, BookmarkFilters, Bookmark } from '../services/bookmarkService';
import BookmarkList from '../components/bookmarks/BookmarkList';

const CollectionsPage: React.FC = () => {
  const [collections, setCollections] = useState<Collection[]>([]);
  const [selectedCollectionId, setSelectedCollectionId] = useState<number | null>(null);
  const [bookmarks, setBookmarks] = useState<Bookmark[]>([]);
  const [totalPages, setTotalPages] = useState<number>(1);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [openForm, setOpenForm] = useState<boolean>(false);
  const [editingCollection, setEditingCollection] = useState<Collection | undefined>(undefined);
  const [confirmDelete, setConfirmDelete] = useState<boolean>(false);
  const [collectionToDelete, setCollectionToDelete] = useState<number | null>(null);

  const loadBookmarks = useCallback(async () => {
    try {
      setIsLoading(true);
      const filters: BookmarkFilters = {
        page: currentPage,
        limit: 12,
      };
      
      if (selectedCollectionId) {
        filters.collectionId = selectedCollectionId;
      }
      
      const response = await getBookmarks(filters);
      setBookmarks(response.bookmarks);
      setTotalPages(response.totalPages);
      setCurrentPage(response.currentPage);
    } catch (error) {
      console.error('Error loading bookmarks:', error);
    } finally {
      setIsLoading(false);
    }
  }, [currentPage, selectedCollectionId]);

  useEffect(() => {
    loadCollections();
  }, []);

  useEffect(() => {
    if (selectedCollectionId !== undefined) {
      loadBookmarks();
    }
  }, [selectedCollectionId, currentPage, loadBookmarks]);

  const loadCollections = async () => {
    try {
      const data = await getCollections();
      setCollections(data);
    } catch (error) {
      console.error('Error loading collections:', error);
    }
  };

  const handleSelectCollection = (collectionId: number | null) => {
    setSelectedCollectionId(collectionId);
    setCurrentPage(1);
  };

  const handleAddCollection = () => {
    setEditingCollection(undefined);
    setOpenForm(true);
  };

  const handleEditCollection = (collection: Collection) => {
    setEditingCollection(collection);
    setOpenForm(true);
  };

  const handleDeleteCollection = (collectionId: number) => {
    setCollectionToDelete(collectionId);
    setConfirmDelete(true);
  };

  const confirmDeleteCollection = async () => {
    if (collectionToDelete) {
      try {
        await deleteCollection(collectionToDelete);
        await loadCollections();
        if (selectedCollectionId === collectionToDelete) {
          setSelectedCollectionId(null);
        }
      } catch (error) {
        console.error('Error deleting collection:', error);
      }
    }
    setConfirmDelete(false);
    setCollectionToDelete(null);
  };

  const handleCloseForm = () => {
    setOpenForm(false);
  };

  const handleSubmitCollection = async (values: CollectionFormData) => {
    try {
      // Convert null to undefined for parentId to match the API type
      const formattedValues: CreateCollectionData = {
        ...values,
        parentId: values.parentId === null ? undefined : values.parentId,
      };
      
      if (editingCollection) {
        await updateCollection(editingCollection.id, formattedValues);
      } else {
        await createCollection(formattedValues);
      }
      await loadCollections();
      setOpenForm(false);
    } catch (error) {
      console.error('Error saving collection:', error);
    }
  };

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };

  const handleEditBookmark = (bookmark: Bookmark) => {
    // Implement bookmark editing logic
    console.log("Edit bookmark:", bookmark);
  };

  const handleDeleteBookmark = (bookmarkId: number) => {
    // Implement bookmark deletion logic
    console.log("Delete bookmark:", bookmarkId);
  };

  const handleToggleFavorite = (bookmark: Bookmark) => {
    // Implement toggle favorite logic
    console.log("Toggle favorite:", bookmark);
  };

  return (
    <Box sx={{ p: 3, height: '100%' }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h4" component="h1">
          Collections
        </Typography>
        <Button
          variant="contained"
          color="primary"
          startIcon={<AddIcon />}
          onClick={handleAddCollection}
        >
          New Collection
        </Button>
      </Box>

      <Grid container spacing={3} sx={{ height: 'calc(100% - 60px)' }}>
        <Grid item xs={12} md={3}>
          <CollectionList
            collections={collections}
            selectedCollectionId={selectedCollectionId}
            onSelectCollection={handleSelectCollection}
            onAddCollection={handleAddCollection}
            onEditCollection={handleEditCollection}
            onDeleteCollection={handleDeleteCollection}
          />
        </Grid>
        <Grid item xs={12} md={9}>
          <Box>
            <Typography variant="h5" component="h2" gutterBottom>
              {selectedCollectionId
                ? collections.find(c => c.id === selectedCollectionId)?.name || 'Collection'
                : 'All Bookmarks'}
            </Typography>
            <Divider sx={{ mb: 2 }} />
            {isLoading ? (
              <Typography>Loading bookmarks...</Typography>
            ) : (
              <BookmarkList
                bookmarks={bookmarks}
                totalPages={totalPages}
                currentPage={currentPage}
                onPageChange={handlePageChange}
                onEdit={handleEditBookmark}
                onDelete={handleDeleteBookmark}
                onToggleFavorite={handleToggleFavorite}
              />
            )}
          </Box>
        </Grid>
      </Grid>

      <CollectionForm
        open={openForm}
        collection={editingCollection}
        onClose={handleCloseForm}
        onSubmit={handleSubmitCollection}
      />

      <Dialog open={confirmDelete} onClose={() => setConfirmDelete(false)}>
        <DialogTitle>Confirm Deletion</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Are you sure you want to delete this collection? All bookmarks will remain but will no longer be associated with this collection.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setConfirmDelete(false)}>Cancel</Button>
          <Button onClick={confirmDeleteCollection} color="error">
            Delete
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default CollectionsPage;
