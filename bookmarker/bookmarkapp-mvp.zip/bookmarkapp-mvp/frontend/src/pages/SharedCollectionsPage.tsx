import React, { useState, useEffect, useCallback } from 'react';
import {
  Container,
  Typography,
  Box,
  Tabs,
  Tab,
  Card,
  CardContent,
  CardActions,
  Grid,
  Button,
  Chip,
  Divider,
  IconButton,
  List,
  ListItem,
  ListItemText,
  Avatar,
  Tooltip,
  CircularProgress,
  Alert,
} from '@mui/material';
import {
  Share as ShareIcon,
  Person as PersonIcon,
  FolderShared as FolderSharedIcon,
  OpenInNew as OpenInNewIcon,
  MoreVert as MoreVertIcon,
  PeopleAlt as PeopleAltIcon,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { 
  getSharedWithMeCollections, 
  getMySharedCollections,
  getSharingSettings,
  updatePublicSharing,
  shareWithUser,
  removeSharedUser,
  updateUserRole,
} from '../services/sharingService';
import { Collection } from '../services/collectionService';
import { SharedUser } from '../components/sharing/ShareCollectionDialog';
import ShareCollectionDialog from '../components/sharing/ShareCollectionDialog';

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

const TabPanel = (props: TabPanelProps) => {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`share-tabpanel-${index}`}
      aria-labelledby={`share-tab-${index}`}
      {...other}
    >
      {value === index && <Box sx={{ py: 3 }}>{children}</Box>}
    </div>
  );
};

const SharedCollectionsPage: React.FC = () => {
  const navigate = useNavigate();
  const [tabValue, setTabValue] = useState(0);
  const [sharedWithMe, setSharedWithMe] = useState<any[]>([]);
  const [myShared, setMyShared] = useState<any[]>([]);
  const [selectedCollection, setSelectedCollection] = useState<Collection | null>(null);
  const [showShareDialog, setShowShareDialog] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadSharedCollections = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      // In a real app, these would be API calls
      // For now, we'll mock the data
      
      // Mocked shared with me collections
      setSharedWithMe([
        {
          id: 101,
          name: "Programming Resources",
          description: "Useful programming tutorials and documentation",
          color: "#2196f3",
          sharedBy: {
            id: 201,
            email: "john.doe@example.com",
            name: "John Doe"
          },
          role: "editor",
          dateShared: "2023-10-20T15:30:00Z"
        },
        {
          id: 102,
          name: "Design Inspiration",
          description: "UI/UX design examples and resources",
          color: "#e91e63",
          sharedBy: {
            id: 202,
            email: "jane.smith@example.com",
            name: "Jane Smith"
          },
          role: "viewer",
          dateShared: "2023-11-01T09:45:00Z"
        }
      ]);
      
      // Mocked my shared collections
      setMyShared([
        {
          id: 1,
          name: "Recipes Collection",
          description: "My favorite cooking recipes",
          color: "#4caf50",
          isPublic: true,
          sharedWithCount: 3,
          dateCreated: "2023-09-15T10:20:00Z"
        },
        {
          id: 2,
          name: "Travel Destinations",
          description: "Places to visit",
          color: "#ff9800",
          isPublic: false,
          sharedWithCount: 1,
          dateCreated: "2023-10-05T14:10:00Z"
        }
      ]);
    } catch (error: any) {
      console.error("Error loading shared collections:", error);
      setError(error.message || "Failed to load shared collections");
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadSharedCollections();
  }, [loadSharedCollections]);

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  const handleOpenShareDialog = (collection: any) => {
    // Convert to expected Collection format
    setSelectedCollection({
      id: collection.id,
      name: collection.name,
      description: collection.description,
      color: collection.color,
      isPublic: collection.isPublic || false,
      createdAt: collection.dateCreated,
      updatedAt: collection.dateCreated,
    });
    setShowShareDialog(true);
  };

  const handleCloseShareDialog = () => {
    setShowShareDialog(false);
    setSelectedCollection(null);
  };

  const handleUpdateSharing = async (
    collectionId: number,
    isPublic: boolean,
    publicLink?: string,
    sharedUsers?: SharedUser[]
  ) => {
    try {
      await updatePublicSharing(collectionId, isPublic);
      
      // Update local state
      setMyShared(myShared.map(collection => {
        if (collection.id === collectionId) {
          return { ...collection, isPublic };
        }
        return collection;
      }));
      
      return;
    } catch (error) {
      console.error("Error updating sharing settings:", error);
      throw new Error("Failed to update sharing settings");
    }
  };

  const handleShareWithUser = async (
    collectionId: number,
    email: string,
    role: string
  ) => {
    try {
      await shareWithUser(collectionId, email, role);
      
      // Update local state
      setMyShared(myShared.map(collection => {
        if (collection.id === collectionId) {
          return { 
            ...collection, 
            sharedWithCount: collection.sharedWithCount + 1 
          };
        }
        return collection;
      }));
      
      return;
    } catch (error) {
      console.error("Error sharing with user:", error);
      throw new Error("Failed to share with user");
    }
  };

  const handleRemoveSharedUser = async (
    collectionId: number,
    userId: number
  ) => {
    try {
      await removeSharedUser(collectionId, userId);
      
      // Update local state
      setMyShared(myShared.map(collection => {
        if (collection.id === collectionId && collection.sharedWithCount > 0) {
          return { 
            ...collection, 
            sharedWithCount: collection.sharedWithCount - 1 
          };
        }
        return collection;
      }));
      
      return;
    } catch (error) {
      console.error("Error removing shared user:", error);
      throw new Error("Failed to remove user");
    }
  };

  const handleUpdateUserRole = async (
    collectionId: number,
    userId: number,
    role: string
  ) => {
    try {
      await updateUserRole(collectionId, userId, role);
      return;
    } catch (error) {
      console.error("Error updating user role:", error);
      throw new Error("Failed to update user role");
    }
  };

  const handleViewCollection = (collectionId: number) => {
    navigate(`/collections/${collectionId}`);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const getRoleBadgeColor = (role: string) => {
    switch (role.toLowerCase()) {
      case 'viewer': return '#2196f3';  // Blue
      case 'editor': return '#4caf50';  // Green
      case 'admin': return '#f44336';   // Red
      default: return '#9e9e9e';        // Grey
    }
  };

  return (
    <Container maxWidth="lg" sx={{ py: 4 }}>
      <Box sx={{ mb: 4, display: 'flex', alignItems: 'center' }}>
        <PeopleAltIcon sx={{ fontSize: 32, mr: 2 }} />
        <Typography variant="h4" component="h1">
          Shared Collections
        </Typography>
      </Box>

      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}

      <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
        <Tabs value={tabValue} onChange={handleTabChange} aria-label="shared collections tabs">
          <Tab label="Shared with Me" icon={<PersonIcon />} iconPosition="start" />
          <Tab label="My Shared Collections" icon={<ShareIcon />} iconPosition="start" />
        </Tabs>
      </Box>

      {isLoading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
          <CircularProgress />
        </Box>
      ) : (
        <>
          <TabPanel value={tabValue} index={0}>
            {sharedWithMe.length === 0 ? (
              <Box sx={{ textAlign: 'center', py: 4 }}>
                <FolderSharedIcon sx={{ fontSize: 64, color: 'text.secondary', mb: 2 }} />
                <Typography variant="h6" color="text.secondary">
                  No collections have been shared with you yet
                </Typography>
              </Box>
            ) : (
              <Grid container spacing={3}>
                {sharedWithMe.map((collection) => (
                  <Grid item xs={12} md={6} lg={4} key={collection.id}>
                    <Card 
                      elevation={2}
                      sx={{ 
                        height: '100%', 
                        display: 'flex',
                        flexDirection: 'column',
                        transition: 'transform 0.2s, box-shadow 0.2s',
                        '&:hover': {
                          transform: 'translateY(-4px)',
                          boxShadow: 4,
                        },
                      }}
                    >
                      <CardContent sx={{ flexGrow: 1 }}>
                        <Box 
                          sx={{ 
                            width: 16, 
                            height: 16, 
                            borderRadius: '50%', 
                            bgcolor: collection.color || '#9e9e9e',
                            display: 'inline-block',
                            mr: 1,
                            verticalAlign: 'middle',
                          }}
                        />
                        <Typography variant="h6" component="div" display="inline" sx={{ verticalAlign: 'middle' }}>
                          {collection.name}
                        </Typography>
                        
                        <Chip 
                          label={collection.role}
                          size="small"
                          sx={{ 
                            ml: 1,
                            bgcolor: getRoleBadgeColor(collection.role),
                            color: 'white',
                          }}
                        />
                        
                        <Typography variant="body2" color="text.secondary" sx={{ mt: 2, mb: 1 }}>
                          {collection.description || "No description provided"}
                        </Typography>
                        
                        <Box sx={{ mt: 2 }}>
                          <Typography variant="caption" color="text.secondary" display="block">
                            Shared by: {collection.sharedBy.name || collection.sharedBy.email}
                          </Typography>
                          <Typography variant="caption" color="text.secondary" display="block">
                            Date shared: {formatDate(collection.dateShared)}
                          </Typography>
                        </Box>
                      </CardContent>
                      
                      <CardActions>
                        <Button 
                          size="small" 
                          variant="contained"
                          onClick={() => handleViewCollection(collection.id)}
                          startIcon={<OpenInNewIcon />}
                        >
                          Open Collection
                        </Button>
                      </CardActions>
                    </Card>
                  </Grid>
                ))}
              </Grid>
            )}
          </TabPanel>

          <TabPanel value={tabValue} index={1}>
            {myShared.length === 0 ? (
              <Box sx={{ textAlign: 'center', py: 4 }}>
                <ShareIcon sx={{ fontSize: 64, color: 'text.secondary', mb: 2 }} />
                <Typography variant="h6" color="text.secondary">
                  You haven't shared any collections yet
                </Typography>
                <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                  Share your collections with others by clicking the share button on any collection page
                </Typography>
              </Box>
            ) : (
              <Grid container spacing={3}>
                {myShared.map((collection) => (
                  <Grid item xs={12} md={6} lg={4} key={collection.id}>
                    <Card 
                      elevation={2}
                      sx={{ 
                        height: '100%', 
                        display: 'flex',
                        flexDirection: 'column',
                        transition: 'transform 0.2s, box-shadow 0.2s',
                        '&:hover': {
                          transform: 'translateY(-4px)',
                          boxShadow: 4,
                        },
                      }}
                    >
                      <CardContent sx={{ flexGrow: 1 }}>
                        <Box 
                          sx={{ 
                            width: 16, 
                            height: 16, 
                            borderRadius: '50%', 
                            bgcolor: collection.color || '#9e9e9e',
                            display: 'inline-block',
                            mr: 1,
                            verticalAlign: 'middle',
                          }}
                        />
                        <Typography variant="h6" component="div" display="inline" sx={{ verticalAlign: 'middle' }}>
                          {collection.name}
                        </Typography>
                        
                        {collection.isPublic && (
                          <Chip 
                            label="Public"
                            size="small"
                            sx={{ 
                              ml: 1,
                              bgcolor: '#2196f3',
                              color: 'white',
                            }}
                          />
                        )}
                        
                        <Typography variant="body2" color="text.secondary" sx={{ mt: 2, mb: 1 }}>
                          {collection.description || "No description provided"}
                        </Typography>
                        
                        <Box sx={{ mt: 2 }}>
                          <Typography variant="caption" color="text.secondary" display="block">
                            Shared with: {collection.sharedWithCount} {collection.sharedWithCount === 1 ? 'user' : 'users'}
                          </Typography>
                          <Typography variant="caption" color="text.secondary" display="block">
                            Date created: {formatDate(collection.dateCreated)}
                          </Typography>
                        </Box>
                      </CardContent>
                      
                      <CardActions>
                        <Button 
                          size="small" 
                          variant="contained"
                          onClick={() => handleOpenShareDialog(collection)}
                          startIcon={<ShareIcon />}
                        >
                          Manage Sharing
                        </Button>
                        <Button 
                          size="small" 
                          variant="outlined"
                          onClick={() => handleViewCollection(collection.id)}
                          startIcon={<OpenInNewIcon />}
                        >
                          View
                        </Button>
                      </CardActions>
                    </Card>
                  </Grid>
                ))}
              </Grid>
            )}
          </TabPanel>
        </>
      )}

      <ShareCollectionDialog
        open={showShareDialog}
        collection={selectedCollection}
        onClose={handleCloseShareDialog}
        onUpdateSharing={handleUpdateSharing}
        onShareWithUser={handleShareWithUser}
        onRemoveSharedUser={handleRemoveSharedUser}
        onUpdateUserRole={handleUpdateUserRole}
      />
    </Container>
  );
};

export default SharedCollectionsPage;
