import React, { useState, useEffect } from 'react';
import {
  Container,
  Typography,
  Box,
  Button,
  Card,
  CardContent,
  Grid,
  Divider,
} from '@mui/material';
import { ImportExport as ImportExportIcon } from '@mui/icons-material';
import { getCollections, Collection } from '../services/collectionService';
import ImportExportDialog, { ImportOptions, ExportOptions } from '../components/import-export/ImportExportDialog';
import { importBookmarks, exportBookmarks } from '../services/importExportService';

const ImportExportPage: React.FC = () => {
  const [collections, setCollections] = useState<Collection[]>([]);
  const [openDialog, setOpenDialog] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchCollections = async () => {
      try {
        const data = await getCollections();
        setCollections(data);
      } catch (error) {
        console.error('Error fetching collections:', error);
        setError('Failed to load collections');
      }
    };

    fetchCollections();
  }, []);

  const handleImport = async (file: File, options: ImportOptions) => {
    setIsLoading(true);
    setError(null);

    try {
      await importBookmarks(file, options);
    } catch (error: any) {
      console.error('Import error:', error);
      setError(error.message || 'Failed to import bookmarks');
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const handleExport = async (format: string, options: ExportOptions) => {
    setIsLoading(true);
    setError(null);

    try {
      await exportBookmarks(format, options);
    } catch (error: any) {
      console.error('Export error:', error);
      setError(error.message || 'Failed to export bookmarks');
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Container maxWidth="md" sx={{ py: 4 }}>
      <Box sx={{ mb: 4, display: 'flex', alignItems: 'center' }}>
        <ImportExportIcon sx={{ fontSize: 32, mr: 2 }} />
        <Typography variant="h4" component="h1">
          Import & Export
        </Typography>
      </Box>

      <Grid container spacing={4}>
        <Grid item xs={12} md={6}>
          <Card elevation={3}>
            <CardContent>
              <Typography variant="h5" component="h2" gutterBottom>
                Import Bookmarks
              </Typography>
              <Typography variant="body2" color="text.secondary" paragraph>
                Import your bookmarks from browsers or other bookmark services.
                Supported formats: HTML, JSON, and CSV.
              </Typography>
              <Typography variant="body2" sx={{ mb: 3 }}>
                You can import from Chrome, Firefox, Safari, or any other service
                that exports in HTML bookmark format.
              </Typography>
              <Button 
                variant="contained" 
                onClick={() => setOpenDialog(true)}
                fullWidth
              >
                Import Bookmarks
              </Button>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={6}>
          <Card elevation={3}>
            <CardContent>
              <Typography variant="h5" component="h2" gutterBottom>
                Export Bookmarks
              </Typography>
              <Typography variant="body2" color="text.secondary" paragraph>
                Export your bookmarks for backup or to use in other services.
                Choose from multiple export formats.
              </Typography>
              <Typography variant="body2" sx={{ mb: 3 }}>
                You can export to HTML (for browser imports), JSON (for full data backup),
                or CSV (for spreadsheet compatibility).
              </Typography>
              <Button 
                variant="contained" 
                onClick={() => setOpenDialog(true)}
                fullWidth
              >
                Export Bookmarks
              </Button>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      <Box sx={{ mt: 6 }}>
        <Divider sx={{ mb: 3 }} />
        <Typography variant="h5" component="h2" gutterBottom>
          Import/Export FAQ
        </Typography>

        <Box sx={{ mb: 2 }}>
          <Typography variant="h6" gutterBottom>
            How do I export bookmarks from my browser?
          </Typography>
          <Typography variant="body2" paragraph>
            <strong>Chrome:</strong> Menu → Bookmarks → Bookmark Manager → ⋮ → Export Bookmarks
          </Typography>
          <Typography variant="body2" paragraph>
            <strong>Firefox:</strong> Menu → Bookmarks → Show All Bookmarks → Import and Backup → Export Bookmarks to HTML
          </Typography>
          <Typography variant="body2" paragraph>
            <strong>Safari:</strong> File → Export Bookmarks
          </Typography>
        </Box>

        <Box sx={{ mb: 2 }}>
          <Typography variant="h6" gutterBottom>
            Will importing overwrite my existing bookmarks?
          </Typography>
          <Typography variant="body2" paragraph>
            You can choose to either merge the imported bookmarks with your existing ones or replace them completely. 
            When merging, bookmarks with the same URL will be considered duplicates and will be skipped.
          </Typography>
        </Box>

        <Box sx={{ mb: 2 }}>
          <Typography variant="h6" gutterBottom>
            What information is preserved during export?
          </Typography>
          <Typography variant="body2" paragraph>
            The JSON export format preserves all bookmark data including URLs, titles, descriptions, tags, 
            collections, notes, and favorites. The HTML format is compatible with browser imports but may 
            not preserve all metadata. The CSV format includes basic information suitable for spreadsheet editing.
          </Typography>
        </Box>
      </Box>

      <ImportExportDialog 
        open={openDialog}
        onClose={() => setOpenDialog(false)}
        onImport={handleImport}
        onExport={handleExport}
      />
    </Container>
  );
};

export default ImportExportPage;
