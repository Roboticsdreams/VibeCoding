import React, { useState, useEffect } from 'react';
import { Link as RouterLink } from 'react-router-dom';
import {
  Box,
  Typography,
  Button,
  TextField,
  InputAdornment,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  IconButton,
  Fab,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TablePagination,
  Chip,
  Tooltip,
  MenuItem,
  Menu,
  Switch,
  FormControlLabel,
} from '@mui/material';
import {
  Search as SearchIcon,
  Add as AddIcon,
  Close as CloseIcon,
  MoreVert as MoreVertIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Favorite as FavoriteIcon,
  FavoriteBorder as FavoriteBorderIcon,
  Visibility as VisibilityIcon,
} from '@mui/icons-material';
import { Link } from 'react-router-dom';
import BookmarkForm from '../components/bookmarks/BookmarkForm';
import { Bookmark, BookmarkFilters, getBookmarks, createBookmark, updateBookmark, deleteBookmark } from '../services/bookmarkService';
import { Collection, getCollections } from '../services/collectionService';
import { Tag, getTags } from '../services/tagService';
import { BookmarkFormData } from '../components/bookmarks/BookmarkForm';

const DashboardPage: React.FC = () => {
  const [bookmarks, setBookmarks] = useState<Bookmark[]>([]);
  const [totalCount, setTotalCount] = useState<number>(0);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [filters, setFilters] = useState<BookmarkFilters & { page: number, limit: number }>({
    page: 0, // 0-indexed for MUI TablePagination
    limit: 10,
  });
  
  const [collections, setCollections] = useState<Collection[]>([]);
  const [tags, setTags] = useState<Tag[]>([]);
  
  const [openForm, setOpenForm] = useState<boolean>(false);
  const [editingBookmark, setEditingBookmark] = useState<Bookmark | undefined>(undefined);
  
  const [confirmDelete, setConfirmDelete] = useState<boolean>(false);
  const [bookmarkToDelete, setBookmarkToDelete] = useState<number | null>(null);

  // Menu state for row actions
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [activeBookmarkId, setActiveBookmarkId] = useState<number | null>(null);

  // View toggle (table/card)
  const [viewMode, setViewMode] = useState<'table' | 'card'>('table');

  useEffect(() => {
    loadBookmarks();
    loadCollections();
    loadTags();
  }, [filters]); // eslint-disable-line react-hooks/exhaustive-deps
  // We're intentionally only reloading when filters change

  const loadBookmarks = async () => {
    try {
      setIsLoading(true);
      // Convert from 0-indexed (MUI) to 1-indexed (API)
      const response = await getBookmarks({
        ...filters,
        page: filters.page + 1
      });
      setBookmarks(response.bookmarks);
      setTotalCount(response.count);
    } catch (error) {
      console.error('Error loading bookmarks:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const loadCollections = async () => {
    try {
      const data = await getCollections();
      setCollections(data);
    } catch (error) {
      console.error('Error loading collections:', error);
    }
  };

  const loadTags = async () => {
    try {
      const data = await getTags();
      setTags(data);
    } catch (error) {
      console.error('Error loading tags:', error);
    }
  };

  const handleSearchChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(event.target.value);
  };

  const handleSearch = () => {
    setFilters({
      ...filters,
      search: searchTerm,
      page: 0, // Reset to first page on new search
    });
  };

  const handlePageChange = (event: unknown, newPage: number) => {
    setFilters({
      ...filters,
      page: newPage,
    });
  };

  const handleRowsPerPageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setFilters({
      ...filters,
      limit: parseInt(event.target.value, 10),
      page: 0, // Reset to first page when changing rows per page
    });
  };

  const handleAddBookmark = () => {
    setEditingBookmark(undefined);
    setOpenForm(true);
  };

  const handleEditBookmark = (bookmark: Bookmark) => {
    setEditingBookmark(bookmark);
    setOpenForm(true);
    handleCloseMenu();
  };

  const handleCloseForm = () => {
    setOpenForm(false);
  };

  const handleDeleteBookmark = (bookmarkId: number) => {
    setBookmarkToDelete(bookmarkId);
    setConfirmDelete(true);
    handleCloseMenu();
  };

  const confirmDeleteBookmark = async () => {
    if (bookmarkToDelete) {
      try {
        await deleteBookmark(bookmarkToDelete);
        loadBookmarks();
      } catch (error) {
        console.error('Error deleting bookmark:', error);
      }
    }
    setConfirmDelete(false);
    setBookmarkToDelete(null);
  };

  const handleToggleFavorite = async (bookmark: Bookmark) => {
    try {
      await updateBookmark(bookmark.id, {
        isFavorite: !bookmark.isFavorite,
      });
      loadBookmarks();
    } catch (error) {
      console.error('Error updating bookmark:', error);
    }
    handleCloseMenu();
  };

  const handleSubmitBookmark = async (values: BookmarkFormData) => {
    try {
      if (editingBookmark) {
        await updateBookmark(editingBookmark.id, values);
      } else {
        await createBookmark(values);
      }
      setOpenForm(false);
      loadBookmarks();
    } catch (error) {
      console.error('Error saving bookmark:', error);
    }
  };

  // Menu handlers
  const handleOpenMenu = (event: React.MouseEvent<HTMLElement>, bookmarkId: number) => {
    setAnchorEl(event.currentTarget);
    setActiveBookmarkId(bookmarkId);
  };

  const handleCloseMenu = () => {
    setAnchorEl(null);
    setActiveBookmarkId(null);
  };

  const getActiveBookmark = (): Bookmark | undefined => {
    return bookmarks.find(bookmark => bookmark.id === activeBookmarkId);
  };

  // Truncate text helper
  const truncateText = (text: string, maxLength: number) => {
    return text.length > maxLength ? `${text.substring(0, maxLength)}...` : text;
  };

  return (
    <Box sx={{ p: 3 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
        <Typography variant="h4" component="h1">
          Dashboard
        </Typography>
        
        <Box sx={{ display: 'flex', gap: 2, alignItems: 'center' }}>
          <FormControlLabel
            control={
              <Switch
                checked={viewMode === 'card'}
                onChange={(e) => setViewMode(e.target.checked ? 'card' : 'table')}
                name="viewMode"
                color="primary"
              />
            }
            label="Card View"
          />
          
          <TextField
            placeholder="Search bookmarks..."
            size="small"
            value={searchTerm}
            onChange={handleSearchChange}
            onKeyPress={(e) => {
              if (e.key === 'Enter') {
                handleSearch();
              }
            }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon />
                </InputAdornment>
              ),
            }}
            sx={{ width: 250 }}
          />
          
          <Button
            variant="contained"
            color="primary"
            startIcon={<AddIcon />}
            onClick={handleAddBookmark}
          >
            Add Bookmark
          </Button>
        </Box>
      </Box>

      {/* Table View */}
      {viewMode === 'table' && (
        <Paper sx={{ width: '100%', mb: 2 }}>
          <TableContainer>
            <Table aria-label="bookmarks table">
              <TableHead>
                <TableRow>
                  <TableCell width="5%">Favorite</TableCell>
                  <TableCell width="25%">Title</TableCell>
                  <TableCell width="30%">URL</TableCell>
                  <TableCell width="20%">Description</TableCell>
                  <TableCell width="15%">Tags</TableCell>
                  <TableCell width="5%">Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={6} align="center">Loading...</TableCell>
                  </TableRow>
                ) : bookmarks.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} align="center">No bookmarks found</TableCell>
                  </TableRow>
                ) : (
                  bookmarks.map((bookmark) => (
                    <TableRow key={bookmark.id}>
                      <TableCell>
                        <IconButton 
                          size="small" 
                          onClick={() => handleToggleFavorite(bookmark)}
                        >
                          {bookmark.isFavorite ? (
                            <FavoriteIcon color="error" fontSize="small" />
                          ) : (
                            <FavoriteBorderIcon fontSize="small" />
                          )}
                        </IconButton>
                      </TableCell>
                      <TableCell>{truncateText(bookmark.title, 30)}</TableCell>
                      <TableCell>
                        <Link 
                          to={bookmark.url} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          style={{ 
                            textDecoration: 'none', 
                            color: '#1976d2',
                            display: 'flex',
                            alignItems: 'center',
                            gap: '4px'
                          }}
                        >
                          {truncateText(bookmark.url, 40)}
                          <VisibilityIcon fontSize="small" />
                        </Link>
                      </TableCell>
                      <TableCell>
                        {bookmark.description ? truncateText(bookmark.description, 50) : '-'}
                      </TableCell>
                      <TableCell>
                        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                          {bookmark.tags && bookmark.tags.slice(0, 2).map((tag) => (
                            <Chip 
                              key={tag.id} 
                              label={tag.name} 
                              size="small" 
                              sx={{ fontSize: '0.7rem' }} 
                            />
                          ))}
                          {bookmark.tags && bookmark.tags.length > 2 && (
                            <Chip 
                              label={`+${bookmark.tags.length - 2}`} 
                              size="small" 
                              variant="outlined"
                              sx={{ fontSize: '0.7rem' }} 
                            />
                          )}
                        </Box>
                      </TableCell>
                      <TableCell>
                        <IconButton 
                          aria-label="more" 
                          id={`bookmark-menu-${bookmark.id}`}
                          aria-controls={activeBookmarkId === bookmark.id ? 'bookmark-menu' : undefined}
                          aria-expanded={activeBookmarkId === bookmark.id ? 'true' : undefined}
                          aria-haspopup="true"
                          onClick={(e) => handleOpenMenu(e, bookmark.id)}
                        >
                          <MoreVertIcon />
                        </IconButton>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </TableContainer>
          <TablePagination
            rowsPerPageOptions={[5, 10, 25]}
            component="div"
            count={totalCount}
            rowsPerPage={filters.limit}
            page={filters.page}
            onPageChange={handlePageChange}
            onRowsPerPageChange={handleRowsPerPageChange}
          />
        </Paper>
      )}

      {/* Card view - using the existing BookmarkList component */}
      {viewMode === 'card' && (
        <Box sx={{ display: 'grid', gridTemplateColumns: {
          xs: '1fr',
          sm: 'repeat(2, 1fr)', 
          md: 'repeat(3, 1fr)'
        }, 
        gap: 3
        }}>
          {bookmarks.map((bookmark) => (
            <Box key={bookmark.id} sx={{ position: 'relative' }}>
              <Paper
                sx={{
                  p: 2,
                  height: '100%',
                  display: 'flex',
                  flexDirection: 'column',
                  transition: 'transform 0.2s',
                  '&:hover': {
                    transform: 'translateY(-4px)',
                    boxShadow: 3
                  }
                }}
              >
                <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                  <Typography variant="h6" component="h2" noWrap sx={{ flex: 1 }}>
                    {bookmark.title}
                  </Typography>
                  <IconButton 
                    size="small" 
                    onClick={() => handleToggleFavorite(bookmark)}
                    sx={{ ml: 1 }}
                  >
                    {bookmark.isFavorite ? (
                      <FavoriteIcon color="error" fontSize="small" />
                    ) : (
                      <FavoriteBorderIcon fontSize="small" />
                    )}
                  </IconButton>
                </Box>

                <Link 
                  to={bookmark.url} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  style={{ 
                    textDecoration: 'none', 
                    color: '#1976d2',
                    marginBottom: '8px',
                    display: 'block',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    whiteSpace: 'nowrap'
                  }}
                >
                  {bookmark.url}
                </Link>

                {bookmark.description && (
                  <Typography 
                    variant="body2" 
                    color="text.secondary"
                    sx={{
                      mb: 2,
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      display: '-webkit-box',
                      WebkitLineClamp: 2,
                      WebkitBoxOrient: 'vertical',
                      lineHeight: 1.5,
                      height: '3em'
                    }}
                  >
                    {bookmark.description}
                  </Typography>
                )}

                <Box sx={{ mt: 'auto', display: 'flex', justifyContent: 'space-between', pt: 1 }}>
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                    {bookmark.tags && bookmark.tags.slice(0, 2).map((tag) => (
                      <Chip 
                        key={tag.id} 
                        label={tag.name} 
                        size="small" 
                        sx={{ fontSize: '0.7rem' }} 
                      />
                    ))}
                    {bookmark.tags && bookmark.tags.length > 2 && (
                      <Chip 
                        label={`+${bookmark.tags.length - 2}`} 
                        size="small" 
                        variant="outlined"
                        sx={{ fontSize: '0.7rem' }} 
                      />
                    )}
                  </Box>

                  <Box>
                    <Tooltip title="Edit">
                      <IconButton onClick={() => handleEditBookmark(bookmark)} size="small">
                        <EditIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>
                    <Tooltip title="Delete">
                      <IconButton onClick={() => handleDeleteBookmark(bookmark.id)} size="small">
                        <DeleteIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>
                  </Box>
                </Box>
              </Paper>
            </Box>
          ))}
        </Box>
      )}

      {/* Row Action Menu */}
      <Menu
        id="bookmark-menu"
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={handleCloseMenu}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'right',
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'right',
        }}
      >
        {getActiveBookmark() && (
          <>
            <MenuItem onClick={() => handleEditBookmark(getActiveBookmark()!)}>
              <EditIcon fontSize="small" sx={{ mr: 1 }} />
              Edit
            </MenuItem>
            <MenuItem onClick={() => handleToggleFavorite(getActiveBookmark()!)}>
              {getActiveBookmark()!.isFavorite ? (
                <>
                  <FavoriteIcon fontSize="small" sx={{ mr: 1 }} color="error" />
                  Remove Favorite
                </>
              ) : (
                <>
                  <FavoriteBorderIcon fontSize="small" sx={{ mr: 1 }} />
                  Add to Favorites
                </>
              )}
            </MenuItem>
            <MenuItem onClick={() => handleDeleteBookmark(getActiveBookmark()!.id)}>
              <DeleteIcon fontSize="small" sx={{ mr: 1 }} />
              Delete
            </MenuItem>
          </>
        )}
      </Menu>
      
      {/* Add/Edit Bookmark Dialog */}
      <Dialog open={openForm} onClose={handleCloseForm} maxWidth="md" fullWidth>
        <DialogTitle>
          {editingBookmark ? 'Edit Bookmark' : 'Add New Bookmark'}
          <IconButton
            aria-label="close"
            onClick={handleCloseForm}
            sx={{
              position: 'absolute',
              right: 8,
              top: 8,
            }}
          >
            <CloseIcon />
          </IconButton>
        </DialogTitle>
        <DialogContent>
          <BookmarkForm
            bookmark={editingBookmark}
            collections={collections}
            tags={tags}
            onSubmit={handleSubmitBookmark}
            onCancel={handleCloseForm}
          />
        </DialogContent>
      </Dialog>
      
      {/* Delete Confirmation Dialog */}
      <Dialog open={confirmDelete} onClose={() => setConfirmDelete(false)}>
        <DialogTitle>Confirm Deletion</DialogTitle>
        <DialogContent>
          <Typography>
            Are you sure you want to delete this bookmark? This action cannot be undone.
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setConfirmDelete(false)}>Cancel</Button>
          <Button onClick={confirmDeleteBookmark} color="error">
            Delete
          </Button>
        </DialogActions>
      </Dialog>

      {/* Floating action button for mobile */}
      <Fab
        color="primary"
        aria-label="add"
        sx={{
          position: 'fixed',
          bottom: 16,
          right: 16,
          display: { xs: 'flex', md: 'none' },
        }}
        onClick={handleAddBookmark}
      >
        <AddIcon />
      </Fab>
    </Box>
  );
};

export default DashboardPage;
