import React from 'react';
import { Box, Container } from '@mui/material';
import RegisterForm from '../components/auth/RegisterForm';

const RegisterPage: React.FC = () => {
  return (
    <Container maxWidth="sm">
      <Box sx={{ mt: 10 }}>
        <RegisterForm />
      </Box>
    </Container>
  );
};

export default RegisterPage;
