import React, { useState, useEffect, useCallback } from 'react';
import {
  Box,
  Container,
  Grid,
  Paper,
  Typography,
  CircularProgress,
  Card,
  CardContent,
  CardHeader,
  Divider,
  Tabs,
  Tab,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  Chip,
  Button,
  Alert,
} from '@mui/material';
import {
  Bookmark as BookmarkIcon,
  FolderOutlined as FolderIcon,
  LocalOffer as TagIcon,
  TrendingUp as TrendingUpIcon,
  Error as ErrorIcon,
  CheckCircle as CheckIcon,
  WarningAmber as WarningIcon,
  Refresh as RefreshIcon,
} from '@mui/icons-material';
import { 
  getBookmarkStats, 
  getUsageAnalytics, 
  getDeadLinksReport,
  getBookmarksHealth,
  triggerHealthScan,
  BookmarkStats,
  UsageAnalytics
} from '../services/statsService';

// Chart components would go here in a real implementation
// For simplicity, we'll just use placeholder components
const BarChart = ({ data }: { data: any }) => {
  // This would be a proper chart in a real app
  return (
    <Box sx={{ height: 200, p: 2, backgroundColor: 'rgba(0,0,0,0.02)', borderRadius: 1 }}>
      <Typography variant="caption" color="text.secondary">
        {JSON.stringify(data).substring(0, 100) + "..."}
      </Typography>
    </Box>
  );
};

const PieChart = ({ data }: { data: any }) => {
  // This would be a proper chart in a real app
  return (
    <Box sx={{ height: 200, p: 2, display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
      <Typography variant="caption" color="text.secondary">
        Pie Chart Placeholder
      </Typography>
    </Box>
  );
};

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

const TabPanel = (props: TabPanelProps) => {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`stats-tabpanel-${index}`}
      aria-labelledby={`stats-tab-${index}`}
      {...other}
    >
      {value === index && <Box sx={{ py: 3 }}>{children}</Box>}
    </div>
  );
};

const StatsDashboardPage: React.FC = () => {
  const [tabValue, setTabValue] = useState(0);
  const [timeRange, setTimeRange] = useState<'week' | 'month' | 'year'>('month');
  const [stats, setStats] = useState<BookmarkStats | null>(null);
  const [analytics, setAnalytics] = useState<UsageAnalytics | null>(null);
  const [deadLinks, setDeadLinks] = useState<any[]>([]);
  const [health, setHealth] = useState<any | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [scanTriggered, setScanTriggered] = useState(false);

  const loadStats = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      // In a real app, these would be API calls
      // For now, we'll mock the data
      
      // Mock bookmark stats
      setStats({
        totalBookmarks: 387,
        totalCollections: 24,
        totalTags: 158,
        bookmarksAddedToday: 5,
        bookmarksAddedThisWeek: 27,
        bookmarksAddedThisMonth: 86,
        mostUsedTags: [
          { id: 1, name: "development", count: 48 },
          { id: 2, name: "design", count: 35 },
          { id: 3, name: "productivity", count: 29 },
          { id: 4, name: "reference", count: 22 },
          { id: 5, name: "tutorial", count: 18 }
        ],
        mostPopularDomains: [
          { domain: "github.com", count: 53 },
          { domain: "medium.com", count: 41 },
          { domain: "stackoverflow.com", count: 37 },
          { domain: "youtube.com", count: 29 },
          { domain: "dev.to", count: 23 }
        ]
      });
      
      // Mock usage analytics
      setAnalytics({
        mostVisitedBookmarks: [
          { id: 101, title: "GitHub", url: "https://github.com", visits: 48, lastVisited: "2023-11-02T10:30:00Z" },
          { id: 102, title: "Stack Overflow", url: "https://stackoverflow.com", visits: 42, lastVisited: "2023-11-02T14:15:00Z" },
          { id: 103, title: "React Documentation", url: "https://reactjs.org/docs", visits: 37, lastVisited: "2023-11-01T09:45:00Z" },
          { id: 104, title: "MDN Web Docs", url: "https://developer.mozilla.org", visits: 31, lastVisited: "2023-10-31T16:20:00Z" }
        ],
        bookmarksByDay: [
          { date: "2023-10-27", count: 7 },
          { date: "2023-10-28", count: 3 },
          { date: "2023-10-29", count: 0 },
          { date: "2023-10-30", count: 12 },
          { date: "2023-10-31", count: 8 },
          { date: "2023-11-01", count: 5 },
          { date: "2023-11-02", count: 9 }
        ],
        bookmarksByCategory: [
          { category: "Development", count: 127 },
          { category: "Design", count: 84 },
          { category: "Business", count: 63 },
          { category: "Education", count: 59 },
          { category: "Entertainment", count: 48 }
        ],
        visitTrend: [
          { date: "2023-10-27", visits: 23 },
          { date: "2023-10-28", visits: 18 },
          { date: "2023-10-29", visits: 15 },
          { date: "2023-10-30", visits: 29 },
          { date: "2023-10-31", visits: 32 },
          { date: "2023-11-01", visits: 27 },
          { date: "2023-11-02", visits: 30 }
        ]
      });
      
      // Mock dead links
      setDeadLinks([
        { id: 201, url: "https://old-blog.example.com/article", title: "Old Blog Article", statusCode: 404, lastChecked: "2023-11-01T18:30:00Z" },
        { id: 202, url: "https://outdated-docs.example.org", title: "Outdated Documentation", statusCode: 404, lastChecked: "2023-11-01T18:30:00Z" },
        { id: 203, url: "https://moved-resource.example.net", title: "Moved Resource", statusCode: 301, lastChecked: "2023-11-01T18:30:00Z" }
      ]);
      
      // Mock health stats
      setHealth({
        totalChecked: 387,
        healthy: 372,
        redirects: 12,
        broken: 3,
        lastScanDate: "2023-11-01T18:30:00Z"
      });
    } catch (error) {
      console.error("Error loading stats:", error);
      setError("Failed to load statistics");
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadStats();
  }, [loadStats, timeRange]);

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  const handleTimeRangeChange = (range: 'week' | 'month' | 'year') => {
    setTimeRange(range);
  };

  const handleTriggerScan = async () => {
    try {
      setScanTriggered(true);
      // In a real app, this would call the actual API
      // await triggerHealthScan();
      
      // For now, just show success message
      setTimeout(() => {
        setScanTriggered(false);
        setHealth({
          ...health,
          lastScanDate: new Date().toISOString()
        });
      }, 2000);
    } catch (error) {
      console.error("Error triggering scan:", error);
      setError("Failed to trigger health scan");
      setScanTriggered(false);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (isLoading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', mt: 8 }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ py: 4 }}>
      <Box sx={{ mb: 4, display: 'flex', alignItems: 'center' }}>
        <TrendingUpIcon sx={{ fontSize: 32, mr: 2 }} />
        <Typography variant="h4" component="h1">
          Statistics & Analytics
        </Typography>
      </Box>

      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}

      <Tabs 
        value={tabValue} 
        onChange={handleTabChange} 
        aria-label="stats dashboard tabs"
        sx={{ borderBottom: 1, borderColor: 'divider' }}
      >
        <Tab label="Overview" />
        <Tab label="Usage Analytics" />
        <Tab label="Bookmark Health" />
      </Tabs>

      <TabPanel value={tabValue} index={0}>
        {stats && (
          <>
            {/* Stats Cards */}
            <Grid container spacing={3}>
              <Grid item xs={12} sm={6} md={3}>
                <Card>
                  <CardContent sx={{ display: 'flex', alignItems: 'center' }}>
                    <BookmarkIcon sx={{ fontSize: 40, color: 'primary.main', mr: 2 }} />
                    <Box>
                      <Typography variant="h4" component="div">
                        {stats.totalBookmarks}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        Total Bookmarks
                      </Typography>
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
              
              <Grid item xs={12} sm={6} md={3}>
                <Card>
                  <CardContent sx={{ display: 'flex', alignItems: 'center' }}>
                    <FolderIcon sx={{ fontSize: 40, color: 'primary.main', mr: 2 }} />
                    <Box>
                      <Typography variant="h4" component="div">
                        {stats.totalCollections}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        Collections
                      </Typography>
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
              
              <Grid item xs={12} sm={6} md={3}>
                <Card>
                  <CardContent sx={{ display: 'flex', alignItems: 'center' }}>
                    <TagIcon sx={{ fontSize: 40, color: 'primary.main', mr: 2 }} />
                    <Box>
                      <Typography variant="h4" component="div">
                        {stats.totalTags}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        Tags
                      </Typography>
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
              
              <Grid item xs={12} sm={6} md={3}>
                <Card>
                  <CardContent sx={{ display: 'flex', alignItems: 'center' }}>
                    <BookmarkIcon sx={{ fontSize: 40, color: 'primary.main', mr: 2 }} />
                    <Box>
                      <Typography variant="h4" component="div">
                        {stats.bookmarksAddedThisWeek}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        Added This Week
                      </Typography>
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
            </Grid>

            {/* Popular Tags & Domains */}
            <Grid container spacing={3} sx={{ mt: 1 }}>
              <Grid item xs={12} md={6}>
                <Card sx={{ height: '100%' }}>
                  <CardHeader title="Most Used Tags" />
                  <Divider />
                  <CardContent>
                    <List dense>
                      {stats.mostUsedTags.map((tag) => (
                        <ListItem key={tag.id}>
                          <ListItemText primary={tag.name} />
                          <ListItemSecondaryAction>
                            <Chip 
                              label={tag.count} 
                              size="small"
                              color="primary"
                            />
                          </ListItemSecondaryAction>
                        </ListItem>
                      ))}
                    </List>
                  </CardContent>
                </Card>
              </Grid>
              
              <Grid item xs={12} md={6}>
                <Card sx={{ height: '100%' }}>
                  <CardHeader title="Popular Domains" />
                  <Divider />
                  <CardContent>
                    <List dense>
                      {stats.mostPopularDomains.map((domain) => (
                        <ListItem key={domain.domain}>
                          <ListItemText primary={domain.domain} />
                          <ListItemSecondaryAction>
                            <Chip 
                              label={domain.count}
                              size="small"
                              color="primary"
                            />
                          </ListItemSecondaryAction>
                        </ListItem>
                      ))}
                    </List>
                  </CardContent>
                </Card>
              </Grid>
            </Grid>
          </>
        )}
      </TabPanel>

      <TabPanel value={tabValue} index={1}>
        {analytics && (
          <>
            <Box sx={{ mb: 3, display: 'flex', justifyContent: 'flex-end' }}>
              <Button 
                variant={timeRange === 'week' ? 'contained' : 'outlined'}
                size="small"
                onClick={() => handleTimeRangeChange('week')}
                sx={{ mr: 1 }}
              >
                Week
              </Button>
              <Button 
                variant={timeRange === 'month' ? 'contained' : 'outlined'}
                size="small"
                onClick={() => handleTimeRangeChange('month')}
                sx={{ mr: 1 }}
              >
                Month
              </Button>
              <Button 
                variant={timeRange === 'year' ? 'contained' : 'outlined'}
                size="small"
                onClick={() => handleTimeRangeChange('year')}
              >
                Year
              </Button>
            </Box>

            <Grid container spacing={3}>
              <Grid item xs={12} md={8}>
                <Card>
                  <CardHeader title="Visit Trend" />
                  <Divider />
                  <CardContent>
                    <BarChart data={analytics.visitTrend} />
                  </CardContent>
                </Card>
              </Grid>
              
              <Grid item xs={12} md={4}>
                <Card>
                  <CardHeader title="Bookmarks by Category" />
                  <Divider />
                  <CardContent>
                    <PieChart data={analytics.bookmarksByCategory} />
                  </CardContent>
                </Card>
              </Grid>
            </Grid>
            
            <Grid container spacing={3} sx={{ mt: 2 }}>
              <Grid item xs={12}>
                <Card>
                  <CardHeader title="Most Visited Bookmarks" />
                  <Divider />
                  <CardContent>
                    <List>
                      {analytics.mostVisitedBookmarks.map((bookmark) => (
                        <ListItem key={bookmark.id}>
                          <ListItemText 
                            primary={bookmark.title}
                            secondary={bookmark.url}
                          />
                          <ListItemSecondaryAction>
                            <Box sx={{ display: 'flex', alignItems: 'center' }}>
                              <Typography variant="body2" color="text.secondary" sx={{ mr: 1 }}>
                                {bookmark.visits} visits
                              </Typography>
                              <Chip 
                                label={`Last: ${formatDate(bookmark.lastVisited)}`}
                                size="small"
                                variant="outlined"
                              />
                            </Box>
                          </ListItemSecondaryAction>
                        </ListItem>
                      ))}
                    </List>
                  </CardContent>
                </Card>
              </Grid>
            </Grid>
          </>
        )}
      </TabPanel>

      <TabPanel value={tabValue} index={2}>
        {health && (
          <>
            <Box sx={{ mb: 3, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <Typography variant="h6">
                Bookmark Health Overview
              </Typography>
              <Box>
                <Button 
                  variant="contained"
                  startIcon={scanTriggered ? <CircularProgress size={20} /> : <RefreshIcon />}
                  onClick={handleTriggerScan}
                  disabled={scanTriggered}
                >
                  {scanTriggered ? 'Scanning...' : 'Scan Now'}
                </Button>
              </Box>
            </Box>
            
            <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
              Last scan: {formatDate(health.lastScanDate)}
            </Typography>

            <Grid container spacing={3}>
              <Grid item xs={12} sm={6} md={3}>
                <Card sx={{ backgroundColor: 'success.light' }}>
                  <CardContent sx={{ display: 'flex', alignItems: 'center' }}>
                    <CheckIcon sx={{ fontSize: 40, color: 'success.main', mr: 2 }} />
                    <Box>
                      <Typography variant="h4" component="div" color="text.primary">
                        {health.healthy}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        Healthy Links
                      </Typography>
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
              
              <Grid item xs={12} sm={6} md={3}>
                <Card sx={{ backgroundColor: 'warning.light' }}>
                  <CardContent sx={{ display: 'flex', alignItems: 'center' }}>
                    <WarningIcon sx={{ fontSize: 40, color: 'warning.main', mr: 2 }} />
                    <Box>
                      <Typography variant="h4" component="div" color="text.primary">
                        {health.redirects}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        Redirects
                      </Typography>
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
              
              <Grid item xs={12} sm={6} md={3}>
                <Card sx={{ backgroundColor: 'error.light' }}>
                  <CardContent sx={{ display: 'flex', alignItems: 'center' }}>
                    <ErrorIcon sx={{ fontSize: 40, color: 'error.main', mr: 2 }} />
                    <Box>
                      <Typography variant="h4" component="div" color="text.primary">
                        {health.broken}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        Broken Links
                      </Typography>
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
              
              <Grid item xs={12} sm={6} md={3}>
                <Card>
                  <CardContent sx={{ display: 'flex', alignItems: 'center' }}>
                    <BookmarkIcon sx={{ fontSize: 40, color: 'primary.main', mr: 2 }} />
                    <Box>
                      <Typography variant="h4" component="div">
                        {health.totalChecked}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        Total Checked
                      </Typography>
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
            </Grid>
            
            <Card sx={{ mt: 3 }}>
              <CardHeader title="Dead or Redirected Links" />
              <Divider />
              <CardContent>
                {deadLinks.length === 0 ? (
                  <Typography>No dead links found!</Typography>
                ) : (
                  <List>
                    {deadLinks.map((link) => (
                      <ListItem key={link.id}>
                        <ListItemText 
                          primary={link.title}
                          secondary={link.url}
                        />
                        <ListItemSecondaryAction>
                          <Chip 
                            icon={link.statusCode === 404 ? <ErrorIcon /> : <WarningIcon />}
                            label={link.statusCode === 404 ? 'Dead Link' : 'Redirected'}
                            color={link.statusCode === 404 ? 'error' : 'warning'}
                            size="small"
                          />
                        </ListItemSecondaryAction>
                      </ListItem>
                    ))}
                  </List>
                )}
              </CardContent>
            </Card>
          </>
        )}
      </TabPanel>
    </Container>
  );
};

export default StatsDashboardPage;
