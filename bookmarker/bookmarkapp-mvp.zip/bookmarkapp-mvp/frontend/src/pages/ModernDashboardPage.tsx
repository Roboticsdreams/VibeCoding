import React, { useState, useEffect } from 'react';
import { Link as RouterLink } from 'react-router-dom';
import {
  Box,
  Typography,
  Paper,
  Grid,
  Card,
  CardContent,
  CardActions,
  Button,
  Chip,
  TextField,
  InputAdornment,
  IconButton,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Divider,
  Avatar,
  Container,
  Menu,
  MenuItem,
  FormControlLabel,
  Radio,
  RadioGroup,
  FormControl,
  FormLabel
} from '@mui/material';
import {
  Search as SearchIcon,
  Add as AddIcon,
  FolderOpen as FolderIcon,
  Label as TagIcon,
  MoreVert as MoreVertIcon,
  DeleteOutline as DeleteIcon,
  EditOutlined as EditIcon,
  Bookmark as BookmarkIcon,
  Star as StarIcon,
  Link as LinkIcon,
  Circle as CircleIcon,
} from '@mui/icons-material';
import { Bookmark, getBookmarks } from '../services/bookmarkService';
import { Collection, getCollections } from '../services/collectionService';
import { Tag, getTags } from '../services/tagService';

const ModernDashboardPage: React.FC = () => {
  const [quickAccessItems, setQuickAccessItems] = useState<Bookmark[]>([]);
  const [toolItems, setToolItems] = useState<Bookmark[]>([]);
  const [indieItems, setIndieItems] = useState<Bookmark[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [collections, setCollections] = useState<Collection[]>([]);
  const [tags, setTags] = useState<Tag[]>([]);
  
  // Anchor for context menu
  const [menuAnchorEl, setMenuAnchorEl] = useState<null | HTMLElement>(null);
  const [activeBookmarkId, setActiveBookmarkId] = useState<number | null>(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setIsLoading(true);
      
      // Load collections and tags
      const collectionsData = await getCollections();
      const tagsData = await getTags();
      setCollections(collectionsData);
      setTags(tagsData);

      // Load bookmarks
      const bookmarksResponse = await getBookmarks({ page: 1, limit: 50 });
      const allBookmarks = bookmarksResponse.bookmarks || [];
      
      // Filter bookmarks for different sections based on collections or tags
      // This is a simple example - you'd likely have a more sophisticated way to categorize
      const quickAccess = allBookmarks.filter(b => b.isFavorite).slice(0, 10);
      
      // For demo purposes, just splitting the remaining bookmarks
      const remaining = allBookmarks.filter(b => !b.isFavorite);
      const toolBookmarks = remaining.slice(0, Math.min(4, remaining.length));
      const indieBookmarks = remaining.slice(Math.min(4, remaining.length), Math.min(8, remaining.length));
      
      setQuickAccessItems(quickAccess);
      setToolItems(toolBookmarks);
      setIndieItems(indieBookmarks);
    } catch (error) {
      console.error("Error loading dashboard data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleMenuOpen = (event: React.MouseEvent<HTMLElement>, bookmarkId: number) => {
    setMenuAnchorEl(event.currentTarget);
    setActiveBookmarkId(bookmarkId);
  };

  const handleMenuClose = () => {
    setMenuAnchorEl(null);
    setActiveBookmarkId(null);
  };

  // Function to render a bookmark card in the grid
  const renderBookmarkCard = (bookmark: Bookmark) => {
    // Get a color based on the bookmark's ID for the favicon placeholder
    const colors = ['#f44336', '#e91e63', '#9c27b0', '#673ab7', '#3f51b5', '#2196f3', '#03a9f4', '#00bcd4'];
    const colorIndex = bookmark.id % colors.length;
    const bgColor = colors[colorIndex];
    
    return (
      <Box 
        component="a" 
        href={bookmark.url} 
        target="_blank" 
        rel="noopener noreferrer"
        sx={{ 
          textDecoration: 'none', 
          color: 'inherit',
          display: 'flex',
          alignItems: 'center',
          py: 1,
          borderRadius: 1,
          '&:hover': { bgcolor: 'rgba(0,0,0,0.04)' }
        }}
      >
        <Avatar 
          sx={{ 
            bgcolor: bgColor, 
            width: 32, 
            height: 32,
            mr: 2,
            '& .MuiSvgIcon-root': { fontSize: '0.9rem' }
          }}
          src={bookmark.favicon || undefined}
        >
          {!bookmark.favicon && <LinkIcon fontSize="small" />}
        </Avatar>
        <Box sx={{ overflow: 'hidden' }}>
          <Typography
            variant="body2"
            sx={{
              fontWeight: 500,
              whiteSpace: 'nowrap',
              overflow: 'hidden',
              textOverflow: 'ellipsis'
            }}
          >
            {bookmark.title}
          </Typography>
        </Box>
        <Box sx={{ ml: 'auto' }}>
          <IconButton 
            size="small" 
            onClick={(e) => {
              e.preventDefault();
              handleMenuOpen(e, bookmark.id);
            }}
          >
            <MoreVertIcon fontSize="small" />
          </IconButton>
        </Box>
      </Box>
    );
  };

  const renderCategoryCard = (title: string, count: number, items: Bookmark[], icon: React.ReactNode) => {
    return (
      <Paper 
        elevation={0} 
        sx={{ 
          p: 2, 
          borderRadius: 2,
          border: '1px solid',
          borderColor: 'divider',
        }}
      >
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
          <Box sx={{ mr: 1, color: 'primary.main' }}>{icon}</Box>
          <Typography variant="subtitle1" fontWeight="500">{title}</Typography>
          <Chip 
            label={`(${count})`} 
            size="small" 
            sx={{ ml: 1, height: 20, fontSize: '0.7rem' }} 
            variant="outlined" 
          />
          <Box sx={{ ml: 'auto', display: 'flex', gap: 1 }}>
            <IconButton size="small" sx={{ p: 0.5 }}>
              <SearchIcon fontSize="small" />
            </IconButton>
            <IconButton size="small" sx={{ p: 0.5 }}>
              <AddIcon fontSize="small" />
            </IconButton>
          </Box>
        </Box>
        
        <Divider sx={{ my: 1 }} />
        
        <Box sx={{ mt: 1 }}>
          {items.map((item) => (
            <React.Fragment key={item.id}>
              {renderBookmarkCard(item)}
            </React.Fragment>
          ))}
          
          {items.length === 0 && (
            <Typography variant="body2" color="text.secondary" align="center" sx={{ py: 2 }}>
              No bookmarks in this category
            </Typography>
          )}
        </Box>
      </Paper>
    );
  };

  // Render link detector card similar to the screenshot
  const renderLinkDetectorCard = () => {
    return (
      <Paper 
        elevation={0} 
        sx={{ 
          p: 2, 
          borderRadius: 2,
          border: '1px solid',
          borderColor: 'divider',
          mb: 3
        }}
      >
        <Typography variant="subtitle1" fontWeight="500" sx={{ mb: 2 }}>
          Bookmark Link Detector
        </Typography>
        
        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
          Check if the bookmark links are accessible
        </Typography>
        
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2 }}>
          <FormControl fullWidth>
            <FormLabel id="target-folder-label" sx={{ fontSize: '0.875rem', mb: 1 }}>Target Folder:</FormLabel>
            <TextField
              select
              size="small"
              defaultValue="ai"
              fullWidth
              variant="outlined"
            >
              <MenuItem value="ai">ai</MenuItem>
              <MenuItem value="framework">framework</MenuItem>
              <MenuItem value="temp">temp</MenuItem>
            </TextField>
          </FormControl>
          
          <FormControl>
            <FormLabel id="timeout-label" sx={{ fontSize: '0.875rem', mb: 1 }}>Timeout:</FormLabel>
            <RadioGroup
              row
              defaultValue="3s"
              name="timeout-buttons-group"
            >
              <FormControlLabel value="3s" control={<Radio size="small" />} label="3s" />
              <FormControlLabel value="10s" control={<Radio size="small" />} label="10s" />
              <FormControlLabel value="30s" control={<Radio size="small" />} label="30s" />
            </RadioGroup>
          </FormControl>
          
          <Button 
            variant="contained" 
            color="primary"
            sx={{ mt: 3 }}
          >
            Start
          </Button>
        </Box>
      </Paper>
    );
  };

  return (
    <Box sx={{ p: 3 }}>
      {/* Link Detector Tool */}
      {renderLinkDetectorCard()}
      
      {/* Bookmark Categories */}
      <Grid container spacing={3}>
        <Grid item xs={12} md={4}>
          {renderCategoryCard(
            "Quick Access", 
            quickAccessItems.length, 
            quickAccessItems, 
            <StarIcon fontSize="small" />
          )}
        </Grid>
        
        <Grid item xs={12} md={4}>
          {renderCategoryCard(
            "Tool", 
            toolItems.length, 
            toolItems, 
            <BookmarkIcon fontSize="small" />
          )}
        </Grid>
        
        <Grid item xs={12} md={4}>
          {renderCategoryCard(
            "Indie", 
            indieItems.length, 
            indieItems, 
            <CircleIcon fontSize="small" />
          )}
        </Grid>
      </Grid>
      
      {/* Bookmark action menu */}
      <Menu
        anchorEl={menuAnchorEl}
        open={Boolean(menuAnchorEl)}
        onClose={handleMenuClose}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'right',
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'right',
        }}
      >
        <MenuItem onClick={handleMenuClose}>
          <ListItemIcon>
            <EditIcon fontSize="small" />
          </ListItemIcon>
          <ListItemText>Edit</ListItemText>
        </MenuItem>
        <MenuItem onClick={handleMenuClose}>
          <ListItemIcon>
            <DeleteIcon fontSize="small" />
          </ListItemIcon>
          <ListItemText>Delete</ListItemText>
        </MenuItem>
      </Menu>
    </Box>
  );
};

export default ModernDashboardPage;
