import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Button,
  TextField,
  InputAdornment,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  IconButton,
  Fab,
} from '@mui/material';
import { Search as SearchIcon, Add as AddIcon, Close as CloseIcon } from '@mui/icons-material';
import BookmarkList from '../components/bookmarks/BookmarkList';
import BookmarkForm from '../components/bookmarks/BookmarkForm';
import { Bookmark, BookmarkFilters, getBookmarks, createBookmark, updateBookmark, deleteBookmark } from '../services/bookmarkService';
import { Collection, getCollections } from '../services/collectionService';
import { Tag, getTags } from '../services/tagService';
import { BookmarkFormData } from '../components/bookmarks/BookmarkForm';

const BookmarksPage: React.FC = () => {
  const [bookmarks, setBookmarks] = useState<Bookmark[]>([]);
  const [totalPages, setTotalPages] = useState<number>(1);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [filters, setFilters] = useState<BookmarkFilters>({
    page: 1,
    limit: 12,
  });
  
  const [collections, setCollections] = useState<Collection[]>([]);
  const [tags, setTags] = useState<Tag[]>([]);
  
  const [openForm, setOpenForm] = useState<boolean>(false);
  const [editingBookmark, setEditingBookmark] = useState<Bookmark | undefined>(undefined);
  
  const [confirmDelete, setConfirmDelete] = useState<boolean>(false);
  const [bookmarkToDelete, setBookmarkToDelete] = useState<number | null>(null);

  useEffect(() => {
    loadBookmarks();
    loadCollections();
    loadTags();
  }, [filters]);

  const loadBookmarks = async () => {
    try {
      setIsLoading(true);
      const response = await getBookmarks(filters);
      setBookmarks(response.bookmarks);
      setTotalPages(response.totalPages);
      setCurrentPage(response.currentPage);
    } catch (error) {
      console.error('Error loading bookmarks:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const loadCollections = async () => {
    try {
      const data = await getCollections();
      setCollections(data);
    } catch (error) {
      console.error('Error loading collections:', error);
    }
  };

  const loadTags = async () => {
    try {
      const data = await getTags();
      setTags(data);
    } catch (error) {
      console.error('Error loading tags:', error);
    }
  };

  const handleSearchChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(event.target.value);
  };

  const handleSearch = () => {
    setFilters({
      ...filters,
      search: searchTerm,
      page: 1,
    });
  };

  const handlePageChange = (page: number) => {
    setFilters({
      ...filters,
      page,
    });
  };

  const handleAddBookmark = () => {
    setEditingBookmark(undefined);
    setOpenForm(true);
  };

  const handleEditBookmark = (bookmark: Bookmark) => {
    setEditingBookmark(bookmark);
    setOpenForm(true);
  };

  const handleCloseForm = () => {
    setOpenForm(false);
  };

  const handleDeleteBookmark = (bookmarkId: number) => {
    setBookmarkToDelete(bookmarkId);
    setConfirmDelete(true);
  };

  const confirmDeleteBookmark = async () => {
    if (bookmarkToDelete) {
      try {
        await deleteBookmark(bookmarkToDelete);
        loadBookmarks();
      } catch (error) {
        console.error('Error deleting bookmark:', error);
      }
    }
    setConfirmDelete(false);
    setBookmarkToDelete(null);
  };

  const handleToggleFavorite = async (bookmark: Bookmark) => {
    try {
      await updateBookmark(bookmark.id, {
        isFavorite: !bookmark.isFavorite,
      });
      loadBookmarks();
    } catch (error) {
      console.error('Error updating bookmark:', error);
    }
  };

  const handleSubmitBookmark = async (values: BookmarkFormData) => {
    try {
      if (editingBookmark) {
        await updateBookmark(editingBookmark.id, values);
      } else {
        await createBookmark(values);
      }
      setOpenForm(false);
      loadBookmarks();
    } catch (error) {
      console.error('Error saving bookmark:', error);
    }
  };

  return (
    <Box sx={{ p: 3 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
        <Typography variant="h4" component="h1">
          My Bookmarks
        </Typography>
        
        <Box sx={{ display: 'flex', gap: 2 }}>
          <TextField
            placeholder="Search bookmarks..."
            size="small"
            value={searchTerm}
            onChange={handleSearchChange}
            onKeyPress={(e) => {
              if (e.key === 'Enter') {
                handleSearch();
              }
            }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon />
                </InputAdornment>
              ),
            }}
            sx={{ width: 250 }}
          />
          
          <Button
            variant="contained"
            color="primary"
            startIcon={<AddIcon />}
            onClick={handleAddBookmark}
          >
            Add Bookmark
          </Button>
        </Box>
      </Box>

      <BookmarkList
        bookmarks={bookmarks}
        totalPages={totalPages}
        currentPage={currentPage}
        onPageChange={handlePageChange}
        onEdit={handleEditBookmark}
        onDelete={handleDeleteBookmark}
        onToggleFavorite={handleToggleFavorite}
      />
      
      {/* Floating action button for mobile */}
      <Fab
        color="primary"
        aria-label="add"
        sx={{
          position: 'fixed',
          bottom: 16,
          right: 16,
          display: { xs: 'flex', md: 'none' },
        }}
        onClick={handleAddBookmark}
      >
        <AddIcon />
      </Fab>
      
      {/* Add/Edit Bookmark Dialog */}
      <Dialog open={openForm} onClose={handleCloseForm} maxWidth="md" fullWidth>
        <DialogTitle>
          {editingBookmark ? 'Edit Bookmark' : 'Add New Bookmark'}
          <IconButton
            aria-label="close"
            onClick={handleCloseForm}
            sx={{
              position: 'absolute',
              right: 8,
              top: 8,
            }}
          >
            <CloseIcon />
          </IconButton>
        </DialogTitle>
        <DialogContent>
          <BookmarkForm
            bookmark={editingBookmark}
            collections={collections}
            tags={tags}
            onSubmit={handleSubmitBookmark}
            onCancel={handleCloseForm}
          />
        </DialogContent>
      </Dialog>
      
      {/* Delete Confirmation Dialog */}
      <Dialog open={confirmDelete} onClose={() => setConfirmDelete(false)}>
        <DialogTitle>Confirm Deletion</DialogTitle>
        <DialogContent>
          <Typography>
            Are you sure you want to delete this bookmark? This action cannot be undone.
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setConfirmDelete(false)}>Cancel</Button>
          <Button onClick={confirmDeleteBookmark} color="error">
            Delete
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default BookmarksPage;
