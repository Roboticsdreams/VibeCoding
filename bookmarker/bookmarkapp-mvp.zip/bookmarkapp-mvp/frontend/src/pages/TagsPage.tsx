import React, { useState, useEffect, useCallback } from 'react';
import {
  Box,
  Typography,
  Grid,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  Divider,
} from '@mui/material';
import { Add as AddIcon } from '@mui/icons-material';
import TagList from '../components/tags/TagList';
import TagForm, { TagFormData } from '../components/tags/TagForm';
import {
  Tag,
  getTags,
  createTag,
  updateTag,
  deleteTag,
} from '../services/tagService';
import { getBookmarks, BookmarkFilters, Bookmark } from '../services/bookmarkService';
import BookmarkList from '../components/bookmarks/BookmarkList';

const TagsPage: React.FC = () => {
  const [tags, setTags] = useState<Tag[]>([]);
  const [selectedTagId, setSelectedTagId] = useState<number | null>(null);
  const [bookmarks, setBookmarks] = useState<Bookmark[]>([]);
  const [totalPages, setTotalPages] = useState<number>(1);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [openForm, setOpenForm] = useState<boolean>(false);
  const [editingTag, setEditingTag] = useState<Tag | undefined>(undefined);
  const [confirmDelete, setConfirmDelete] = useState<boolean>(false);
  const [tagToDelete, setTagToDelete] = useState<number | null>(null);

  const loadBookmarks = useCallback(async () => {
    try {
      setIsLoading(true);
      const filters: BookmarkFilters = {
        page: currentPage,
        limit: 12,
      };
      
      if (selectedTagId) {
        filters.tagId = selectedTagId;
      }
      
      const response = await getBookmarks(filters);
      setBookmarks(response.bookmarks);
      setTotalPages(response.totalPages);
      setCurrentPage(response.currentPage);
    } catch (error) {
      console.error('Error loading bookmarks:', error);
    } finally {
      setIsLoading(false);
    }
  }, [currentPage, selectedTagId]);

  useEffect(() => {
    loadTags();
  }, []);

  useEffect(() => {
    if (selectedTagId !== undefined) {
      loadBookmarks();
    }
  }, [selectedTagId, currentPage, loadBookmarks]);

  const loadTags = async () => {
    try {
      const data = await getTags();
      setTags(data);
    } catch (error) {
      console.error('Error loading tags:', error);
    }
  };

  const handleSelectTag = (tagId: number | null) => {
    setSelectedTagId(tagId);
    setCurrentPage(1);
  };

  const handleAddTag = () => {
    setEditingTag(undefined);
    setOpenForm(true);
  };

  const handleEditTag = (tag: Tag) => {
    setEditingTag(tag);
    setOpenForm(true);
  };

  const handleDeleteTag = (tagId: number) => {
    setTagToDelete(tagId);
    setConfirmDelete(true);
  };

  const confirmDeleteTag = async () => {
    if (tagToDelete) {
      try {
        await deleteTag(tagToDelete);
        await loadTags();
        if (selectedTagId === tagToDelete) {
          setSelectedTagId(null);
        }
      } catch (error) {
        console.error('Error deleting tag:', error);
      }
    }
    setConfirmDelete(false);
    setTagToDelete(null);
  };

  const handleCloseForm = () => {
    setOpenForm(false);
  };

  const handleSubmitTag = async (values: TagFormData) => {
    try {
      if (editingTag) {
        await updateTag(editingTag.id, values.name);
      } else {
        await createTag(values.name);
      }
      await loadTags();
      setOpenForm(false);
    } catch (error) {
      console.error('Error saving tag:', error);
    }
  };

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };

  const handleEditBookmark = (bookmark: Bookmark) => {
    // Implement bookmark editing logic
    console.log("Edit bookmark:", bookmark);
  };

  const handleDeleteBookmark = (bookmarkId: number) => {
    // Implement bookmark deletion logic
    console.log("Delete bookmark:", bookmarkId);
  };

  const handleToggleFavorite = (bookmark: Bookmark) => {
    // Implement toggle favorite logic
    console.log("Toggle favorite:", bookmark);
  };

  return (
    <Box sx={{ p: 3, height: '100%' }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h4" component="h1">
          Tags
        </Typography>
        <Button
          variant="contained"
          color="primary"
          startIcon={<AddIcon />}
          onClick={handleAddTag}
        >
          New Tag
        </Button>
      </Box>

      <Grid container spacing={3} sx={{ height: 'calc(100% - 60px)' }}>
        <Grid item xs={12} md={3}>
          <TagList
            tags={tags}
            selectedTagId={selectedTagId}
            onSelectTag={handleSelectTag}
            onAddTag={handleAddTag}
            onEditTag={handleEditTag}
            onDeleteTag={handleDeleteTag}
          />
        </Grid>
        <Grid item xs={12} md={9}>
          <Box>
            <Typography variant="h5" component="h2" gutterBottom>
              {selectedTagId
                ? tags.find(t => t.id === selectedTagId)?.name || 'Tag'
                : 'All Bookmarks'}
            </Typography>
            <Divider sx={{ mb: 2 }} />
            {isLoading ? (
              <Typography>Loading bookmarks...</Typography>
            ) : (
              <BookmarkList
                bookmarks={bookmarks}
                totalPages={totalPages}
                currentPage={currentPage}
                onPageChange={handlePageChange}
                onEdit={handleEditBookmark}
                onDelete={handleDeleteBookmark}
                onToggleFavorite={handleToggleFavorite}
              />
            )}
          </Box>
        </Grid>
      </Grid>

      <TagForm
        open={openForm}
        tag={editingTag}
        onClose={handleCloseForm}
        onSubmit={handleSubmitTag}
      />

      <Dialog open={confirmDelete} onClose={() => setConfirmDelete(false)}>
        <DialogTitle>Confirm Deletion</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Are you sure you want to delete this tag? Bookmarks will not be deleted, but they will no longer be associated with this tag.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setConfirmDelete(false)}>Cancel</Button>
          <Button onClick={confirmDeleteTag} color="error">
            Delete
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default TagsPage;
