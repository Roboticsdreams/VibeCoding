import React, { useState, useEffect, useCallback } from 'react';
import {
  Box,
  Typography,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Container,
  CircularProgress,
} from '@mui/material';
import {
  ExpandMore as ExpandMoreIcon,
  Search as SearchIcon,
} from '@mui/icons-material';
import { useLocation } from 'react-router-dom';
import { getBookmarks, BookmarkFilters, BookmarkResponse, Bookmark } from '../services/bookmarkService';
import { getCollections, Collection } from '../services/collectionService';
import { getTags, Tag } from '../services/tagService';
import BookmarkList from '../components/bookmarks/BookmarkList';
import AdvancedSearchForm, { AdvancedSearchFilters } from '../components/search/AdvancedSearchForm';

const SearchPage: React.FC = () => {
  const location = useLocation();
  const [searchResults, setSearchResults] = useState<BookmarkResponse | null>(null);
  const [collections, setCollections] = useState<Collection[]>([]);
  const [tags, setTags] = useState<Tag[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [searchExpanded, setSearchExpanded] = useState<boolean>(true);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [filters, setFilters] = useState<AdvancedSearchFilters>({});

  const handleSearch = useCallback(async (searchFilters: AdvancedSearchFilters) => {
    try {
      setIsLoading(true);
      setFilters(searchFilters);
      
      const apiFilters: BookmarkFilters = {
        search: searchFilters.search,
        favorite: searchFilters.favorite,
        collectionId: searchFilters.collectionId,
        tagId: searchFilters.tagIds && searchFilters.tagIds.length > 0 ? searchFilters.tagIds[0] : undefined,
        page: currentPage,
        limit: 12
      };
      
      const response = await getBookmarks(apiFilters);
      setSearchResults(response);
      setSearchExpanded(false);
    } catch (error) {
      console.error('Error searching bookmarks:', error);
    } finally {
      setIsLoading(false);
    }
  }, [currentPage]);

  // Parse query params from URL
  useEffect(() => {
    const searchParams = new URLSearchParams(location.search);
    const initialFilters: AdvancedSearchFilters = {};
    
    if (searchParams.has('search')) {
      initialFilters.search = searchParams.get('search') || undefined;
    }
    
    if (searchParams.has('favorite')) {
      initialFilters.favorite = searchParams.get('favorite') === 'true';
    }
    
    if (searchParams.has('collectionId')) {
      const collectionId = parseInt(searchParams.get('collectionId') || '0');
      if (collectionId > 0) {
        initialFilters.collectionId = collectionId;
      }
    }
    
    if (searchParams.has('tagIds')) {
      const tagIdsStr = searchParams.get('tagIds');
      if (tagIdsStr) {
        initialFilters.tagIds = tagIdsStr.split(',').map(id => parseInt(id));
      }
    }
    
    setFilters(initialFilters);
    setCurrentPage(parseInt(searchParams.get('page') || '1'));
  }, [location.search]);

  const fetchData = useCallback(async () => {
    try {
      const [collectionsData, tagsData] = await Promise.all([
        getCollections(),
        getTags()
      ]);
      
      setCollections(collectionsData);
      setTags(tagsData);
    } catch (error) {
      console.error('Error loading data:', error);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  useEffect(() => {
    handleSearch(filters);
  }, [currentPage, filters, handleSearch]);

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };

  const handleEditBookmark = (bookmark: Bookmark) => {
    // Implement bookmark editing logic
    console.log("Edit bookmark:", bookmark);
  };

  const handleDeleteBookmark = (bookmarkId: number) => {
    // Implement bookmark deletion logic
    console.log("Delete bookmark:", bookmarkId);
  };

  const handleToggleFavorite = (bookmark: Bookmark) => {
    // Implement toggle favorite logic
    console.log("Toggle favorite:", bookmark);
  };

  return (
    <Container maxWidth="lg" sx={{ py: 4 }}>
      <Typography variant="h4" component="h1" gutterBottom sx={{ display: 'flex', alignItems: 'center' }}>
        <SearchIcon sx={{ mr: 1 }} /> Advanced Search
      </Typography>
      
      <Accordion 
        expanded={searchExpanded} 
        onChange={() => setSearchExpanded(!searchExpanded)}
      >
        <AccordionSummary expandIcon={<ExpandMoreIcon />}>
          <Typography>Search Options</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <AdvancedSearchForm 
            collections={collections}
            tags={tags}
            onSearch={handleSearch}
            initialFilters={filters}
          />
        </AccordionDetails>
      </Accordion>
      
      <Box sx={{ mt: 3 }}>
        {isLoading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', mt: 5 }}>
            <CircularProgress />
          </Box>
        ) : searchResults ? (
          <>
            <Box sx={{ mb: 2 }}>
              <Typography variant="h6">
                {searchResults.count === 0 ? 'No results found' : `Found ${searchResults.count} result(s)`}
              </Typography>
            </Box>
            
            <BookmarkList
              bookmarks={searchResults.bookmarks}
              totalPages={searchResults.totalPages}
              currentPage={currentPage}
              onPageChange={handlePageChange}
              onEdit={handleEditBookmark}
              onDelete={handleDeleteBookmark}
              onToggleFavorite={handleToggleFavorite}
            />
          </>
        ) : (
          <Typography variant="body1" sx={{ textAlign: 'center', mt: 5 }}>
            Use the search options above to find bookmarks.
          </Typography>
        )}
      </Box>
    </Container>
  );
};

export default SearchPage;
