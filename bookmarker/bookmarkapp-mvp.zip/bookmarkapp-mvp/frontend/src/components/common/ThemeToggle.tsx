import React from 'react';
import { IconButton, Tooltip } from '@mui/material';
import { Brightness4 as DarkIcon, Brightness7 as LightIcon } from '@mui/icons-material';
import { useTheme } from '../../context/ThemeContext';

interface ThemeToggleProps {
  iconOnly?: boolean;
}

const ThemeToggle: React.FC<ThemeToggleProps> = ({ iconOnly = false }) => {
  const { mode, toggleThemeMode } = useTheme();
  const isDark = mode === 'dark';

  return (
    <Tooltip title={isDark ? 'Switch to Light Mode' : 'Switch to Dark Mode'}>
      <IconButton
        onClick={toggleThemeMode}
        color="inherit"
        aria-label="toggle dark/light mode"
        edge="end"
        size={iconOnly ? 'medium' : 'large'}
        sx={iconOnly ? {} : { mr: 1 }}
      >
        {isDark ? <LightIcon /> : <DarkIcon />}
      </IconButton>
    </Tooltip>
  );
};

export default ThemeToggle;
