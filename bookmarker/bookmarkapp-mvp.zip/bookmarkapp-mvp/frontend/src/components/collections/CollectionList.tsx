import React from 'react';
import {
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Typography,
  IconButton,
  Box,
  Paper,
} from '@mui/material';
import {
  Folder as FolderIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Add as AddIcon,
} from '@mui/icons-material';
import { Collection } from '../../services/collectionService';

interface CollectionListProps {
  collections: Collection[];
  selectedCollectionId: number | null;
  onSelectCollection: (collectionId: number | null) => void;
  onAddCollection: () => void;
  onEditCollection: (collection: Collection) => void;
  onDeleteCollection: (collectionId: number) => void;
}

const CollectionList: React.FC<CollectionListProps> = ({
  collections,
  selectedCollectionId,
  onSelectCollection,
  onAddCollection,
  onEditCollection,
  onDeleteCollection,
}) => {
  return (
    <Paper elevation={0} sx={{ height: '100%', bgcolor: 'background.default' }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', p: 2, pb: 1 }}>
        <Typography variant="h6" component="h2">
          Collections
        </Typography>
        <IconButton
          size="small"
          color="primary"
          onClick={onAddCollection}
          aria-label="Add collection"
        >
          <AddIcon />
        </IconButton>
      </Box>
      
      <List sx={{ pt: 0 }}>
        <ListItemButton 
          selected={selectedCollectionId === null}
          onClick={() => onSelectCollection(null)}
        >
          <ListItemIcon>
            <FolderIcon color="primary" />
          </ListItemIcon>
          <ListItemText primary="All Bookmarks" />
        </ListItemButton>
        
        {collections.map((collection) => (
          <ListItem
            key={collection.id}
            secondaryAction={
              <Box>
                <IconButton 
                  edge="end" 
                  aria-label="edit" 
                  onClick={(e) => {
                    e.stopPropagation();
                    onEditCollection(collection);
                  }}
                  size="small"
                >
                  <EditIcon fontSize="small" />
                </IconButton>
                <IconButton 
                  edge="end" 
                  aria-label="delete" 
                  onClick={(e) => {
                    e.stopPropagation();
                    onDeleteCollection(collection.id);
                  }}
                  size="small"
                >
                  <DeleteIcon fontSize="small" />
                </IconButton>
              </Box>
            }
            disablePadding
          >
            <ListItemButton
              selected={selectedCollectionId === collection.id}
              onClick={() => onSelectCollection(collection.id)}
            >
              <ListItemIcon>
                <FolderIcon style={{ color: collection.color || '#1976d2' }} />
              </ListItemIcon>
              <ListItemText primary={collection.name} />
            </ListItemButton>
          </ListItem>
        ))}
      </List>
    </Paper>
  );
};

export default CollectionList;
