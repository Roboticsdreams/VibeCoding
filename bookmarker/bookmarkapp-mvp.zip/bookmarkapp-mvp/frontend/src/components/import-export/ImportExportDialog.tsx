import React, { useState, useRef } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Tabs,
  Tab,
  Box,
  Typography,
  CircularProgress,
  Alert,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  FormGroup,
  FormControlLabel,
  Checkbox,
  RadioGroup,
  Radio,
  Paper,
} from '@mui/material';
import {
  FileUpload as FileUploadIcon,
  FileDownload as FileDownloadIcon,
  Close as CloseIcon,
} from '@mui/icons-material';

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

const TabPanel = (props: TabPanelProps) => {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`import-export-tabpanel-${index}`}
      aria-labelledby={`import-export-tab-${index}`}
      {...other}
    >
      {value === index && <Box sx={{ p: 3 }}>{children}</Box>}
    </div>
  );
};

interface ImportExportDialogProps {
  open: boolean;
  onClose: () => void;
  onImport: (file: File, options: ImportOptions) => Promise<void>;
  onExport: (format: string, options: ExportOptions) => Promise<void>;
}

export interface ImportOptions {
  importMode: 'merge' | 'replace';
  defaultCollectionId?: number;
}

export interface ExportOptions {
  includeCollections: boolean;
  includeTags: boolean;
  includeNotes: boolean;
  collectionId?: number;
  format: 'html' | 'json' | 'csv';
}

const ImportExportDialog: React.FC<ImportExportDialogProps> = ({
  open,
  onClose,
  onImport,
  onExport,
}) => {
  const [tabValue, setTabValue] = useState(0);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [importOptions, setImportOptions] = useState<ImportOptions>({
    importMode: 'merge',
  });
  const [exportOptions, setExportOptions] = useState<ExportOptions>({
    includeCollections: true,
    includeTags: true,
    includeNotes: true,
    format: 'html',
  });
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
    // Reset state when changing tabs
    setSelectedFile(null);
    setError(null);
    setSuccess(null);
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files.length > 0) {
      setSelectedFile(event.target.files[0]);
      setError(null);
    }
  };

  const handleImportOptionChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = event.target;
    setImportOptions({
      ...importOptions,
      [name]: value,
    });
  };

  const handleExportOptionChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked, value, type } = event.target;
    setExportOptions({
      ...exportOptions,
      [name]: type === 'checkbox' ? checked : value,
    });
  };

  const handleImport = async () => {
    if (!selectedFile) {
      setError('Please select a file to import');
      return;
    }

    try {
      setLoading(true);
      setError(null);
      await onImport(selectedFile, importOptions);
      setSuccess('Import completed successfully!');
      setSelectedFile(null);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    } catch (err: any) {
      setError(err.message || 'An error occurred during import');
    } finally {
      setLoading(false);
    }
  };

  const handleExport = async () => {
    try {
      setLoading(true);
      setError(null);
      await onExport(exportOptions.format, exportOptions);
      setSuccess('Export completed successfully!');
    } catch (err: any) {
      setError(err.message || 'An error occurred during export');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle>
        Import / Export Bookmarks
        <Button
          onClick={onClose}
          sx={{ position: 'absolute', right: 8, top: 8 }}
          color="inherit"
        >
          <CloseIcon />
        </Button>
      </DialogTitle>

      <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
        <Tabs 
          value={tabValue} 
          onChange={handleTabChange} 
          aria-label="import-export tabs"
          variant="fullWidth"
        >
          <Tab 
            label="Import" 
            icon={<FileUploadIcon />} 
            iconPosition="start" 
          />
          <Tab 
            label="Export" 
            icon={<FileDownloadIcon />} 
            iconPosition="start" 
          />
        </Tabs>
      </Box>

      <DialogContent sx={{ minHeight: '400px' }}>
        {error && (
          <Alert severity="error" sx={{ mb: 2 }}>
            {error}
          </Alert>
        )}

        {success && (
          <Alert severity="success" sx={{ mb: 2 }}>
            {success}
          </Alert>
        )}

        <TabPanel value={tabValue} index={0}>
          <Typography variant="h6" gutterBottom>
            Import Bookmarks
          </Typography>
          <Typography variant="body2" color="text.secondary" paragraph>
            Import bookmarks from HTML files exported from browsers or other bookmark services,
            or from JSON or CSV files exported from BookMark App.
          </Typography>

          <Box sx={{ mt: 3 }}>
            <Paper variant="outlined" sx={{ p: 3, textAlign: 'center', mb: 3 }}>
              <input
                type="file"
                accept=".html,.htm,.json,.csv"
                id="import-file"
                ref={fileInputRef}
                style={{ display: 'none' }}
                onChange={handleFileChange}
              />
              <Button
                variant="contained"
                component="label"
                htmlFor="import-file"
                startIcon={<FileUploadIcon />}
                onClick={() => fileInputRef.current?.click()}
              >
                Select File
              </Button>
              <Typography variant="body2" sx={{ mt: 1 }}>
                {selectedFile ? `Selected: ${selectedFile.name}` : 'No file selected'}
              </Typography>
            </Paper>

            <Box sx={{ mt: 3 }}>
              <Typography variant="subtitle1" gutterBottom>
                Import Options
              </Typography>
              
              <FormControl component="fieldset">
                <RadioGroup
                  name="importMode"
                  value={importOptions.importMode}
                  onChange={handleImportOptionChange}
                >
                  <FormControlLabel
                    value="merge"
                    control={<Radio />}
                    label="Merge with existing bookmarks (skip duplicates)"
                  />
                  <FormControlLabel
                    value="replace"
                    control={<Radio />}
                    label="Replace existing bookmarks (warning: this will delete all current bookmarks)"
                  />
                </RadioGroup>
              </FormControl>
            </Box>
          </Box>
        </TabPanel>

        <TabPanel value={tabValue} index={1}>
          <Typography variant="h6" gutterBottom>
            Export Bookmarks
          </Typography>
          <Typography variant="body2" color="text.secondary" paragraph>
            Export your bookmarks to various formats for backup or to import into other services.
          </Typography>

          <Box sx={{ mt: 3 }}>
            <FormControl component="fieldset" fullWidth sx={{ mb: 3 }}>
              <InputLabel id="export-format-label">Export Format</InputLabel>
              <Select
                labelId="export-format-label"
                name="format"
                value={exportOptions.format}
                label="Export Format"
                onChange={(e) => {
                  setExportOptions({
                    ...exportOptions,
                    format: e.target.value as 'html' | 'json' | 'csv',
                  });
                }}
              >
                <MenuItem value="html">HTML (Browser Compatible)</MenuItem>
                <MenuItem value="json">JSON (BookMark App Format)</MenuItem>
                <MenuItem value="csv">CSV (Spreadsheet Compatible)</MenuItem>
              </Select>
            </FormControl>

            <Typography variant="subtitle1" gutterBottom>
              Export Options
            </Typography>

            <FormGroup>
              <FormControlLabel
                control={
                  <Checkbox
                    name="includeCollections"
                    checked={exportOptions.includeCollections}
                    onChange={handleExportOptionChange}
                  />
                }
                label="Include Collection Structure"
              />
              <FormControlLabel
                control={
                  <Checkbox
                    name="includeTags"
                    checked={exportOptions.includeTags}
                    onChange={handleExportOptionChange}
                  />
                }
                label="Include Tags"
              />
              <FormControlLabel
                control={
                  <Checkbox
                    name="includeNotes"
                    checked={exportOptions.includeNotes}
                    onChange={handleExportOptionChange}
                  />
                }
                label="Include Notes"
              />
            </FormGroup>
          </Box>
        </TabPanel>
      </DialogContent>

      <DialogActions sx={{ px: 3, pb: 2 }}>
        <Button onClick={onClose} color="inherit" disabled={loading}>
          Cancel
        </Button>
        <Button
          onClick={tabValue === 0 ? handleImport : handleExport}
          color="primary"
          variant="contained"
          disabled={loading || (tabValue === 0 && !selectedFile)}
          startIcon={loading ? <CircularProgress size={20} /> : tabValue === 0 ? <FileUploadIcon /> : <FileDownloadIcon />}
        >
          {loading ? 'Processing...' : tabValue === 0 ? 'Import' : 'Export'}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default ImportExportDialog;
