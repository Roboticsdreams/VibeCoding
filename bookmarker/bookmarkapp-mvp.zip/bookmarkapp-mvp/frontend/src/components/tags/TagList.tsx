import React from 'react';
import {
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Typography,
  IconButton,
  Box,
  Paper,
  Chip,
} from '@mui/material';
import {
  Tag as TagIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Add as AddIcon,
} from '@mui/icons-material';
import { Tag } from '../../services/tagService';

interface TagListProps {
  tags: Tag[];
  selectedTagId: number | null;
  onSelectTag: (tagId: number | null) => void;
  onAddTag: () => void;
  onEditTag: (tag: Tag) => void;
  onDeleteTag: (tagId: number) => void;
}

const getTagColor = (name: string): string => {
  // Simple hash function to generate consistent colors for tags
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = name.charCodeAt(i) + ((hash << 5) - hash);
  }
  const hue = Math.abs(hash % 360);
  return `hsl(${hue}, 70%, 65%)`;
};

const TagList: React.FC<TagListProps> = ({
  tags,
  selectedTagId,
  onSelectTag,
  onAddTag,
  onEditTag,
  onDeleteTag,
}) => {
  return (
    <Paper elevation={0} sx={{ height: '100%', bgcolor: 'background.default' }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', p: 2, pb: 1 }}>
        <Typography variant="h6" component="h2">
          Tags
        </Typography>
        <IconButton
          size="small"
          color="primary"
          onClick={onAddTag}
          aria-label="Add tag"
        >
          <AddIcon />
        </IconButton>
      </Box>
      
      <List sx={{ pt: 0 }}>
        <ListItemButton 
          selected={selectedTagId === null}
          onClick={() => onSelectTag(null)}
        >
          <ListItemIcon>
            <TagIcon color="primary" />
          </ListItemIcon>
          <ListItemText primary="All Tags" />
        </ListItemButton>
        
        {tags.map((tag) => (
          <ListItem
            key={tag.id}
            secondaryAction={
              <Box>
                <IconButton 
                  edge="end" 
                  aria-label="edit" 
                  onClick={(e) => {
                    e.stopPropagation();
                    onEditTag(tag);
                  }}
                  size="small"
                >
                  <EditIcon fontSize="small" />
                </IconButton>
                <IconButton 
                  edge="end" 
                  aria-label="delete" 
                  onClick={(e) => {
                    e.stopPropagation();
                    onDeleteTag(tag.id);
                  }}
                  size="small"
                >
                  <DeleteIcon fontSize="small" />
                </IconButton>
              </Box>
            }
            disablePadding
          >
            <ListItemButton
              selected={selectedTagId === tag.id}
              onClick={() => onSelectTag(tag.id)}
            >
              <ListItemIcon>
                <Chip 
                  label={tag.name} 
                  size="small" 
                  sx={{ 
                    bgcolor: getTagColor(tag.name),
                    color: '#fff', 
                    fontWeight: 'bold'
                  }} 
                />
              </ListItemIcon>
              <ListItemText primary={tag.name} />
            </ListItemButton>
          </ListItem>
        ))}
      </List>
    </Paper>
  );
};

export default TagList;
