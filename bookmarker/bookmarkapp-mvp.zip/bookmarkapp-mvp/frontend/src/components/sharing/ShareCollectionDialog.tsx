import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Box,
  Typography,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  FormGroup,
  FormControlLabel,
  Switch,
  Chip,
  IconButton,
  Tabs,
  Tab,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  CircularProgress,
  Divider,
  Alert,
  Tooltip,
} from '@mui/material';
import {
  Share as ShareIcon,
  ContentCopy as CopyIcon,
  Add as AddIcon,
  Delete as DeleteIcon,
  Close as CloseIcon,
  Edit as EditIcon,
  PersonAdd as PersonAddIcon,
} from '@mui/icons-material';
import { Collection } from '../../services/collectionService';

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

const TabPanel = (props: TabPanelProps) => {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`share-tabpanel-${index}`}
      aria-labelledby={`share-tab-${index}`}
      {...other}
    >
      {value === index && <Box sx={{ p: 1 }}>{children}</Box>}
    </div>
  );
};

export interface SharedUser {
  id: number;
  email: string;
  firstName?: string;
  lastName?: string;
  role: 'viewer' | 'editor' | 'admin';
  dateAdded: string;
}

interface ShareCollectionDialogProps {
  open: boolean;
  collection: Collection | null;
  onClose: () => void;
  onUpdateSharing: (
    collectionId: number, 
    isPublic: boolean, 
    publicLink?: string,
    sharedUsers?: SharedUser[]
  ) => Promise<void>;
  onShareWithUser: (collectionId: number, email: string, role: string) => Promise<void>;
  onRemoveSharedUser: (collectionId: number, userId: number) => Promise<void>;
  onUpdateUserRole: (collectionId: number, userId: number, role: string) => Promise<void>;
}

const ShareCollectionDialog: React.FC<ShareCollectionDialogProps> = ({
  open,
  collection,
  onClose,
  onUpdateSharing,
  onShareWithUser,
  onRemoveSharedUser,
  onUpdateUserRole,
}) => {
  const [tabValue, setTabValue] = useState(0);
  const [isPublic, setIsPublic] = useState(false);
  const [publicLink, setPublicLink] = useState<string>('');
  const [sharedUsers, setSharedUsers] = useState<SharedUser[]>([]);
  const [email, setEmail] = useState('');
  const [role, setRole] = useState('viewer');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [linkCopied, setLinkCopied] = useState(false);

  useEffect(() => {
    if (collection) {
      setIsPublic(collection.isPublic || false);
      
      // In a real app, you would fetch this data from the API
      // For now we're mocking it
      setPublicLink(collection.isPublic 
        ? `${window.location.origin}/shared/collection/${collection.id}` 
        : '');
        
      // Mocked shared users - in a real app, fetch from API
      setSharedUsers([
        {
          id: 1,
          email: 'user1@example.com',
          firstName: 'John',
          lastName: 'Doe',
          role: 'editor' as const,
          dateAdded: '2023-10-15T12:00:00Z',
        },
        {
          id: 2,
          email: 'user2@example.com',
          firstName: 'Jane',
          lastName: 'Smith',
          role: 'viewer' as const,
          dateAdded: '2023-11-01T09:30:00Z',
        },
      ]);
    }
  }, [collection]);

  useEffect(() => {
    if (open) {
      setTabValue(0);
      setError(null);
      setSuccessMessage(null);
      setLinkCopied(false);
      setEmail('');
    }
  }, [open]);

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  const handleTogglePublic = async () => {
    if (!collection) return;
    
    setIsLoading(true);
    setError(null);
    setSuccessMessage(null);
    
    try {
      const newIsPublic = !isPublic;
      let newPublicLink = publicLink;
      
      if (newIsPublic && !publicLink) {
        // In a real app, the API would generate this link
        newPublicLink = `${window.location.origin}/shared/collection/${collection.id}`;
      }
      
      await onUpdateSharing(collection.id, newIsPublic, newPublicLink, sharedUsers);
      
      setIsPublic(newIsPublic);
      setPublicLink(newPublicLink);
      setSuccessMessage(newIsPublic 
        ? 'Collection is now publicly accessible via link'
        : 'Collection is now private');
    } catch (error: any) {
      setError(error.message || 'Failed to update sharing settings');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(publicLink);
    setLinkCopied(true);
    setTimeout(() => setLinkCopied(false), 2000);
  };

  const handleShareWithUser = async () => {
    if (!collection || !email.trim()) return;
    
    setIsLoading(true);
    setError(null);
    setSuccessMessage(null);
    
    try {
      await onShareWithUser(collection.id, email, role);
      
      // In a real app, you would fetch the updated list
      // For now, we'll just add a mocked user
      const newUser: SharedUser = {
        id: Math.floor(Math.random() * 1000),
        email: email,
        role: role as 'viewer' | 'editor' | 'admin',
        dateAdded: new Date().toISOString(),
      };
      
      setSharedUsers([...sharedUsers, newUser]);
      setEmail('');
      setSuccessMessage(`Collection shared with ${email}`);
    } catch (error: any) {
      setError(error.message || 'Failed to share with user');
    } finally {
      setIsLoading(false);
    }
  };

  const handleRemoveUser = async (userId: number) => {
    if (!collection) return;
    
    setIsLoading(true);
    setError(null);
    
    try {
      await onRemoveSharedUser(collection.id, userId);
      
      // Filter out the removed user
      setSharedUsers(sharedUsers.filter(user => user.id !== userId));
      setSuccessMessage('User removed from shared collection');
    } catch (error: any) {
      setError(error.message || 'Failed to remove user');
    } finally {
      setIsLoading(false);
    }
  };

  const handleUpdateRole = async (userId: number, newRole: string) => {
    if (!collection) return;
    
    setIsLoading(true);
    setError(null);
    
    try {
      await onUpdateUserRole(collection.id, userId, newRole);
      
      // Update the user's role in the local state
      setSharedUsers(sharedUsers.map(user => {
        if (user.id === userId) {
          return { ...user, role: newRole as 'viewer' | 'editor' | 'admin' };
        }
        return user;
      }));
      setSuccessMessage('User role updated');
    } catch (error: any) {
      setError(error.message || 'Failed to update user role');
    } finally {
      setIsLoading(false);
    }
  };

  const getRoleName = (role: string): string => {
    switch (role) {
      case 'viewer': return 'Viewer';
      case 'editor': return 'Editor';
      case 'admin': return 'Admin';
      default: return role;
    }
  };

  const getRoleColor = (role: string): string => {
    switch (role) {
      case 'viewer': return '#2196f3'; // Blue
      case 'editor': return '#4caf50'; // Green
      case 'admin': return '#f44336';  // Red
      default: return '#9e9e9e';       // Grey
    }
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle>
        {collection ? `Share Collection: ${collection.name}` : 'Share Collection'}
        <IconButton
          aria-label="close"
          onClick={onClose}
          sx={{
            position: 'absolute',
            right: 8,
            top: 8,
          }}
        >
          <CloseIcon />
        </IconButton>
      </DialogTitle>

      <DialogContent sx={{ minHeight: '400px' }}>
        {error && (
          <Alert severity="error" sx={{ mb: 2 }}>
            {error}
          </Alert>
        )}

        {successMessage && (
          <Alert severity="success" sx={{ mb: 2 }}>
            {successMessage}
          </Alert>
        )}

        <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
          <Tabs value={tabValue} onChange={handleTabChange} aria-label="share tabs">
            <Tab label="Public Link" />
            <Tab label="Share with Users" />
          </Tabs>
        </Box>

        <TabPanel value={tabValue} index={0}>
          <Box sx={{ py: 2 }}>
            <FormGroup>
              <FormControlLabel
                control={
                  <Switch
                    checked={isPublic}
                    onChange={handleTogglePublic}
                    disabled={isLoading}
                  />
                }
                label={isPublic ? "Collection is public" : "Make collection public"}
              />
              <Typography variant="caption" color="text.secondary">
                Anyone with the link can view this collection {isPublic ? '' : 'if enabled'}
              </Typography>
            </FormGroup>

            {isPublic && (
              <Box sx={{ mt: 3 }}>
                <Typography variant="subtitle1" gutterBottom>
                  Public Link
                </Typography>
                <Box sx={{ display: 'flex', alignItems: 'center', mt: 1 }}>
                  <TextField
                    value={publicLink}
                    fullWidth
                    variant="outlined"
                    size="small"
                    InputProps={{
                      readOnly: true,
                    }}
                  />
                  <Tooltip title={linkCopied ? "Copied!" : "Copy to clipboard"}>
                    <IconButton onClick={handleCopyLink} color={linkCopied ? "success" : "default"}>
                      <CopyIcon />
                    </IconButton>
                  </Tooltip>
                </Box>
                <Typography variant="caption" color="text.secondary" sx={{ mt: 1, display: 'block' }}>
                  Anyone with this link will be able to view (but not modify) this collection.
                </Typography>
              </Box>
            )}
          </Box>
        </TabPanel>

        <TabPanel value={tabValue} index={1}>
          <Box sx={{ py: 2 }}>
            <Typography variant="subtitle1" gutterBottom>
              Share with Users
            </Typography>
            <Box sx={{ display: 'flex', gap: 1, mb: 3 }}>
              <TextField
                label="Email Address"
                variant="outlined"
                size="small"
                fullWidth
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter email address"
              />
              <FormControl variant="outlined" size="small" sx={{ minWidth: 120 }}>
                <InputLabel id="role-select-label">Role</InputLabel>
                <Select
                  labelId="role-select-label"
                  value={role}
                  onChange={(e) => setRole(e.target.value)}
                  label="Role"
                >
                  <MenuItem value="viewer">Viewer</MenuItem>
                  <MenuItem value="editor">Editor</MenuItem>
                  <MenuItem value="admin">Admin</MenuItem>
                </Select>
              </FormControl>
              <Button
                variant="contained"
                color="primary"
                onClick={handleShareWithUser}
                disabled={!email.trim() || isLoading}
                startIcon={<PersonAddIcon />}
              >
                Share
              </Button>
            </Box>

            <Typography variant="subtitle1" gutterBottom>
              Currently Shared With
            </Typography>
            {sharedUsers.length === 0 ? (
              <Typography variant="body2" color="text.secondary" sx={{ my: 2 }}>
                This collection is not shared with any users.
              </Typography>
            ) : (
              <List>
                {sharedUsers.map((user) => (
                  <React.Fragment key={user.id}>
                    <ListItem>
                      <ListItemText
                        primary={
                          <Box sx={{ display: 'flex', alignItems: 'center' }}>
                            <Typography variant="body1">
                              {user.firstName && user.lastName
                                ? `${user.firstName} ${user.lastName}`
                                : user.email}
                            </Typography>
                            <Chip
                              size="small"
                              label={getRoleName(user.role)}
                              sx={{
                                ml: 1,
                                bgcolor: getRoleColor(user.role),
                                color: 'white',
                                fontSize: '0.7rem',
                                height: 20,
                              }}
                            />
                          </Box>
                        }
                        secondary={
                          <Typography variant="caption" color="text.secondary">
                            {user.email}
                          </Typography>
                        }
                      />
                      <ListItemSecondaryAction>
                        <FormControl variant="standard" size="small" sx={{ mr: 1, minWidth: 80 }}>
                          <Select
                            value={user.role}
                            onChange={(e) => handleUpdateRole(user.id, e.target.value)}
                            disabled={isLoading}
                          >
                            <MenuItem value="viewer">Viewer</MenuItem>
                            <MenuItem value="editor">Editor</MenuItem>
                            <MenuItem value="admin">Admin</MenuItem>
                          </Select>
                        </FormControl>
                        <IconButton
                          edge="end"
                          aria-label="delete"
                          onClick={() => handleRemoveUser(user.id)}
                          disabled={isLoading}
                        >
                          <DeleteIcon />
                        </IconButton>
                      </ListItemSecondaryAction>
                    </ListItem>
                    <Divider />
                  </React.Fragment>
                ))}
              </List>
            )}
          </Box>
        </TabPanel>

        <Box sx={{ mt: 2 }}>
          <Typography variant="subtitle2" color="text.secondary">
            Access Levels
          </Typography>
          <Typography variant="caption" display="block">
            <strong>Viewer:</strong> Can view bookmarks in this collection
          </Typography>
          <Typography variant="caption" display="block">
            <strong>Editor:</strong> Can view and edit bookmarks in this collection
          </Typography>
          <Typography variant="caption" display="block">
            <strong>Admin:</strong> Can view, edit, delete, and manage sharing for this collection
          </Typography>
        </Box>
      </DialogContent>

      <DialogActions>
        <Button onClick={onClose} color="inherit">
          Close
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default ShareCollectionDialog;
