import React, { useState } from 'react';
import {
  AppBar,
  Toolbar,
  Typography,
  Button,
  IconButton,
  Box,
  Menu,
  MenuItem,
  Avatar,
  InputBase,
  Tabs,
  Tab,
  Tooltip,
} from '@mui/material';
import { styled, alpha } from '@mui/material/styles';
import { Link as RouterLink, useLocation } from 'react-router-dom';
import MenuIcon from '@mui/icons-material/Menu';
import SearchIcon from '@mui/icons-material/Search';
import KeyboardCommandKeyIcon from '@mui/icons-material/KeyboardCommandKey';
import AccountCircle from '@mui/icons-material/AccountCircle';
import ThemeToggle from '../common/ThemeToggle';
import { useAuth } from '../../context/AuthContext';

// Styled components for the search bar
const Search = styled('div')(({ theme }) => ({
  position: 'relative',
  borderRadius: theme.shape.borderRadius,
  backgroundColor: alpha(theme.palette.common.white, 0.15),
  '&:hover': {
    backgroundColor: alpha(theme.palette.common.white, 0.25),
  },
  marginRight: theme.spacing(2),
  marginLeft: 0,
  width: '300px',
  height: '36px',
  display: 'flex',
  alignItems: 'center',
}));

const SearchIconWrapper = styled('div')(({ theme }) => ({
  padding: theme.spacing(0, 2),
  height: '100%',
  position: 'absolute',
  pointerEvents: 'none',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
}));

const StyledInputBase = styled(InputBase)(({ theme }) => ({
  color: 'inherit',
  width: '100%',
  '& .MuiInputBase-input': {
    padding: theme.spacing(1, 1, 1, 0),
    paddingLeft: `calc(1em + ${theme.spacing(4)})`,
    width: '100%',
  },
}));

const ShortcutIndicator = styled('div')(({ theme }) => ({
  position: 'absolute',
  right: theme.spacing(1),
  display: 'flex',
  alignItems: 'center',
  backgroundColor: alpha(theme.palette.common.white, 0.1),
  borderRadius: theme.shape.borderRadius,
  padding: '2px 6px',
  fontSize: '0.7rem',
  fontWeight: 'bold',
  color: alpha(theme.palette.common.white, 0.7),
}));

// Custom Link Tab component to work with React Router
interface LinkTabProps {
  label: string;
  href: string;
}

const LinkTab = (props: LinkTabProps) => {
  const { href, ...other } = props;
  return (
    <Tab
      component={RouterLink}
      to={href}
      {...other}
    />
  );
};

const NavTab = styled(LinkTab)(({ theme }) => ({
  minWidth: 'auto',
  padding: theme.spacing(0, 2),
  color: theme.palette.common.white,
  textTransform: 'none',
  fontWeight: 'normal',
  fontSize: '0.9rem',
  opacity: 0.8,
  '&.Mui-selected': {
    color: theme.palette.common.white,
    opacity: 1,
    fontWeight: 'bold',
  },
}));

interface HeaderProps {
  onMenuToggle: () => void;
}

const Header: React.FC<HeaderProps> = ({ 
  onMenuToggle
}) => {
  const { user, logout, isAuthenticated } = useAuth();
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const location = useLocation();
  
  const handleMenu = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleLogout = () => {
    logout();
    handleClose();
  };
  
  // Determine which navigation tab is active
  const currentPath = location.pathname;
  let activeTab = 0;
  if (currentPath.startsWith('/explore')) activeTab = 1;
  else if (currentPath.startsWith('/tool')) activeTab = 2;

  return (
    <AppBar position="fixed" sx={{ zIndex: (theme) => theme.zIndex.drawer + 1 }}>
      <Toolbar sx={{ minHeight: '56px', justifyContent: 'space-between' }}>
        {/* Left section: Logo and menu toggle */}
        <Box sx={{ display: 'flex', alignItems: 'center' }}>
          {isAuthenticated && (
            <IconButton
              color="inherit"
              aria-label="open drawer"
              edge="start"
              onClick={onMenuToggle}
              sx={{ display: { sm: 'none' } }}
            >
              <MenuIcon />
            </IconButton>
          )}
          
          <Typography 
            variant="h6" 
            component={RouterLink} 
            to="/" 
            sx={{ 
              textDecoration: 'none',
              color: 'inherit',
              fontWeight: 'bold',
              letterSpacing: '0.5px',
              fontSize: '1.1rem',
            }}
          >
            My-BookMarks
          </Typography>
        </Box>

        {/* Center: Search bar */}
        {isAuthenticated && (
          <Box sx={{ display: 'flex', alignItems: 'center', flexGrow: 0 }}>
            <Search>
              <SearchIconWrapper>
                <SearchIcon />
              </SearchIconWrapper>
              <StyledInputBase
                placeholder="Search…"
                inputProps={{ 'aria-label': 'search' }}
              />
              <ShortcutIndicator>
                <KeyboardCommandKeyIcon fontSize="small" sx={{ mr: 0.5, fontSize: '0.8rem' }} /> k
              </ShortcutIndicator>
            </Search>
          </Box>
        )}

        {/* Right section: Nav tabs and user menu */}
        {isAuthenticated ? (
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <Tabs 
              value={activeTab} 
              aria-label="navigation tabs"
              sx={{ 
                minHeight: '56px',
                '& .MuiTabs-indicator': { backgroundColor: 'white' } 
              }}
            >
              <NavTab 
                label="Dashboard" 
                href="/" 
              />
              <NavTab 
                label="Explore" 
                href="/explore" 
              />
              <NavTab 
                label="Tool" 
                href="/tool" 
              />
            </Tabs>

            <ThemeToggle />

            <IconButton
              aria-label="account of current user"
              aria-controls="menu-appbar"
              aria-haspopup="true"
              onClick={handleMenu}
              color="inherit"
              sx={{ ml: 1 }}
            >
              {user?.firstName ? (
                <Avatar sx={{ width: 28, height: 28, fontSize: '0.9rem' }}>
                  {user.firstName[0]}
                </Avatar>
              ) : (
                <AccountCircle />
              )}
            </IconButton>
            <Menu
              id="menu-appbar"
              anchorEl={anchorEl}
              anchorOrigin={{
                vertical: 'bottom',
                horizontal: 'right',
              }}
              keepMounted
              transformOrigin={{
                vertical: 'top',
                horizontal: 'right',
              }}
              open={Boolean(anchorEl)}
              onClose={handleClose}
            >
              <MenuItem 
                component={RouterLink} 
                to="/settings" 
                onClick={handleClose}
              >
                Settings
              </MenuItem>
              <MenuItem onClick={handleLogout}>Logout</MenuItem>
            </Menu>
          </Box>
        ) : (
          <Box>
            <Button 
              color="inherit" 
              component={RouterLink} 
              to="/login"
              sx={{ mr: 1 }}
            >
              Login
            </Button>
            <Button 
              variant="outlined" 
              color="inherit" 
              component={RouterLink} 
              to="/register"
            >
              Register
            </Button>
          </Box>
        )}
      </Toolbar>
    </AppBar>
  );
};

export default Header;
