import React, { useEffect, useState } from 'react';
import {
  Drawer,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Toolbar,
  Divider,
  Box,
  Typography,
  IconButton,
  Collapse,
  ListItemButton,
} from '@mui/material';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  Bookmark as BookmarkIcon,
  Label as TagIcon,
  Star as FavoriteIcon,
  ExpandLess,
  ExpandMore,
  Add as AddIcon,
  Folder as FolderIcon,
  Dashboard as DashboardIcon,
} from '@mui/icons-material';
import { getCollections } from '../../services/collectionService';
import { getTags } from '../../services/tagService';

interface SidebarProps {
  isOpen: boolean;
  drawerWidth: number;
  onClose: () => void;
  mobileOpen?: boolean;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, drawerWidth, onClose, mobileOpen = false }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const [collections, setCollections] = useState<any[]>([]);
  const [tags, setTags] = useState<any[]>([]);
  const [collectionsOpen, setCollectionsOpen] = useState(true);
  const [tagsOpen, setTagsOpen] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const collectionsData = await getCollections();
        const tagsData = await getTags();
        setCollections(collectionsData);
        setTags(tagsData);
      } catch (error) {
        console.error('Error fetching sidebar data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const handleNavigation = (path: string) => {
    navigate(path);
    if (mobileOpen) {
      onClose();
    }
  };

  const drawerContent = (
    <div>
      <Toolbar />
      <List>
        <ListItemButton 
          onClick={() => handleNavigation('/')}
          selected={location.pathname === '/'}
        >
          <ListItemIcon>
            <DashboardIcon />
          </ListItemIcon>
          <ListItemText primary="Dashboard" />
        </ListItemButton>
        <ListItemButton 
          onClick={() => handleNavigation('/bookmarks')}
          selected={location.pathname === '/bookmarks'}
        >
          <ListItemIcon>
            <BookmarkIcon />
          </ListItemIcon>
          <ListItemText primary="All Bookmarks" />
        </ListItemButton>
        <ListItemButton 
          onClick={() => handleNavigation('/bookmarks/favorites')}
          selected={location.pathname === '/bookmarks/favorites'}
        >
          <ListItemIcon>
            <FavoriteIcon />
          </ListItemIcon>
          <ListItemText primary="Favorites" />
        </ListItemButton>
      </List>
      <Divider />
      
      {/* Collections Section */}
      <ListItemButton onClick={() => setCollectionsOpen(!collectionsOpen)}>
        <ListItemIcon>
          <FolderIcon />
        </ListItemIcon>
        <ListItemText primary="Collections" />
        {collectionsOpen ? <ExpandLess /> : <ExpandMore />}
      </ListItemButton>
      
      <Collapse in={collectionsOpen} timeout="auto" unmountOnExit>
        <List component="div" disablePadding>
          {collections.map((collection) => (
            <ListItemButton 
              key={collection.id}
              onClick={() => handleNavigation(`/collections/${collection.id}`)}
              sx={{ pl: 4 }}
            >
              <ListItemIcon>
                <FolderIcon style={{ color: collection.color || 'inherit' }} />
              </ListItemIcon>
              <ListItemText primary={collection.name} />
            </ListItemButton>
          ))}
          <ListItemButton 
            onClick={() => handleNavigation('/collections/create')}
            sx={{ pl: 4 }}
          >
            <ListItemIcon>
              <AddIcon />
            </ListItemIcon>
            <ListItemText primary="Add Collection" />
          </ListItemButton>
        </List>
      </Collapse>
      
      <Divider />
      
      {/* Tags Section */}
      <ListItemButton onClick={() => setTagsOpen(!tagsOpen)}>
        <ListItemIcon>
          <TagIcon />
        </ListItemIcon>
        <ListItemText primary="Tags" />
        {tagsOpen ? <ExpandLess /> : <ExpandMore />}
      </ListItemButton>
      
      <Collapse in={tagsOpen} timeout="auto" unmountOnExit>
        <List component="div" disablePadding>
          {tags.map((tag) => (
            <ListItemButton 
              key={tag.id}
              onClick={() => handleNavigation(`/tags/${tag.id}`)}
              sx={{ pl: 4 }}
            >
              <ListItemIcon>
                <TagIcon />
              </ListItemIcon>
              <ListItemText primary={tag.name} />
            </ListItemButton>
          ))}
          <ListItemButton 
            onClick={() => handleNavigation('/tags/manage')}
            sx={{ pl: 4 }}
          >
            <ListItemIcon>
              <AddIcon />
            </ListItemIcon>
            <ListItemText primary="Manage Tags" />
          </ListItemButton>
        </List>
      </Collapse>
    </div>
  );

  return (
    <>
      {/* Mobile drawer */}
      <Drawer
        variant="temporary"
        open={mobileOpen}
        onClose={onClose}
        ModalProps={{
          keepMounted: true, // Better open performance on mobile
        }}
        sx={{
          display: { xs: 'block', sm: 'none' },
          '& .MuiDrawer-paper': { boxSizing: 'border-box', width: drawerWidth },
        }}
      >
        {drawerContent}
      </Drawer>
      
      {/* Desktop drawer */}
      <Drawer
        variant="permanent"
        open={isOpen}
        sx={{
          display: { xs: 'none', sm: 'block' },
          '& .MuiDrawer-paper': { 
            boxSizing: 'border-box', 
            width: drawerWidth,
            position: 'relative',
            height: '100%',
            overflowX: 'hidden'
          },
          width: isOpen ? drawerWidth : 0,
          transition: (theme) => theme.transitions.create('width', {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.enteringScreen,
          }),
        }}
        PaperProps={{
          sx: {
            overflow: 'hidden',
            width: isOpen ? drawerWidth : 0,
            transition: (theme) => theme.transitions.create('width', {
              easing: theme.transitions.easing.sharp,
              duration: theme.transitions.duration.enteringScreen,
            }),
          }
        }}
      >
        {drawerContent}
      </Drawer>
    </>
  );
};

export default Sidebar;
