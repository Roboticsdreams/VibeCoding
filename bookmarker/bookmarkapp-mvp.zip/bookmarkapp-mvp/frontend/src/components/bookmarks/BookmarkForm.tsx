import React, { useEffect, useState } from 'react';
import {
  Box,
  Button,
  TextField,
  Typography,
  Paper,
  FormControlLabel,
  Switch,
  Autocomplete,
  Chip,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  OutlinedInput,
  SelectChangeEvent,
  Checkbox,
  ListItemText,
} from '@mui/material';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import { Bookmark } from '../../services/bookmarkService';
import { Collection } from '../../services/collectionService';
import { Tag } from '../../services/tagService';

interface BookmarkFormProps {
  bookmark?: Bookmark;
  collections: Collection[];
  tags: Tag[];
  onSubmit: (values: BookmarkFormData) => void;
  onCancel: () => void;
}

export interface BookmarkFormData {
  url: string;
  title: string;
  description?: string;
  favicon?: string;
  notes?: string;
  isFavorite?: boolean;
  tags?: string[];
  collectionIds?: number[];
}

const validationSchema = Yup.object({
  url: Yup.string().url('Enter a valid URL').required('URL is required'),
  title: Yup.string().required('Title is required'),
  description: Yup.string(),
  favicon: Yup.string(),
  notes: Yup.string(),
});

const BookmarkForm: React.FC<BookmarkFormProps> = ({
  bookmark,
  collections,
  tags,
  onSubmit,
  onCancel,
}) => {
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [selectedCollections, setSelectedCollections] = useState<number[]>([]);

  useEffect(() => {
    if (bookmark) {
      if (bookmark.tags) {
        setSelectedTags(bookmark.tags.map((tag) => tag.name));
      }
      if (bookmark.collections) {
        setSelectedCollections(bookmark.collections.map((collection) => collection.id));
      }
    }
  }, [bookmark]);

  const formik = useFormik({
    initialValues: {
      url: bookmark?.url || '',
      title: bookmark?.title || '',
      description: bookmark?.description || '',
      favicon: bookmark?.favicon || '',
      notes: bookmark?.notes || '',
      isFavorite: bookmark?.isFavorite || false,
    },
    validationSchema,
    onSubmit: (values) => {
      onSubmit({
        ...values,
        tags: selectedTags,
        collectionIds: selectedCollections,
      });
    },
  });

  const handleTagsChange = (event: React.SyntheticEvent, value: string[]) => {
    setSelectedTags(value);
  };

  const handleCollectionsChange = (event: SelectChangeEvent<number[]>) => {
    const value = event.target.value as number[];
    setSelectedCollections(value);
  };

  return (
    <Paper elevation={3} sx={{ p: 4, maxWidth: '800px', margin: '0 auto' }}>
      <Typography variant="h5" gutterBottom>
        {bookmark ? 'Edit Bookmark' : 'Add New Bookmark'}
      </Typography>
      
      <Box component="form" onSubmit={formik.handleSubmit} sx={{ mt: 2 }}>
        <TextField
          fullWidth
          id="url"
          name="url"
          label="URL"
          variant="outlined"
          margin="normal"
          value={formik.values.url}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          error={formik.touched.url && Boolean(formik.errors.url)}
          helperText={formik.touched.url && formik.errors.url}
        />
        
        <TextField
          fullWidth
          id="title"
          name="title"
          label="Title"
          variant="outlined"
          margin="normal"
          value={formik.values.title}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          error={formik.touched.title && Boolean(formik.errors.title)}
          helperText={formik.touched.title && formik.errors.title}
        />
        
        <TextField
          fullWidth
          id="description"
          name="description"
          label="Description"
          variant="outlined"
          margin="normal"
          multiline
          rows={2}
          value={formik.values.description}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          error={formik.touched.description && Boolean(formik.errors.description)}
          helperText={formik.touched.description && formik.errors.description}
        />
        
        <TextField
          fullWidth
          id="favicon"
          name="favicon"
          label="Favicon URL"
          variant="outlined"
          margin="normal"
          value={formik.values.favicon}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          error={formik.touched.favicon && Boolean(formik.errors.favicon)}
          helperText={formik.touched.favicon && formik.errors.favicon}
        />
        
        <TextField
          fullWidth
          id="notes"
          name="notes"
          label="Notes"
          variant="outlined"
          margin="normal"
          multiline
          rows={4}
          value={formik.values.notes}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          error={formik.touched.notes && Boolean(formik.errors.notes)}
          helperText={formik.touched.notes && formik.errors.notes}
        />
        
        <Box sx={{ mt: 2, mb: 2 }}>
          <FormControlLabel
            control={
              <Switch
                checked={formik.values.isFavorite}
                onChange={(e) => {
                  formik.setFieldValue('isFavorite', e.target.checked);
                }}
                name="isFavorite"
                color="primary"
              />
            }
            label="Add to favorites"
          />
        </Box>
        
        <FormControl fullWidth margin="normal">
          <InputLabel id="collections-label">Collections</InputLabel>
          <Select
            labelId="collections-label"
            id="collections"
            multiple
            value={selectedCollections}
            onChange={handleCollectionsChange}
            input={<OutlinedInput label="Collections" />}
            renderValue={(selected) => (
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                {selected.map((value) => {
                  const collection = collections.find(c => c.id === value);
                  return (
                    <Chip 
                      key={value} 
                      label={collection ? collection.name : ''} 
                    />
                  );
                })}
              </Box>
            )}
          >
            {collections.map((collection) => (
              <MenuItem key={collection.id} value={collection.id}>
                <Checkbox checked={selectedCollections.indexOf(collection.id) > -1} />
                <ListItemText primary={collection.name} />
              </MenuItem>
            ))}
          </Select>
        </FormControl>
        
        <Autocomplete
          multiple
          id="tags"
          options={tags.map(tag => tag.name)}
          value={selectedTags}
          onChange={handleTagsChange}
          freeSolo
          renderTags={(value, getTagProps) =>
            value.map((option, index) => (
              <Chip
                label={option}
                {...getTagProps({ index })}
              />
            ))
          }
          renderInput={(params) => (
            <TextField
              {...params}
              margin="normal"
              label="Tags"
              placeholder="Add tags"
            />
          )}
        />
        
        <Box sx={{ mt: 4, display: 'flex', justifyContent: 'flex-end', gap: 2 }}>
          <Button variant="outlined" onClick={onCancel}>
            Cancel
          </Button>
          <Button type="submit" variant="contained" color="primary">
            {bookmark ? 'Update' : 'Save'}
          </Button>
        </Box>
      </Box>
    </Paper>
  );
};

export default BookmarkForm;
