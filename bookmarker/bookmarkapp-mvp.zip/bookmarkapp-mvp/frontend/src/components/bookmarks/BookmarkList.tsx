import React, { useState } from 'react';
import { Box, Typography, Pagination, MenuItem, Select, FormControl, InputLabel, SelectChangeEvent, Grid } from '@mui/material';
import BookmarkItem from './BookmarkItem';
import { Bookmark } from '../../services/bookmarkService';

interface BookmarkListProps {
  bookmarks: Bookmark[];
  totalPages: number;
  currentPage: number;
  onPageChange: (page: number) => void;
  onEdit: (bookmark: Bookmark) => void;
  onDelete: (bookmarkId: number) => void;
  onToggleFavorite: (bookmark: Bookmark) => void;
}

const BookmarkList: React.FC<BookmarkListProps> = ({
  bookmarks,
  totalPages,
  currentPage,
  onPageChange,
  onEdit,
  onDelete,
  onToggleFavorite,
}) => {
  const [view, setView] = useState<'grid' | 'list'>('grid');
  
  const handlePageChange = (event: React.ChangeEvent<unknown>, page: number) => {
    onPageChange(page);
  };

  const handleViewChange = (event: SelectChangeEvent) => {
    setView(event.target.value as 'grid' | 'list');
  };

  if (bookmarks.length === 0) {
    return (
      <Box sx={{ textAlign: 'center', py: 8 }}>
        <Typography variant="h5" color="text.secondary">
          No bookmarks found
        </Typography>
        <Typography variant="body1" color="text.secondary" mt={2}>
          Add your first bookmark to get started
        </Typography>
      </Box>
    );
  }

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'flex-end', mb: 3 }}>
        <FormControl variant="outlined" size="small" sx={{ minWidth: 120 }}>
          <InputLabel id="view-select-label">View</InputLabel>
          <Select
            labelId="view-select-label"
            id="view-select"
            value={view}
            label="View"
            onChange={handleViewChange}
          >
            <MenuItem value="grid">Grid</MenuItem>
            <MenuItem value="list">List</MenuItem>
          </Select>
        </FormControl>
      </Box>
      
      <Box sx={{ display: 'grid', gridTemplateColumns: {
          xs: '1fr',
          sm: view === 'grid' ? 'repeat(2, 1fr)' : '1fr', 
          md: view === 'grid' ? 'repeat(3, 1fr)' : '1fr'
        }, 
        gap: 3
      }}>
        {bookmarks.map((bookmark) => (
          <Box key={bookmark.id}>
            <BookmarkItem
              bookmark={bookmark}
              onEdit={onEdit}
              onDelete={onDelete}
              onToggleFavorite={onToggleFavorite}
            />
          </Box>
        ))}
      </Box>
      
      {totalPages > 1 && (
        <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
          <Pagination 
            count={totalPages} 
            page={currentPage} 
            onChange={handlePageChange} 
            color="primary" 
          />
        </Box>
      )}
    </Box>
  );
};

export default BookmarkList;
