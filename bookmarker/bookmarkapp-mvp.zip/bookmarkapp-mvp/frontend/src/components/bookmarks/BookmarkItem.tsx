import React from 'react';
import {
  Card,
  CardContent,
  CardActions,
  Typography,
  IconButton,
  Chip,
  Box,
  Tooltip,
  CardMedia,
  Link,
} from '@mui/material';
import {
  Favorite as FavoriteIcon,
  FavoriteBorder as FavoriteBorderIcon,
  Delete as DeleteIcon,
  Edit as EditIcon,
  Folder as FolderIcon,
  OpenInNew as OpenInNewIcon,
} from '@mui/icons-material';
import { Bookmark } from '../../services/bookmarkService';

interface BookmarkItemProps {
  bookmark: Bookmark;
  onEdit: (bookmark: Bookmark) => void;
  onDelete: (bookmarkId: number) => void;
  onToggleFavorite: (bookmark: Bookmark) => void;
}

const BookmarkItem: React.FC<BookmarkItemProps> = ({
  bookmark,
  onEdit,
  onDelete,
  onToggleFavorite,
}) => {
  return (
    <Card sx={{ 
      display: 'flex', 
      flexDirection: 'column', 
      height: '100%',
      transition: 'transform 0.3s',
      '&:hover': {
        transform: 'translateY(-4px)',
        boxShadow: 3,
      },
    }}>
      {bookmark.favicon && (
        <CardMedia
          component="img"
          sx={{ 
            height: 140, 
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            backgroundColor: '#f5f5f5',
          }}
          image={bookmark.favicon}
          alt={bookmark.title}
        />
      )}
      
      <CardContent sx={{ flexGrow: 1 }}>
        <Typography 
          variant="h6" 
          component="div" 
          gutterBottom
          sx={{
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            display: '-webkit-box',
            WebkitLineClamp: 2,
            WebkitBoxOrient: 'vertical',
            lineHeight: 1.2,
            height: '2.4em',
            fontWeight: 'bold',
          }}
        >
          {bookmark.title}
        </Typography>
        
        <Link 
          href={bookmark.url} 
          target="_blank" 
          rel="noopener noreferrer"
          sx={{
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            display: 'block',
            whiteSpace: 'nowrap',
            fontSize: '0.8rem',
            color: 'text.secondary',
            mb: 1,
          }}
        >
          {bookmark.url}
        </Link>
        
        {bookmark.description && (
          <Typography 
            variant="body2" 
            color="text.secondary"
            sx={{
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              display: '-webkit-box',
              WebkitLineClamp: 2,
              WebkitBoxOrient: 'vertical',
              lineHeight: 1.5,
              height: '3em',
              mb: 2,
            }}
          >
            {bookmark.description}
          </Typography>
        )}
        
        {bookmark.tags && bookmark.tags.length > 0 && (
          <Box sx={{ mt: 1, display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
            {bookmark.tags.slice(0, 3).map((tag) => (
              <Chip 
                key={tag.id} 
                label={tag.name} 
                size="small" 
                sx={{ fontSize: '0.7rem' }} 
              />
            ))}
            {bookmark.tags.length > 3 && (
              <Chip 
                label={`+${bookmark.tags.length - 3}`} 
                size="small" 
                variant="outlined"
                sx={{ fontSize: '0.7rem' }} 
              />
            )}
          </Box>
        )}
      </CardContent>
      
      <CardActions sx={{ justifyContent: 'space-between', px: 2, pt: 0, pb: 1 }}>
        <Box>
          <Tooltip title="Toggle favorite">
            <IconButton onClick={() => onToggleFavorite(bookmark)} size="small">
              {bookmark.isFavorite ? (
                <FavoriteIcon color="error" fontSize="small" />
              ) : (
                <FavoriteBorderIcon fontSize="small" />
              )}
            </IconButton>
          </Tooltip>
          <Tooltip title="Edit">
            <IconButton onClick={() => onEdit(bookmark)} size="small">
              <EditIcon fontSize="small" />
            </IconButton>
          </Tooltip>
          <Tooltip title="Delete">
            <IconButton onClick={() => onDelete(bookmark.id)} size="small">
              <DeleteIcon fontSize="small" />
            </IconButton>
          </Tooltip>
        </Box>
        
        <Box>
          <Tooltip title="Open in new tab">
            <IconButton 
              href={bookmark.url} 
              target="_blank" 
              rel="noopener noreferrer" 
              size="small"
            >
              <OpenInNewIcon fontSize="small" />
            </IconButton>
          </Tooltip>
        </Box>
      </CardActions>
    </Card>
  );
};

export default BookmarkItem;
