import React, { useState } from 'react';
import {
  Box,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  TextField,
  Button,
  Chip,
  Paper,
  Typography,
  Grid,
  Autocomplete,
  FormControlLabel,
  Checkbox,
  FormGroup,
  SelectChangeEvent,
} from '@mui/material';
import { Search as SearchIcon, Clear as ClearIcon } from '@mui/icons-material';
import { Collection } from '../../services/collectionService';
import { Tag } from '../../services/tagService';

export interface AdvancedSearchFilters {
  search?: string;
  favorite?: boolean;
  collectionId?: number;
  tagIds?: number[];
  dateFrom?: string;
  dateTo?: string;
  sortBy?: string;
  sortDirection?: 'asc' | 'desc';
}

interface AdvancedSearchFormProps {
  collections: Collection[];
  tags: Tag[];
  onSearch: (filters: AdvancedSearchFilters) => void;
  initialFilters?: AdvancedSearchFilters;
}

const AdvancedSearchForm: React.FC<AdvancedSearchFormProps> = ({
  collections,
  tags,
  onSearch,
  initialFilters = {},
}) => {
  const [filters, setFilters] = useState<AdvancedSearchFilters>({
    search: initialFilters.search || '',
    favorite: initialFilters.favorite || false,
    collectionId: initialFilters.collectionId,
    tagIds: initialFilters.tagIds || [],
    dateFrom: initialFilters.dateFrom || '',
    dateTo: initialFilters.dateTo || '',
    sortBy: initialFilters.sortBy || 'createdAt',
    sortDirection: initialFilters.sortDirection || 'desc',
  });

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, checked, type } = event.target;
    setFilters({
      ...filters,
      [name]: type === 'checkbox' ? checked : value,
    });
  };

  const handleSelectChange = (event: SelectChangeEvent<unknown>) => {
    const { name, value } = event.target;
    setFilters({
      ...filters,
      [name]: value,
    });
  };

  const handleTagsChange = (event: React.SyntheticEvent, value: Tag[]) => {
    setFilters({
      ...filters,
      tagIds: value.map(tag => tag.id),
    });
  };

  const handleSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    onSearch(filters);
  };

  const handleClear = () => {
    setFilters({
      search: '',
      favorite: false,
      collectionId: undefined,
      tagIds: [],
      dateFrom: '',
      dateTo: '',
      sortBy: 'createdAt',
      sortDirection: 'desc',
    });
  };

  return (
    <Paper sx={{ p: 3, mb: 3 }}>
      <Typography variant="h6" gutterBottom>
        Advanced Search
      </Typography>
      <Box component="form" onSubmit={handleSubmit}>
        <Grid container spacing={2}>
          <Grid item xs={12}>
            <TextField
              fullWidth
              name="search"
              label="Search Keywords"
              value={filters.search}
              onChange={handleChange}
              placeholder="Search for title, URL, description or notes"
            />
          </Grid>
          
          <Grid item xs={12} sm={6}>
            <FormControl fullWidth>
              <InputLabel id="collection-label">Collection</InputLabel>
              <Select
                labelId="collection-label"
                name="collectionId"
                value={filters.collectionId || ''}
                label="Collection"
                onChange={handleSelectChange}
              >
                <MenuItem value="">
                  <em>Any Collection</em>
                </MenuItem>
                {collections.map((collection) => (
                  <MenuItem key={collection.id} value={collection.id}>
                    {collection.name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
          
          <Grid item xs={12} sm={6}>
            <Autocomplete
              multiple
              id="tags-select"
              options={tags}
              getOptionLabel={(tag) => tag.name}
              value={tags.filter(tag => filters.tagIds?.includes(tag.id))}
              onChange={handleTagsChange}
              renderInput={(params) => (
                <TextField {...params} label="Tags" placeholder="Select Tags" />
              )}
              renderTags={(value, getTagProps) =>
                value.map((tag, index) => (
                  <Chip label={tag.name} {...getTagProps({ index })} />
                ))
              }
            />
          </Grid>
          
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              label="From Date"
              type="date"
              name="dateFrom"
              value={filters.dateFrom}
              onChange={handleChange}
              InputLabelProps={{
                shrink: true,
              }}
            />
          </Grid>
          
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              label="To Date"
              type="date"
              name="dateTo"
              value={filters.dateTo}
              onChange={handleChange}
              InputLabelProps={{
                shrink: true,
              }}
            />
          </Grid>
          
          <Grid item xs={12} sm={4}>
            <FormControl fullWidth>
              <InputLabel id="sort-by-label">Sort By</InputLabel>
              <Select
                labelId="sort-by-label"
                name="sortBy"
                value={filters.sortBy}
                label="Sort By"
                onChange={handleSelectChange}
              >
                <MenuItem value="createdAt">Date Created</MenuItem>
                <MenuItem value="updatedAt">Date Updated</MenuItem>
                <MenuItem value="title">Title</MenuItem>
                <MenuItem value="url">URL</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          
          <Grid item xs={12} sm={4}>
            <FormControl fullWidth>
              <InputLabel id="sort-direction-label">Sort Direction</InputLabel>
              <Select
                labelId="sort-direction-label"
                name="sortDirection"
                value={filters.sortDirection}
                label="Sort Direction"
                onChange={handleSelectChange}
              >
                <MenuItem value="asc">Ascending</MenuItem>
                <MenuItem value="desc">Descending</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          
          <Grid item xs={12} sm={4}>
            <FormGroup sx={{ mt: 1 }}>
              <FormControlLabel
                control={
                  <Checkbox
                    name="favorite"
                    checked={filters.favorite}
                    onChange={handleChange}
                  />
                }
                label="Favorites Only"
              />
            </FormGroup>
          </Grid>
          
          <Grid item xs={12}>
            <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 2, mt: 2 }}>
              <Button
                variant="outlined"
                color="primary"
                onClick={handleClear}
                startIcon={<ClearIcon />}
              >
                Clear
              </Button>
              <Button
                variant="contained"
                color="primary"
                type="submit"
                startIcon={<SearchIcon />}
              >
                Search
              </Button>
            </Box>
          </Grid>
        </Grid>
      </Box>
    </Paper>
  );
};

export default AdvancedSearchForm;
