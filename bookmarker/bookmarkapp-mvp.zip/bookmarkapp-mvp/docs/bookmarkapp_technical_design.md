# BookMark App - Technical Design Document

## 1. Architecture Overview

### 1.1 System Architecture
![System Architecture](https://placeholder-for-architecture-diagram.com)

The BookMark App follows a modern three-tier architecture:

- **Frontend**: React.js single-page application (SPA)
- **Backend**: Node.js/Express.js RESTful API
- **Database**: SQLite relational database
- **External Services**: Google Drive API, Authentication providers

### 1.2 Deployment Architecture

- **Frontend**: Static assets served through CDN
- **Backend**: Containerized microservices via Docker
- **Database**: SQLite file-based database
- **CI/CD**: GitHub Actions pipeline with automated testing
- **Hosting**: AWS (EC2, S3, CloudFront) or similar cloud provider

## 2. Frontend Design

### 2.1 Component Structure

```
src/
├── assets/             # Static assets (icons, images)
├── components/         # Reusable UI components
│   ├── common/         # Shared components (Button, Input, etc.)
│   ├── layout/         # Layout components (Sidebar, Header, etc.)
│   └── features/       # Feature-specific components
├── contexts/           # React context providers
├── hooks/              # Custom React hooks
├── pages/              # Page components
├── services/           # API client and external service integrations
├── store/              # State management (Redux or Context)
├── styles/             # Global styles and themes
├── types/              # TypeScript type definitions
└── utils/              # Utility functions
```

### 2.2 State Management

- **Application State**: Redux for global app state
  - Auth state
  - User preferences
  - Bookmark collections
- **Component State**: React hooks for local component state
- **Server State**: React Query for API data fetching, caching, and synchronization

### 2.3 Routing Structure

- `/` - Dashboard/Home
- `/login` - User login
- `/register` - User registration
- `/bookmarks` - Main bookmark view
- `/bookmarks/:collectionId` - Specific collection view
- `/bookmarks/:collectionId/:bookmarkId` - Individual bookmark detail
- `/settings` - User settings
- `/analytics` - Analytics dashboard

### 2.4 UI Component Library

- Material UI or Chakra UI as the base component library
- Custom theme extension for brand identity
- Responsive design with mobile-first approach

## 3. Backend Design

### 3.0 Database Configuration

- **ORM**: Sequelize or TypeORM for SQLite integration
- **Migrations**: Database schema version control
- **Connection Pool**: Configured for optimal performance
- **Transaction Support**: ACID-compliant operations for data integrity

### 3.1 API Structure

#### Base URL: `/api/v1`

#### Authentication Endpoints
- `POST /auth/register` - User registration
- `POST /auth/login` - User login
- `POST /auth/refresh` - Refresh access token
- `POST /auth/forgot-password` - Password reset request
- `POST /auth/reset-password` - Password reset

#### Bookmark Endpoints
- `GET /bookmarks` - List bookmarks (with filtering/pagination)
- `POST /bookmarks` - Create bookmark
- `GET /bookmarks/:id` - Get bookmark details
- `PUT /bookmarks/:id` - Update bookmark
- `DELETE /bookmarks/:id` - Delete bookmark

#### Collection Endpoints
- `GET /collections` - List collections
- `POST /collections` - Create collection
- `GET /collections/:id` - Get collection details
- `PUT /collections/:id` - Update collection
- `DELETE /collections/:id` - Delete collection
- `POST /collections/:id/bookmarks` - Add bookmark to collection
- `DELETE /collections/:id/bookmarks/:bookmarkId` - Remove bookmark from collection

#### Sharing Endpoints
- `POST /share/bookmarks/:id` - Share a bookmark
- `POST /share/collections/:id` - Share a collection
- `GET /share/:shareId` - Access shared item

#### Import/Export Endpoints
- `POST /import/browser` - Import from browser
- `POST /import/html` - Import from HTML file
- `GET /export/:format` - Export bookmarks

#### Google Drive Integration
- `GET /drive/auth` - Initiate OAuth flow
- `POST /drive/backup` - Create backup
- `GET /drive/backups` - List backups
- `POST /drive/restore/:backupId` - Restore from backup

#### Analytics Endpoints
- `GET /analytics/usage` - Get usage statistics
- `GET /analytics/bookmarks` - Get bookmark analytics

### 3.2 Middleware Stack

1. **Request Logging**: Morgan/Winston for request logging
2. **Body Parsing**: Express body parser for JSON/form data
3. **Authentication**: JWT verification middleware
4. **Error Handling**: Centralized error handling middleware
5. **Compression**: Response compression
6. **CORS**: Cross-origin resource sharing configuration

### 3.3 Authentication Flow

1. User registers or logs in
2. Server validates credentials and issues JWT (access token + refresh token)
3. Access token included in Authorization header for protected requests
4. Refresh token used to obtain new access tokens when expired
5. Social login (Google, Facebook) implemented via OAuth 2.0

## 4. Database Design

### 4.1 Schema Definition

#### User Table

```sql
CREATE TABLE users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  first_name TEXT,
  last_name TEXT,
  avatar TEXT,
  theme TEXT DEFAULT 'light',
  default_view TEXT DEFAULT 'grid',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### Social Profiles Table

```sql
CREATE TABLE social_profiles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  provider TEXT NOT NULL,
  provider_id TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE(user_id, provider)
);
```

#### Bookmarks Table

```sql
CREATE TABLE bookmarks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  url TEXT NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  favicon TEXT,
  screenshot TEXT,
  notes TEXT,
  is_archived BOOLEAN DEFAULT 0,
  is_favorite BOOLEAN DEFAULT 0,
  source TEXT,
  content_type TEXT,
  visit_count INTEGER DEFAULT 0,
  last_visited TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE(user_id, url)
);
```

#### Tags Table

```sql
CREATE TABLE tags (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE(user_id, name)
);
```

#### Bookmark Tags Table (Junction Table)

```sql
CREATE TABLE bookmark_tags (
  bookmark_id INTEGER NOT NULL,
  tag_id INTEGER NOT NULL,
  PRIMARY KEY (bookmark_id, tag_id),
  FOREIGN KEY (bookmark_id) REFERENCES bookmarks(id) ON DELETE CASCADE,
  FOREIGN KEY (tag_id) REFERENCES tags(id) ON DELETE CASCADE
);
```

#### Collections Table

```sql
CREATE TABLE collections (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  color TEXT,
  icon TEXT,
  is_public BOOLEAN DEFAULT 0,
  parent_id INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (parent_id) REFERENCES collections(id) ON DELETE SET NULL,
  UNIQUE(user_id, name)
);
```

#### Collection Bookmarks Table (Junction Table)

```sql
CREATE TABLE collection_bookmarks (
  collection_id INTEGER NOT NULL,
  bookmark_id INTEGER NOT NULL,
  added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (collection_id, bookmark_id),
  FOREIGN KEY (collection_id) REFERENCES collections(id) ON DELETE CASCADE,
  FOREIGN KEY (bookmark_id) REFERENCES bookmarks(id) ON DELETE CASCADE
);
```

#### Shares Table

```sql
CREATE TABLE shares (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  resource_type TEXT NOT NULL, -- 'bookmark' or 'collection'
  resource_id INTEGER NOT NULL,
  share_code TEXT UNIQUE NOT NULL,
  can_read BOOLEAN DEFAULT 1,
  can_write BOOLEAN DEFAULT 0,
  can_admin BOOLEAN DEFAULT 0,
  expires_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
```

#### Backups Table

```sql
CREATE TABLE backups (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  drive_file_id TEXT NOT NULL,
  file_name TEXT NOT NULL,
  size INTEGER NOT NULL,
  bookmark_count INTEGER NOT NULL,
  collection_count INTEGER NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
```

### 4.2 Indexing Strategy

```sql
-- Basic indexes
CREATE INDEX idx_bookmarks_user_id ON bookmarks(user_id);
CREATE INDEX idx_collections_user_id ON collections(user_id);
CREATE INDEX idx_collections_parent_id ON collections(parent_id);
CREATE INDEX idx_shares_resource ON shares(resource_type, resource_id);
CREATE INDEX idx_shares_user_id ON shares(user_id);

-- Full-text search indexes (using SQLite FTS5 extension)
CREATE VIRTUAL TABLE bookmarks_fts USING fts5(
  title, 
  description, 
  notes,
  content='bookmarks',
  content_rowid='id'
);
```

### 4.3 Data Relationships

- User to Bookmarks: One-to-Many (via foreign key user_id in bookmarks table)
- User to Collections: One-to-Many (via foreign key user_id in collections table)
- Collection to Bookmarks: Many-to-Many (via junction table collection_bookmarks)
- Collection to Collections (nested): One-to-Many (via self-referencing parent_id)

## 5. Integration Designs

### 5.1 Google Drive Integration

#### Authentication Flow
1. User initiates Google Drive connection
2. App redirects to Google OAuth consent screen
3. User grants permissions
4. Google returns auth code
5. Backend exchanges code for access/refresh tokens
6. Store refresh token in user document
7. Use access token for API requests

#### Backup Process
1. Export user's bookmarks and collections to JSON
2. Create timestamped backup file
3. Upload to user's Google Drive via API
4. Store reference to drive file in Backup model

#### Restore Process
1. Retrieve backup file from Google Drive
2. Parse backup data
3. Create transaction for database operations
4. Replace or merge data according to user preference
5. Update user's bookmarks and collections

### 5.2 Browser Extension Integration

#### Extension Architecture
- Background script for event handling
- Content script for page interaction
- Popup UI for bookmark creation
- Storage sync for user data

#### Communication Flow
1. Extension captures current page data
2. User adds bookmark via extension popup
3. Extension sends data to API with user's JWT
4. API creates bookmark and returns confirmation
5. Extension updates local state

## 6. Security Implementation

### 6.1 Authentication Security
- Passwords hashed with bcrypt (10+ rounds)
- JWT with short expiration for access tokens
- HTTP-only, secure cookies for refresh tokens
- CSRF token validation for sensitive operations

### 6.2 API Security
- Input validation with Joi/Yup
- Rate limiting for authentication endpoints
- Content Security Policy headers
- Helmet.js for HTTP header security

### 6.3 Data Security
- HTTPS for all communications
- Field-level encryption for sensitive data
- Sanitization of user-generated content
- Principle of least privilege for DB operations

## 7. Performance Optimizations

### 7.1 Frontend Optimizations
- Code splitting by route
- Lazy loading of components
- Virtualized lists for large bookmark collections
- Image optimization for screenshots/favicons
- Service worker for offline capability

### 7.2 Backend Optimizations
- Response caching with Redis
- Database query optimization
- Connection pooling
- Pagination for large result sets
- Background processing for heavy operations

### 7.3 Database Optimizations
- Appropriate indexing
- Denormalization where appropriate
- Document embedding vs references based on access patterns
- Read replicas for scaling read operations

## 8. Testing Strategy

### 8.1 Unit Testing
- Frontend: Jest + React Testing Library
- Backend: Mocha/Chai or Jest

### 8.2 Integration Testing
- API tests with Supertest
- Database integration tests
- Third-party API mocking

### 8.3 End-to-End Testing
- Cypress for critical user flows
- Cross-browser testing
- Mobile device testing

## 9. Monitoring and Logging

### 9.1 Application Monitoring
- Error tracking with Sentry
- Performance monitoring with New Relic
- Custom event tracking for business metrics

### 9.2 Logging Strategy
- Structured logging with Winston
- Log levels (debug, info, warn, error)
- Centralized log storage (ELK stack or cloud service)
- Request ID tracking across services

## 10. Implementation Plan

### 10.1 Phase 1: Core Infrastructure
- Project scaffolding
- Authentication system
- Basic bookmark CRUD
- Simple collections
- Minimal UI

### 10.2 Phase 2: Feature Implementation
- Advanced organization features
- Search functionality
- Import/export
- Responsive design
- Theme support
- Browser extension

### 10.3 Phase 3: Advanced Features
- Google Drive integration
- Analytics
- Collaboration features
- API for third-party integrations
- Performance optimizations

## 11. API Contract Examples

### 11.1 Create Bookmark Request
```json
POST /api/v1/bookmarks
Content-Type: application/json
Authorization: Bearer <jwt>

{
  "url": "https://example.com",
  "title": "Example Website",
  "description": "This is an example website",
  "categoryId": "60d21b4667d0d8992e610c85",
  "tags": ["example", "documentation"]
}
```

### 11.2 Create Bookmark Response
```json
201 Created
Content-Type: application/json

{
  "id": "60d21b4667d0d8992e610c87",
  "url": "https://example.com",
  "title": "Example Website",
  "description": "This is an example website",
  "favicon": "https://example.com/favicon.ico",
  "categoryId": "60d21b4667d0d8992e610c85",
  "tags": ["example", "documentation"],
  "createdAt": "2023-06-22T10:30:00Z"
}
```

## 12. Appendix

### 12.1 Technology Stack Summary
- **Frontend**: React, TypeScript, Redux/Context, Material UI
- **Backend**: Node.js, Express, JWT, MongoDB
- **Testing**: Jest, React Testing Library, Cypress
- **DevOps**: Docker, GitHub Actions, AWS
- **External APIs**: Google Drive, OAuth providers

### 12.2 Development Environment Setup
1. Install Node.js (v16+)
2. Install MongoDB
3. Clone repository
4. Install dependencies (`npm install`)
5. Set up environment variables
6. Run development server (`npm run dev`)

### 12.3 Coding Standards
- ESLint configuration
- Prettier formatting
- TypeScript strictness
- Component naming conventions
- File structure guidelines
# BookMark App - Technical Design Document

## 1. Architecture Overview

### 1.1 System Architecture
![System Architecture](https://placeholder-for-architecture-diagram.com)

The BookMark App follows a modern three-tier architecture:

- **Frontend**: React.js single-page application (SPA)
- **Backend**: Node.js/Express.js RESTful API
- **Database**: SQLite relational database
- **External Services**: Google Drive API, Authentication providers

### 1.2 Deployment Architecture

- **Frontend**: Static assets served through CDN
- **Backend**: Containerized microservices via Docker
- **Database**: SQLite file-based database
- **CI/CD**: GitHub Actions pipeline with automated testing
- **Hosting**: AWS (EC2, S3, CloudFront) or similar cloud provider

## 2. Frontend Design

### 2.1 Component Structure

```
src/
├── assets/             # Static assets (icons, images)
├── components/         # Reusable UI components
│   ├── common/         # Shared components (Button, Input, etc.)
│   ├── layout/         # Layout components (Sidebar, Header, etc.)
│   └── features/       # Feature-specific components
├── contexts/           # React context providers
├── hooks/              # Custom React hooks
├── pages/              # Page components
├── services/           # API client and external service integrations
├── store/              # State management (Redux or Context)
├── styles/             # Global styles and themes
├── types/              # TypeScript type definitions
└── utils/              # Utility functions
```

### 2.2 State Management

- **Application State**: Redux for global app state
  - Auth state
  - User preferences
  - Bookmark collections
- **Component State**: React hooks for local component state
- **Server State**: React Query for API data fetching, caching, and synchronization

### 2.3 Routing Structure

- `/` - Dashboard/Home
- `/login` - User login
- `/register` - User registration
- `/bookmarks` - Main bookmark view
- `/bookmarks/:collectionId` - Specific collection view
- `/bookmarks/:collectionId/:bookmarkId` - Individual bookmark detail
- `/settings` - User settings
- `/analytics` - Analytics dashboard

### 2.4 UI Component Library

- Material UI or Chakra UI as the base component library
- Custom theme extension for brand identity
- Responsive design with mobile-first approach

## 3. Backend Design

### 3.0 Database Configuration

- **ORM**: Sequelize or TypeORM for SQLite integration
- **Migrations**: Database schema version control
- **Connection Pool**: Configured for optimal performance
- **Transaction Support**: ACID-compliant operations for data integrity

### 3.1 API Structure

#### Base URL: `/api/v1`

#### Authentication Endpoints
- `POST /auth/register` - User registration
- `POST /auth/login` - User login
- `POST /auth/refresh` - Refresh access token
- `POST /auth/forgot-password` - Password reset request
- `POST /auth/reset-password` - Password reset

#### Bookmark Endpoints
- `GET /bookmarks` - List bookmarks (with filtering/pagination)
- `POST /bookmarks` - Create bookmark
- `GET /bookmarks/:id` - Get bookmark details
- `PUT /bookmarks/:id` - Update bookmark
- `DELETE /bookmarks/:id` - Delete bookmark

#### Collection Endpoints
- `GET /collections` - List collections
- `POST /collections` - Create collection
- `GET /collections/:id` - Get collection details
- `PUT /collections/:id` - Update collection
- `DELETE /collections/:id` - Delete collection
- `POST /collections/:id/bookmarks` - Add bookmark to collection
- `DELETE /collections/:id/bookmarks/:bookmarkId` - Remove bookmark from collection

#### Sharing Endpoints
- `POST /share/bookmarks/:id` - Share a bookmark
- `POST /share/collections/:id` - Share a collection
- `GET /share/:shareId` - Access shared item

#### Import/Export Endpoints
- `POST /import/browser` - Import from browser
- `POST /import/html` - Import from HTML file
- `GET /export/:format` - Export bookmarks

#### Google Drive Integration
- `GET /drive/auth` - Initiate OAuth flow
- `POST /drive/backup` - Create backup
- `GET /drive/backups` - List backups
- `POST /drive/restore/:backupId` - Restore from backup

#### Analytics Endpoints
- `GET /analytics/usage` - Get usage statistics
- `GET /analytics/bookmarks` - Get bookmark analytics

### 3.2 Middleware Stack

1. **Request Logging**: Morgan/Winston for request logging
2. **Body Parsing**: Express body parser for JSON/form data
3. **Authentication**: JWT verification middleware
4. **Error Handling**: Centralized error handling middleware
5. **Compression**: Response compression
6. **CORS**: Cross-origin resource sharing configuration

### 3.3 Authentication Flow

1. User registers or logs in
2. Server validates credentials and issues JWT (access token + refresh token)
3. Access token included in Authorization header for protected requests
4. Refresh token used to obtain new access tokens when expired
5. Social login (Google, Facebook) implemented via OAuth 2.0

## 4. Database Design

### 4.1 Schema Definition

#### User Table

```sql
CREATE TABLE users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  first_name TEXT,
  last_name TEXT,
  avatar TEXT,
  theme TEXT DEFAULT 'light',
  default_view TEXT DEFAULT 'grid',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### Social Profiles Table

```sql
CREATE TABLE social_profiles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  provider TEXT NOT NULL,
  provider_id TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE(user_id, provider)
);
```

#### Bookmarks Table

```sql
CREATE TABLE bookmarks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  url TEXT NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  favicon TEXT,
  screenshot TEXT,
  notes TEXT,
  is_archived BOOLEAN DEFAULT 0,
  is_favorite BOOLEAN DEFAULT 0,
  source TEXT,
  content_type TEXT,
  visit_count INTEGER DEFAULT 0,
  last_visited TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE(user_id, url)
);
```

#### Tags Table

```sql
CREATE TABLE tags (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE(user_id, name)
);
```

#### Bookmark Tags Table (Junction Table)

```sql
CREATE TABLE bookmark_tags (
  bookmark_id INTEGER NOT NULL,
  tag_id INTEGER NOT NULL,
  PRIMARY KEY (bookmark_id, tag_id),
  FOREIGN KEY (bookmark_id) REFERENCES bookmarks(id) ON DELETE CASCADE,
  FOREIGN KEY (tag_id) REFERENCES tags(id) ON DELETE CASCADE
);
```

#### Collections Table

```sql
CREATE TABLE collections (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  color TEXT,
  icon TEXT,
  is_public BOOLEAN DEFAULT 0,
  parent_id INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (parent_id) REFERENCES collections(id) ON DELETE SET NULL,
  UNIQUE(user_id, name)
);
```

#### Collection Bookmarks Table (Junction Table)

```sql
CREATE TABLE collection_bookmarks (
  collection_id INTEGER NOT NULL,
  bookmark_id INTEGER NOT NULL,
  added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (collection_id, bookmark_id),
  FOREIGN KEY (collection_id) REFERENCES collections(id) ON DELETE CASCADE,
  FOREIGN KEY (bookmark_id) REFERENCES bookmarks(id) ON DELETE CASCADE
);
```

#### Shares Table

```sql
CREATE TABLE shares (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  resource_type TEXT NOT NULL, -- 'bookmark' or 'collection'
  resource_id INTEGER NOT NULL,
  share_code TEXT UNIQUE NOT NULL,
  can_read BOOLEAN DEFAULT 1,
  can_write BOOLEAN DEFAULT 0,
  can_admin BOOLEAN DEFAULT 0,
  expires_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
```

#### Backups Table

```sql
CREATE TABLE backups (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  drive_file_id TEXT NOT NULL,
  file_name TEXT NOT NULL,
  size INTEGER NOT NULL,
  bookmark_count INTEGER NOT NULL,
  collection_count INTEGER NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
```

### 4.2 Indexing Strategy

```sql
-- Basic indexes
CREATE INDEX idx_bookmarks_user_id ON bookmarks(user_id);
CREATE INDEX idx_collections_user_id ON collections(user_id);
CREATE INDEX idx_collections_parent_id ON collections(parent_id);
CREATE INDEX idx_shares_resource ON shares(resource_type, resource_id);
CREATE INDEX idx_shares_user_id ON shares(user_id);

-- Full-text search indexes (using SQLite FTS5 extension)
CREATE VIRTUAL TABLE bookmarks_fts USING fts5(
  title, 
  description, 
  notes,
  content='bookmarks',
  content_rowid='id'
);
```

### 4.3 Data Relationships

- User to Bookmarks: One-to-Many (via foreign key user_id in bookmarks table)
- User to Collections: One-to-Many (via foreign key user_id in collections table)
- Collection to Bookmarks: Many-to-Many (via junction table collection_bookmarks)
- Collection to Collections (nested): One-to-Many (via self-referencing parent_id)

## 5. Integration Designs

### 5.1 Google Drive Integration

#### Authentication Flow
1. User initiates Google Drive connection
2. App redirects to Google OAuth consent screen
3. User grants permissions
4. Google returns auth code
5. Backend exchanges code for access/refresh tokens
6. Store refresh token in user document
7. Use access token for API requests

#### Backup Process
1. Export user's bookmarks and collections to JSON
2. Create timestamped backup file
3. Upload to user's Google Drive via API
4. Store reference to drive file in Backup model

#### Restore Process
1. Retrieve backup file from Google Drive
2. Parse backup data
3. Create transaction for database operations
4. Replace or merge data according to user preference
5. Update user's bookmarks and collections

### 5.2 Browser Extension Integration

#### Extension Architecture
- Background script for event handling
- Content script for page interaction
- Popup UI for bookmark creation
- Storage sync for user data

#### Communication Flow
1. Extension captures current page data
2. User adds bookmark via extension popup
3. Extension sends data to API with user's JWT
4. API creates bookmark and returns confirmation
5. Extension updates local state

## 6. Security Implementation

### 6.1 Authentication Security
- Passwords hashed with bcrypt (10+ rounds)
- JWT with short expiration for access tokens
- HTTP-only, secure cookies for refresh tokens
- CSRF token validation for sensitive operations

### 6.2 API Security
- Input validation with Joi/Yup
- Rate limiting for authentication endpoints
- Content Security Policy headers
- Helmet.js for HTTP header security

### 6.3 Data Security
- HTTPS for all communications
- Field-level encryption for sensitive data
- Sanitization of user-generated content
- Principle of least privilege for DB operations

## 7. Performance Optimizations

### 7.1 Frontend Optimizations
- Code splitting by route
- Lazy loading of components
- Virtualized lists for large bookmark collections
- Image optimization for screenshots/favicons
- Service worker for offline capability

### 7.2 Backend Optimizations
- Response caching with Redis
- Database query optimization
- Connection pooling
- Pagination for large result sets
- Background processing for heavy operations

### 7.3 Database Optimizations
- Appropriate indexing
- Denormalization where appropriate
- Document embedding vs references based on access patterns
- Read replicas for scaling read operations

## 8. Testing Strategy

### 8.1 Unit Testing
- Frontend: Jest + React Testing Library
- Backend: Mocha/Chai or Jest

### 8.2 Integration Testing
- API tests with Supertest
- Database integration tests
- Third-party API mocking

### 8.3 End-to-End Testing
- Cypress for critical user flows
- Cross-browser testing
- Mobile device testing

## 9. Monitoring and Logging

### 9.1 Application Monitoring
- Error tracking with Sentry
- Performance monitoring with New Relic
- Custom event tracking for business metrics

### 9.2 Logging Strategy
- Structured logging with Winston
- Log levels (debug, info, warn, error)
- Centralized log storage (ELK stack or cloud service)
- Request ID tracking across services

## 10. Implementation Plan

### 10.1 Phase 1: Core Infrastructure
- Project scaffolding
- Authentication system
- Basic bookmark CRUD
- Simple collections
- Minimal UI

### 10.2 Phase 2: Feature Implementation
- Advanced organization features
- Search functionality
- Import/export
- Responsive design
- Theme support
- Browser extension

### 10.3 Phase 3: Advanced Features
- Google Drive integration
- Analytics
- Collaboration features
- API for third-party integrations
- Performance optimizations

## 11. API Contract Examples

### 11.1 Create Bookmark Request
```json
POST /api/v1/bookmarks
Content-Type: application/json
Authorization: Bearer <jwt>

{
  "url": "https://example.com",
  "title": "Example Website",
  "description": "This is an example website",
  "categoryId": "60d21b4667d0d8992e610c85",
  "tags": ["example", "documentation"]
}
```

### 11.2 Create Bookmark Response
```json
201 Created
Content-Type: application/json

{
  "id": "60d21b4667d0d8992e610c87",
  "url": "https://example.com",
  "title": "Example Website",
  "description": "This is an example website",
  "favicon": "https://example.com/favicon.ico",
  "categoryId": "60d21b4667d0d8992e610c85",
  "tags": ["example", "documentation"],
  "createdAt": "2023-06-22T10:30:00Z"
}
```

## 12. Appendix

### 12.1 Technology Stack Summary
- **Frontend**: React, TypeScript, Redux/Context, Material UI
- **Backend**: Node.js, Express, JWT, MongoDB
- **Testing**: Jest, React Testing Library, Cypress
- **DevOps**: Docker, GitHub Actions, AWS
- **External APIs**: Google Drive, OAuth providers

### 12.2 Development Environment Setup
1. Install Node.js (v16+)
2. Install MongoDB
3. Clone repository
4. Install dependencies (`npm install`)
5. Set up environment variables
6. Run development server (`npm run dev`)

### 12.3 Coding Standards
- ESLint configuration
- Prettier formatting
- TypeScript strictness
- Component naming conventions
- File structure guidelines
