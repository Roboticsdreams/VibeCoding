const fs = require('fs');
const path = require('path');
const { sequelize } = require('../models');

const dbDir = path.join(__dirname, '../db');

// Create db directory if it doesn't exist
if (!fs.existsSync(dbDir)) {
  console.log('Creating db directory...');
  fs.mkdirSync(dbDir);
}

// Initialize database
const initDb = async () => {
  try {
    // Sync all models with force option
    await sequelize.sync({ force: true });
    console.log('Database synced successfully!');
  } catch (error) {
    console.error('Error initializing database:', error);
  } finally {
    process.exit();
  }
};

initDb();
