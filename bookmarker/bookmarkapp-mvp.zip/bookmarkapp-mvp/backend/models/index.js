const sequelize = require('../config/db');
const User = require('./User');
const Bookmark = require('./Bookmark');
const Collection = require('./Collection');
const Tag = require('./Tag');
const CollectionBookmark = require('./CollectionBookmark');
const BookmarkTag = require('./BookmarkTag');

// Define relationships
User.hasMany(Bookmark, { foreignKey: 'userId', onDelete: 'CASCADE' });
Bookmark.belongsTo(User, { foreignKey: 'userId' });

User.hasMany(Collection, { foreignKey: 'userId', onDelete: 'CASCADE' });
Collection.belongsTo(User, { foreignKey: 'userId' });

User.hasMany(Tag, { foreignKey: 'userId', onDelete: 'CASCADE' });
Tag.belongsTo(User, { foreignKey: 'userId' });

// Self-referencing relationship for nested collections
Collection.hasMany(Collection, { foreignKey: 'parentId', as: 'childCollections' });
Collection.belongsTo(Collection, { foreignKey: 'parentId', as: 'parentCollection' });

// Many-to-Many: Collections and Bookmarks
Collection.belongsToMany(Bookmark, { 
  through: CollectionBookmark, 
  foreignKey: 'collectionId',
  otherKey: 'bookmarkId'
});
Bookmark.belongsToMany(Collection, { 
  through: CollectionBookmark, 
  foreignKey: 'bookmarkId',
  otherKey: 'collectionId'
});

// Many-to-Many: Bookmarks and Tags
Bookmark.belongsToMany(Tag, { 
  through: BookmarkTag, 
  foreignKey: 'bookmarkId',
  otherKey: 'tagId'
});
Tag.belongsToMany(Bookmark, { 
  through: BookmarkTag, 
  foreignKey: 'tagId',
  otherKey: 'bookmarkId'
});

module.exports = {
  sequelize,
  User,
  Bookmark,
  Collection,
  Tag,
  CollectionBookmark,
  BookmarkTag
};
