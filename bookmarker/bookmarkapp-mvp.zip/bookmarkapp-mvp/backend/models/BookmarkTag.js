const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const BookmarkTag = sequelize.define('BookmarkTag', {
  bookmarkId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'Bookmarks',
      key: 'id'
    },
    primaryKey: true
  },
  tagId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'Tags',
      key: 'id'
    },
    primaryKey: true
  }
}, {
  timestamps: false
});

module.exports = BookmarkTag;
