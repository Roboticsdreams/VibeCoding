const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const Bookmark = sequelize.define('Bookmark', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  userId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'Users',
      key: 'id'
    }
  },
  url: {
    type: DataTypes.STRING,
    allowNull: false,
    validate: {
      customUrlValidator(value) {
        // Basic URL pattern: Allow URLs with or without protocol
        // Will prepend http:// if missing
        if (!value) {
          throw new Error('URL cannot be empty');
        }
        
        // Check if URL has protocol, if not add http://
        if (!/^https?:\/\//i.test(value)) {
          this.url = 'http://' + value;
        }
        
        // Additional validation could be added here if needed
      }
    }
  },
  title: {
    type: DataTypes.STRING,
    allowNull: false
  },
  description: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  favicon: {
    type: DataTypes.STRING,
    allowNull: true
  },
  screenshot: {
    type: DataTypes.STRING,
    allowNull: true
  },
  notes: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  isArchived: {
    type: DataTypes.BOOLEAN,
    defaultValue: false
  },
  isFavorite: {
    type: DataTypes.BOOLEAN,
    defaultValue: false
  },
  source: {
    type: DataTypes.STRING,
    allowNull: true
  },
  contentType: {
    type: DataTypes.STRING,
    allowNull: true
  },
  visitCount: {
    type: DataTypes.INTEGER,
    defaultValue: 0
  },
  lastVisited: {
    type: DataTypes.DATE,
    allowNull: true
  }
}, {
  timestamps: true,
  indexes: [
    {
      unique: true,
      fields: ['userId', 'url']
    }
  ]
});

module.exports = Bookmark;
