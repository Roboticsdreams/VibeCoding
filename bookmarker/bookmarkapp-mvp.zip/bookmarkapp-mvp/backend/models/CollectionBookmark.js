const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const CollectionBookmark = sequelize.define('CollectionBookmark', {
  collectionId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'Collections',
      key: 'id'
    },
    primaryKey: true
  },
  bookmarkId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'Bookmarks',
      key: 'id'
    },
    primaryKey: true
  },
  addedAt: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW
  }
}, {
  timestamps: false
});

module.exports = CollectionBookmark;
