# BookMark App API Documentation

This directory contains information about the API endpoints and how to use them.

## API Testing Tools

### Postman Collection

A Postman collection is provided to help with API testing. To use it:

1. Import the `bookmarkapp.postman_collection.json` file into Postman
2. Import the `bookmarkapp.postman_environment.json` environment file
3. Select the "BookMark App Local" environment
4. Register a new user or login using the authentication endpoints
5. When you receive a token, copy it and set the `token` environment variable

### Swagger Documentation

The API documentation is generated using Swagger/OpenAPI. When the server is running, you can access the interactive documentation at:

```plaintext
http://localhost:5000/api-docs
```

### Features

- Interactive API documentation
- Try out API endpoints directly from the browser
- Authentication using Bearer token
- Complete endpoint documentation

### Authentication

Most endpoints require authentication. To authenticate:

1. Create a user using the `/api/auth/register` endpoint
2. Login with the `/api/auth/login` endpoint to get a JWT token
3. Click the "Authorize" button in Swagger UI
4. Enter your token in the format: `Bearer your_token_here`
5. Click "Authorize" to enable authenticated requests

### Available Endpoints

#### Authentication

- `POST /api/auth/register` - Register a new user
- `POST /api/auth/login` - Login a user
- `GET /api/auth/me` - Get current user info

#### Bookmarks

- `GET /api/bookmarks` - Get all bookmarks
- `POST /api/bookmarks` - Create a bookmark
- `GET /api/bookmarks/:id` - Get a specific bookmark
- `PUT /api/bookmarks/:id` - Update a bookmark
- `DELETE /api/bookmarks/:id` - Delete a bookmark

#### Collections

- `GET /api/collections` - Get all collections
- `POST /api/collections` - Create a collection
- `GET /api/collections/:id` - Get a specific collection
- `PUT /api/collections/:id` - Update a collection
- `DELETE /api/collections/:id` - Delete a collection
- `POST /api/collections/:id/bookmarks` - Add a bookmark to a collection
- `DELETE /api/collections/:id/bookmarks/:bookmarkId` - Remove a bookmark from a collection

#### Tags

- `GET /api/tags` - Get all tags
- `POST /api/tags` - Create a tag
- `PUT /api/tags/:id` - Update a tag
- `DELETE /api/tags/:id` - Delete a tag
- `GET /api/tags/:id/bookmarks` - Get bookmarks by tag
- `POST /api/tags/:id/bookmarks` - Add a tag to a bookmark
- `DELETE /api/tags/:id/bookmarks/:bookmarkId` - Remove a tag from a bookmark
