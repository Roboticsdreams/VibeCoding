const express = require('express');
const dotenv = require('dotenv');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const path = require('path');

// Load env vars
dotenv.config();

// Database connection
const { sequelize } = require('./models');

// Route files
const authRoutes = require('./routes/auth');
const bookmarkRoutes = require('./routes/bookmarks');
const collectionRoutes = require('./routes/collections');
const tagRoutes = require('./routes/tags');
const docsRoutes = require('./routes/docs');

// Swagger documentation
const swaggerDocs = require('./config/swagger');

const app = express();

// Body parser
app.use(express.json());

// Security headers
app.use(helmet());

// CORS
app.use(cors());

// Logging in development
if (process.env.NODE_ENV === 'development') {
  app.use(morgan('dev'));
}

// Mount routers
app.use('/api/auth', authRoutes);
app.use('/api/bookmarks', bookmarkRoutes);
app.use('/api/collections', collectionRoutes);
app.use('/api/tags', tagRoutes);
app.use('/api', docsRoutes);

// Base route
app.get('/', (req, res) => {
  res.send('BookMark API is running - Visit /api for API information and /api-docs for full documentation');
});

const PORT = process.env.PORT || 5000;

// Sync database and start server
const startServer = async () => {
  try {
    await sequelize.sync();
    console.log('Database synced');
    
    app.listen(PORT, () => {
      console.log(`Server running in ${process.env.NODE_ENV} mode on port ${PORT}`);
      
      // Initialize Swagger docs
      swaggerDocs(app);
    });
  } catch (error) {
    console.error('Unable to start server:', error);
  }
};

startServer();
