const express = require('express');
const router = express.Router();

/**
 * @swagger
 * tags:
 *   name: API Documentation
 *   description: API documentation for the BookMark app
 */

/**
 * @swagger
 * /api:
 *   get:
 *     summary: Get API information
 *     tags: [API Documentation]
 *     responses:
 *       200:
 *         description: API information
 */
router.get('/', (req, res) => {
  res.json({
    name: 'BookMark App API',
    version: '1.0.0',
    description: 'API for managing bookmarks, collections, and tags',
    documentation: `${req.protocol}://${req.get('host')}/api-docs`,
    endpoints: {
      auth: '/api/auth',
      bookmarks: '/api/bookmarks',
      collections: '/api/collections',
      tags: '/api/tags'
    }
  });
});

module.exports = router;
