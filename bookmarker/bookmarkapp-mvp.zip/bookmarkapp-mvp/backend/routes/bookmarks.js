const express = require('express');
const {
  getBookmarks,
  getBookmark,
  createBookmark,
  updateBookmark,
  deleteBookmark
} = require('../controllers/bookmarks');
const { protect } = require('../middleware/auth');

const router = express.Router();

/**
 * @swagger
 * components:
 *   schemas:
 *     Bookmark:
 *       type: object
 *       required:
 *         - url
 *         - title
 *       properties:
 *         id:
 *           type: integer
 *           description: The auto-generated id of the bookmark
 *         userId:
 *           type: integer
 *           description: User ID who owns this bookmark
 *         url:
 *           type: string
 *           description: The URL of the bookmark
 *         title:
 *           type: string
 *           description: The title of the bookmark
 *         description:
 *           type: string
 *           description: Optional description of the bookmark
 *         favicon:
 *           type: string
 *           description: URL to the favicon
 *         screenshot:
 *           type: string
 *           description: URL to the screenshot
 *         notes:
 *           type: string
 *           description: User notes for the bookmark
 *         isArchived:
 *           type: boolean
 *           description: Whether the bookmark is archived
 *         isFavorite:
 *           type: boolean
 *           description: Whether the bookmark is marked as favorite
 *         source:
 *           type: string
 *           description: Source of the bookmark
 *         createdAt:
 *           type: string
 *           format: date
 *           description: The date the bookmark was created
 *         updatedAt:
 *           type: string
 *           format: date
 *           description: The date the bookmark was last updated
 *       example:
 *         id: 1
 *         userId: 1
 *         url: https://example.com
 *         title: Example Website
 *         description: An example website
 *         favicon: https://example.com/favicon.ico
 *         notes: My notes about this website
 *         isFavorite: true
 *         isArchived: false
 *         createdAt: 2023-01-01T00:00:00.000Z
 *         updatedAt: 2023-01-01T00:00:00.000Z
 */

/**
 * @swagger
 * tags:
 *   name: Bookmarks
 *   description: Bookmark management API
 */

/**
 * @swagger
 * /api/bookmarks:
 *   get:
 *     summary: Get all bookmarks for the authenticated user
 *     tags: [Bookmarks]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: search
 *         schema:
 *           type: string
 *         description: Search term to filter bookmarks
 *       - in: query
 *         name: favorite
 *         schema:
 *           type: boolean
 *         description: Filter by favorite status
 *       - in: query
 *         name: collectionId
 *         schema:
 *           type: integer
 *         description: Filter by collection ID
 *       - in: query
 *         name: tagId
 *         schema:
 *           type: integer
 *         description: Filter by tag ID
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *         description: Page number
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 20
 *         description: Number of bookmarks per page
 *     responses:
 *       200:
 *         description: A list of bookmarks
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 count:
 *                   type: integer
 *                 bookmarks:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/Bookmark'
 *                 totalPages:
 *                   type: integer
 *                 currentPage:
 *                   type: integer
 *       401:
 *         description: Not authorized
 *
 *   post:
 *     summary: Create a new bookmark
 *     tags: [Bookmarks]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - url
 *               - title
 *             properties:
 *               url:
 *                 type: string
 *                 description: URL of the bookmark
 *               title:
 *                 type: string
 *                 description: Title of the bookmark
 *               description:
 *                 type: string
 *                 description: Description of the bookmark
 *               favicon:
 *                 type: string
 *                 description: URL to the favicon
 *               notes:
 *                 type: string
 *                 description: User notes
 *               isFavorite:
 *                 type: boolean
 *                 description: Whether to mark as favorite
 *               tags:
 *                 type: array
 *                 items:
 *                   type: string
 *                 description: Array of tag names
 *               collectionIds:
 *                 type: array
 *                 items:
 *                   type: integer
 *                 description: Array of collection IDs
 *     responses:
 *       201:
 *         description: Bookmark created successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Bookmark'
 *       400:
 *         description: Invalid input data
 *       401:
 *         description: Not authorized
 */
router.route('/')
  .get(protect, getBookmarks)
  .post(protect, createBookmark);

/**
 * @swagger
 * /api/bookmarks/{id}:
 *   get:
 *     summary: Get a bookmark by ID
 *     tags: [Bookmarks]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: Bookmark ID
 *     responses:
 *       200:
 *         description: Bookmark details
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Bookmark'
 *       401:
 *         description: Not authorized
 *       404:
 *         description: Bookmark not found
 *
 *   put:
 *     summary: Update a bookmark
 *     tags: [Bookmarks]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: Bookmark ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               url:
 *                 type: string
 *                 description: URL of the bookmark
 *               title:
 *                 type: string
 *                 description: Title of the bookmark
 *               description:
 *                 type: string
 *                 description: Description of the bookmark
 *               favicon:
 *                 type: string
 *                 description: URL to the favicon
 *               notes:
 *                 type: string
 *                 description: User notes
 *               isFavorite:
 *                 type: boolean
 *                 description: Whether to mark as favorite
 *               tags:
 *                 type: array
 *                 items:
 *                   type: string
 *                 description: Array of tag names
 *               collectionIds:
 *                 type: array
 *                 items:
 *                   type: integer
 *                 description: Array of collection IDs
 *     responses:
 *       200:
 *         description: Bookmark updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Bookmark'
 *       400:
 *         description: Invalid input data
 *       401:
 *         description: Not authorized
 *       404:
 *         description: Bookmark not found
 *
 *   delete:
 *     summary: Delete a bookmark
 *     tags: [Bookmarks]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: Bookmark ID
 *     responses:
 *       200:
 *         description: Bookmark deleted successfully
 *       401:
 *         description: Not authorized
 *       404:
 *         description: Bookmark not found
 */
router.route('/:id')
  .get(protect, getBookmark)
  .put(protect, updateBookmark)
  .delete(protect, deleteBookmark);

module.exports = router;
