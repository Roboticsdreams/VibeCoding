const express = require('express');
const {
  getCollections,
  getCollection,
  createCollection,
  updateCollection,
  deleteCollection,
  addBookmarkToCollection,
  removeBookmarkFromCollection
} = require('../controllers/collections');
const { protect } = require('../middleware/auth');

const router = express.Router();

router.route('/')
  .get(protect, getCollections)
  .post(protect, createCollection);

router.route('/:id')
  .get(protect, getCollection)
  .put(protect, updateCollection)
  .delete(protect, deleteCollection);

router.route('/:id/bookmarks')
  .post(protect, addBookmarkToCollection);

router.route('/:id/bookmarks/:bookmarkId')
  .delete(protect, removeBookmarkFromCollection);

module.exports = router;
