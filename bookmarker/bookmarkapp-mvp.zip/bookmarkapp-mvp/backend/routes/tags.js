const express = require('express');
const {
  getTags,
  createTag,
  updateTag,
  deleteTag,
  getBookmarksByTag,
  addTagToBookmark,
  removeTagFromBookmark
} = require('../controllers/tags');
const { protect } = require('../middleware/auth');

const router = express.Router();

router.route('/')
  .get(protect, getTags)
  .post(protect, createTag);

router.route('/:id')
  .put(protect, updateTag)
  .delete(protect, deleteTag);

router.route('/:id/bookmarks')
  .get(protect, getBookmarksByTag)
  .post(protect, addTagToBookmark);

router.route('/:id/bookmarks/:bookmarkId')
  .delete(protect, removeTagFromBookmark);

module.exports = router;
