const { Collection, Bookmark } = require('../models');

// @desc    Get all collections for a user
// @route   GET /api/collections
// @access  Private
exports.getCollections = async (req, res) => {
  try {
    const collections = await Collection.findAll({
      where: { userId: req.user.id },
      order: [['name', 'ASC']]
    });
    
    res.json(collections);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server Error' });
  }
};

// @desc    Get a single collection with bookmarks
// @route   GET /api/collections/:id
// @access  Private
exports.getCollection = async (req, res) => {
  try {
    const collection = await Collection.findOne({
      where: { 
        id: req.params.id,
        userId: req.user.id 
      },
      include: [
        { 
          model: Bookmark,
          through: { attributes: [] }
        },
        {
          model: Collection,
          as: 'childCollections'
        }
      ]
    });
    
    if (!collection) {
      return res.status(404).json({ message: 'Collection not found' });
    }
    
    res.json(collection);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server Error' });
  }
};

// @desc    Create a new collection
// @route   POST /api/collections
// @access  Private
exports.createCollection = async (req, res) => {
  try {
    const { name, description, color, icon, isPublic, parentId } = req.body;
    
    // If parentId is provided, check if it belongs to the user
    if (parentId) {
      const parentCollection = await Collection.findOne({
        where: { 
          id: parentId,
          userId: req.user.id 
        }
      });
      
      if (!parentCollection) {
        return res.status(404).json({ message: 'Parent collection not found' });
      }
    }
    
    // Create collection
    const collection = await Collection.create({
      userId: req.user.id,
      name,
      description,
      color,
      icon,
      isPublic,
      parentId
    });
    
    res.status(201).json(collection);
  } catch (error) {
    console.error(error);
    
    // Handle unique constraint error
    if (error.name === 'SequelizeUniqueConstraintError') {
      return res.status(400).json({ message: 'A collection with that name already exists' });
    }
    
    res.status(500).json({ message: 'Server Error' });
  }
};

// @desc    Update a collection
// @route   PUT /api/collections/:id
// @access  Private
exports.updateCollection = async (req, res) => {
  try {
    const { name, description, color, icon, isPublic, parentId } = req.body;
    
    // Find collection
    const collection = await Collection.findOne({
      where: { 
        id: req.params.id,
        userId: req.user.id 
      }
    });
    
    if (!collection) {
      return res.status(404).json({ message: 'Collection not found' });
    }
    
    // If parentId is provided and changed, check if it belongs to the user and is not the same collection
    if (parentId && parentId !== collection.parentId) {
      // Prevent circular references
      if (parentId == collection.id) {
        return res.status(400).json({ message: 'Cannot set a collection as its own parent' });
      }
      
      const parentCollection = await Collection.findOne({
        where: { 
          id: parentId,
          userId: req.user.id 
        }
      });
      
      if (!parentCollection) {
        return res.status(404).json({ message: 'Parent collection not found' });
      }
    }
    
    // Update collection
    await collection.update({
      name: name || collection.name,
      description: description !== undefined ? description : collection.description,
      color: color !== undefined ? color : collection.color,
      icon: icon !== undefined ? icon : collection.icon,
      isPublic: isPublic !== undefined ? isPublic : collection.isPublic,
      parentId: parentId !== undefined ? parentId : collection.parentId
    });
    
    res.json(collection);
  } catch (error) {
    console.error(error);
    
    // Handle unique constraint error
    if (error.name === 'SequelizeUniqueConstraintError') {
      return res.status(400).json({ message: 'A collection with that name already exists' });
    }
    
    res.status(500).json({ message: 'Server Error' });
  }
};

// @desc    Delete a collection
// @route   DELETE /api/collections/:id
// @access  Private
exports.deleteCollection = async (req, res) => {
  try {
    const collection = await Collection.findOne({
      where: { 
        id: req.params.id,
        userId: req.user.id 
      }
    });
    
    if (!collection) {
      return res.status(404).json({ message: 'Collection not found' });
    }
    
    // Check if there are child collections and update their parentId to null
    await Collection.update(
      { parentId: null },
      { where: { parentId: collection.id } }
    );
    
    await collection.destroy();
    
    res.json({ message: 'Collection removed' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server Error' });
  }
};

// @desc    Add bookmark to collection
// @route   POST /api/collections/:id/bookmarks
// @access  Private
exports.addBookmarkToCollection = async (req, res) => {
  try {
    const { bookmarkId } = req.body;
    
    // Find collection
    const collection = await Collection.findOne({
      where: { 
        id: req.params.id,
        userId: req.user.id 
      }
    });
    
    if (!collection) {
      return res.status(404).json({ message: 'Collection not found' });
    }
    
    // Find bookmark
    const bookmark = await Bookmark.findOne({
      where: { 
        id: bookmarkId,
        userId: req.user.id 
      }
    });
    
    if (!bookmark) {
      return res.status(404).json({ message: 'Bookmark not found' });
    }
    
    // Add bookmark to collection
    await collection.addBookmark(bookmark);
    
    res.json({ message: 'Bookmark added to collection' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server Error' });
  }
};

// @desc    Remove bookmark from collection
// @route   DELETE /api/collections/:id/bookmarks/:bookmarkId
// @access  Private
exports.removeBookmarkFromCollection = async (req, res) => {
  try {
    const collectionId = req.params.id;
    const bookmarkId = req.params.bookmarkId;
    
    // Find collection
    const collection = await Collection.findOne({
      where: { 
        id: collectionId,
        userId: req.user.id 
      }
    });
    
    if (!collection) {
      return res.status(404).json({ message: 'Collection not found' });
    }
    
    // Find bookmark
    const bookmark = await Bookmark.findOne({
      where: { 
        id: bookmarkId,
        userId: req.user.id 
      }
    });
    
    if (!bookmark) {
      return res.status(404).json({ message: 'Bookmark not found' });
    }
    
    // Remove bookmark from collection
    await collection.removeBookmark(bookmark);
    
    res.json({ message: 'Bookmark removed from collection' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server Error' });
  }
};
