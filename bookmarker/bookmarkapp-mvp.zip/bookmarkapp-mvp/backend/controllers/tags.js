const { Tag, Bookmark } = require('../models');

// @desc    Get all tags for a user
// @route   GET /api/tags
// @access  Private
exports.getTags = async (req, res) => {
  try {
    const tags = await Tag.findAll({
      where: { userId: req.user.id },
      order: [['name', 'ASC']]
    });
    
    res.json(tags);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server Error' });
  }
};

// @desc    Create a new tag
// @route   POST /api/tags
// @access  Private
exports.createTag = async (req, res) => {
  try {
    const { name } = req.body;
    
    // Create tag
    const tag = await Tag.create({
      userId: req.user.id,
      name
    });
    
    res.status(201).json(tag);
  } catch (error) {
    console.error(error);
    
    // Handle unique constraint error
    if (error.name === 'SequelizeUniqueConstraintError') {
      return res.status(400).json({ message: 'A tag with that name already exists' });
    }
    
    res.status(500).json({ message: 'Server Error' });
  }
};

// @desc    Update a tag
// @route   PUT /api/tags/:id
// @access  Private
exports.updateTag = async (req, res) => {
  try {
    const { name } = req.body;
    
    // Find tag
    const tag = await Tag.findOne({
      where: { 
        id: req.params.id,
        userId: req.user.id 
      }
    });
    
    if (!tag) {
      return res.status(404).json({ message: 'Tag not found' });
    }
    
    // Update tag
    await tag.update({
      name: name || tag.name
    });
    
    res.json(tag);
  } catch (error) {
    console.error(error);
    
    // Handle unique constraint error
    if (error.name === 'SequelizeUniqueConstraintError') {
      return res.status(400).json({ message: 'A tag with that name already exists' });
    }
    
    res.status(500).json({ message: 'Server Error' });
  }
};

// @desc    Delete a tag
// @route   DELETE /api/tags/:id
// @access  Private
exports.deleteTag = async (req, res) => {
  try {
    const tag = await Tag.findOne({
      where: { 
        id: req.params.id,
        userId: req.user.id 
      }
    });
    
    if (!tag) {
      return res.status(404).json({ message: 'Tag not found' });
    }
    
    await tag.destroy();
    
    res.json({ message: 'Tag removed' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server Error' });
  }
};

// @desc    Get bookmarks by tag
// @route   GET /api/tags/:id/bookmarks
// @access  Private
exports.getBookmarksByTag = async (req, res) => {
  try {
    const tag = await Tag.findOne({
      where: { 
        id: req.params.id,
        userId: req.user.id 
      },
      include: [
        { 
          model: Bookmark,
          through: { attributes: [] }
        }
      ]
    });
    
    if (!tag) {
      return res.status(404).json({ message: 'Tag not found' });
    }
    
    res.json(tag.Bookmarks);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server Error' });
  }
};

// @desc    Add tag to bookmark
// @route   POST /api/tags/:id/bookmarks
// @access  Private
exports.addTagToBookmark = async (req, res) => {
  try {
    const { bookmarkId } = req.body;
    
    // Find tag
    const tag = await Tag.findOne({
      where: { 
        id: req.params.id,
        userId: req.user.id 
      }
    });
    
    if (!tag) {
      return res.status(404).json({ message: 'Tag not found' });
    }
    
    // Find bookmark
    const bookmark = await Bookmark.findOne({
      where: { 
        id: bookmarkId,
        userId: req.user.id 
      }
    });
    
    if (!bookmark) {
      return res.status(404).json({ message: 'Bookmark not found' });
    }
    
    // Add tag to bookmark
    await tag.addBookmark(bookmark);
    
    res.json({ message: 'Tag added to bookmark' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server Error' });
  }
};

// @desc    Remove tag from bookmark
// @route   DELETE /api/tags/:id/bookmarks/:bookmarkId
// @access  Private
exports.removeTagFromBookmark = async (req, res) => {
  try {
    const tagId = req.params.id;
    const bookmarkId = req.params.bookmarkId;
    
    // Find tag
    const tag = await Tag.findOne({
      where: { 
        id: tagId,
        userId: req.user.id 
      }
    });
    
    if (!tag) {
      return res.status(404).json({ message: 'Tag not found' });
    }
    
    // Find bookmark
    const bookmark = await Bookmark.findOne({
      where: { 
        id: bookmarkId,
        userId: req.user.id 
      }
    });
    
    if (!bookmark) {
      return res.status(404).json({ message: 'Bookmark not found' });
    }
    
    // Remove tag from bookmark
    await tag.removeBookmark(bookmark);
    
    res.json({ message: 'Tag removed from bookmark' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server Error' });
  }
};
