const { Bookmark, Tag, Collection } = require('../models');
const { Op } = require('sequelize');

// @desc    Get all bookmarks for a user
// @route   GET /api/bookmarks
// @access  Private
exports.getBookmarks = async (req, res) => {
  try {
    const { search, favorite, collectionId, tagId, page = 1, limit = 20 } = req.query;
    const userId = req.user.id;
    
    const offset = (page - 1) * limit;
    
    // Build where clause
    let where = { userId };
    
    // Search functionality
    if (search) {
      where = {
        ...where,
        [Op.or]: [
          { title: { [Op.like]: `%${search}%` } },
          { description: { [Op.like]: `%${search}%` } },
          { url: { [Op.like]: `%${search}%` } },
          { notes: { [Op.like]: `%${search}%` } }
        ]
      };
    }
    
    // Filter by favorite
    if (favorite === 'true') {
      where.isFavorite = true;
    }
    
    // Build include array for associations
    let include = [];
    
    // Filter by collection
    if (collectionId) {
      include.push({
        model: Collection,
        where: { id: collectionId },
        attributes: [],
        through: { attributes: [] }
      });
    }
    
    // Filter by tag
    if (tagId) {
      include.push({
        model: Tag,
        where: { id: tagId },
        attributes: [],
        through: { attributes: [] }
      });
    }
    
    // Get bookmarks
    const bookmarks = await Bookmark.findAndCountAll({
      where,
      include,
      distinct: true,
      limit: parseInt(limit),
      offset,
      order: [['createdAt', 'DESC']]
    });
    
    res.json({
      count: bookmarks.count,
      bookmarks: bookmarks.rows,
      totalPages: Math.ceil(bookmarks.count / limit),
      currentPage: parseInt(page)
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server Error' });
  }
};

// @desc    Get a single bookmark
// @route   GET /api/bookmarks/:id
// @access  Private
exports.getBookmark = async (req, res) => {
  try {
    const bookmark = await Bookmark.findOne({
      where: { 
        id: req.params.id,
        userId: req.user.id 
      },
      include: [
        { model: Tag },
        { model: Collection }
      ]
    });
    
    if (!bookmark) {
      return res.status(404).json({ message: 'Bookmark not found' });
    }
    
    res.json(bookmark);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server Error' });
  }
};

// @desc    Create a new bookmark
// @route   POST /api/bookmarks
// @access  Private
exports.createBookmark = async (req, res) => {
  try {
    const { url, title, description, favicon, notes, isFavorite, tags, collectionIds } = req.body;
    
    // Create bookmark
    const bookmark = await Bookmark.create({
      userId: req.user.id,
      url,
      title,
      description,
      favicon,
      notes,
      isFavorite
    });
    
    // Handle tags if provided
    if (tags && tags.length > 0) {
      // Find or create tags and associate with bookmark
      const tagPromises = tags.map(async (tagName) => {
        const [tag] = await Tag.findOrCreate({
          where: { name: tagName, userId: req.user.id }
        });
        return tag;
      });
      
      const createdTags = await Promise.all(tagPromises);
      await bookmark.setTags(createdTags);
    }
    
    // Handle collections if provided
    if (collectionIds && collectionIds.length > 0) {
      const collections = await Collection.findAll({
        where: {
          id: collectionIds,
          userId: req.user.id
        }
      });
      
      if (collections.length > 0) {
        await bookmark.setCollections(collections);
      }
    }
    
    // Get the full bookmark with associations
    const fullBookmark = await Bookmark.findByPk(bookmark.id, {
      include: [
        { model: Tag },
        { model: Collection }
      ]
    });
    
    res.status(201).json(fullBookmark);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server Error' });
  }
};

// @desc    Update a bookmark
// @route   PUT /api/bookmarks/:id
// @access  Private
exports.updateBookmark = async (req, res) => {
  try {
    const { url, title, description, favicon, notes, isFavorite, tags, collectionIds } = req.body;
    
    // Find bookmark
    const bookmark = await Bookmark.findOne({
      where: { 
        id: req.params.id,
        userId: req.user.id 
      }
    });
    
    if (!bookmark) {
      return res.status(404).json({ message: 'Bookmark not found' });
    }
    
    // Update bookmark
    await bookmark.update({
      url: url || bookmark.url,
      title: title || bookmark.title,
      description: description !== undefined ? description : bookmark.description,
      favicon: favicon !== undefined ? favicon : bookmark.favicon,
      notes: notes !== undefined ? notes : bookmark.notes,
      isFavorite: isFavorite !== undefined ? isFavorite : bookmark.isFavorite
    });
    
    // Handle tags if provided
    if (tags) {
      // Find or create tags and associate with bookmark
      const tagPromises = tags.map(async (tagName) => {
        const [tag] = await Tag.findOrCreate({
          where: { name: tagName, userId: req.user.id }
        });
        return tag;
      });
      
      const createdTags = await Promise.all(tagPromises);
      await bookmark.setTags(createdTags);
    }
    
    // Handle collections if provided
    if (collectionIds) {
      const collections = await Collection.findAll({
        where: {
          id: collectionIds,
          userId: req.user.id
        }
      });
      
      await bookmark.setCollections(collections);
    }
    
    // Get the full bookmark with associations
    const fullBookmark = await Bookmark.findByPk(bookmark.id, {
      include: [
        { model: Tag },
        { model: Collection }
      ]
    });
    
    res.json(fullBookmark);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server Error' });
  }
};

// @desc    Delete a bookmark
// @route   DELETE /api/bookmarks/:id
// @access  Private
exports.deleteBookmark = async (req, res) => {
  try {
    const bookmark = await Bookmark.findOne({
      where: { 
        id: req.params.id,
        userId: req.user.id 
      }
    });
    
    if (!bookmark) {
      return res.status(404).json({ message: 'Bookmark not found' });
    }
    
    await bookmark.destroy();
    
    res.json({ message: 'Bookmark removed' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server Error' });
  }
};
